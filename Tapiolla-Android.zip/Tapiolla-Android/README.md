# Tapiolla

The future of business cards is here! With Tapiolla you will now be able to design and create your business cards just the way you want, be able to make multiple versions, keep all your info up to date with all your contacts and... NEVER RUN OUT OF CARDS AGAIN!!!

<ul>
<li>Tap To Share/Exchange</li>
<li>Unlimited Cards</li>
<li>Auto Update Contact Info</li>
<li>Never Lose Received Cards</li>
<li>Organize and Categorize Cards</li>
<li>Send Reminders/Notifications</li>
<li>And So Much More!</li>
</ul>

# Grandeur Apps

https://grandeurapps.com/portfolio/
