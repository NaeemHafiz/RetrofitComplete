package com.example.arago.tapiolla.fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.models.UserDO;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link AccountInfoFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link AccountInfoFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AccountInfoFragment extends Fragment {
    private static final String ARG_PARAM = "userInfo";
    private static final String ARG_PARAM2 = "param2";

    private UserDO userDO;


    private OnFragmentInteractionListener mListener;

    public AccountInfoFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param userDO User Information
     * @return A new instance of fragment AccountInfoFragment.
     */
    public static AccountInfoFragment newInstance(UserDO userDO) {
        AccountInfoFragment fragment = new AccountInfoFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PARAM, userDO);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            userDO = (UserDO) getArguments().getSerializable(ARG_PARAM);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_account_info, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        super.onViewCreated(view, savedInstanceState);
        Button editProfile = view.findViewById(R.id.editProfile);
        Button editPayment = view.findViewById(R.id.editPayment);
        TextView changPassword = view.findViewById(R.id.changePassword_Setting);
        TextView userFullName = view.findViewById(R.id.userFullName);
        TextView userFullName1 = view.findViewById(R.id.userFullName1);
        TextView userEmail = view.findViewById(R.id.userEmail);
        TextView userBillingAddress1 = view.findViewById(R.id.userBillingAddress1);
        TextView userBillingAddress2 = view.findViewById(R.id.userBillingAddress2);
        TextView userPhone = view.findViewById(R.id.userPhone);
        if(userDO != null) {
            if( userDO.getFullName() != null) {
                userFullName.setText(userDO.getFullName());
                userFullName1.setText(userDO.getFullName());
            }
            if( userDO.getUserEmail() != null) {
                userEmail.setText(userDO.getUserEmail());
            }
            if(userDO.getAddress() != null) {
                String add1 = userDO.getAddress().getAddress2() == null ?
                        userDO.getAddress().getAddress1() :
                        userDO.getAddress().getAddress1() + " / " + userDO.getAddress().getAddress2();
                userBillingAddress1.setText(add1 );

                String add2 = userDO.getAddress().getCity() + ", " + userDO.getAddress().getState() + ", " +
                        userDO.getAddress().getCountry() + ", " + userDO.getAddress().getZipcode();
                userBillingAddress2.setText(add2);
            }
            if(userDO.getPhoneNumber() != null) {
                userPhone.setText(userDO.getPhoneNumber());
            }
        }


        changPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onItemClick(v);
            }
        });

        editProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onItemClick(v);
            }
        });

        editPayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onItemClick(v);
            }
        });
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        void onItemClick(View v);
    }
}
