package com.example.arago.tapiolla.models;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@DynamoDBTable(tableName = "tapiolla-mobilehub-396882117-images")

public class ImagesDO {
    private String _userId;
    private String _imageId;
    private String _cardId;
    private String _imageUrl;
    private String _folderPath;

    @DynamoDBHashKey(attributeName = "userId")
    @DynamoDBIndexHashKey(attributeName = "userId", globalSecondaryIndexName = "card_image_index")
    public String getUserId() {
        return _userId;
    }

    public void setUserId(final String _userId) {
        this._userId = _userId;
    }
    @DynamoDBRangeKey(attributeName = "imageId")
    @DynamoDBAttribute(attributeName = "imageId")
    public String getImageId() {
        return _imageId;
    }

    public void setImageId(final String _imageId) {
        this._imageId = _imageId;
    }
    @DynamoDBIndexRangeKey(attributeName = "cardId", globalSecondaryIndexName = "card_image_index")
    public String getCardId() {
        return _cardId;
    }

    public void setCardId(final String _cardId) {
        this._cardId = _cardId;
    }
    @DynamoDBAttribute(attributeName = "imageUrl")
    public String getImageUrl() {
        return _imageUrl;
    }

    public void setImageUrl(final String _imageUrl) {
        this._imageUrl = _imageUrl;
    }

    @DynamoDBAttribute(attributeName = "folderPath")
    public String getFolderPath() {
        return _folderPath;
    }
    public void setFolderPath(final String _folderPath) {
        this._folderPath = _folderPath;
    }

//    public String getTableName() {
//        return "tapiolla-mobilehub-558879177-images";
//    }
    public Map<String, AttributeValue> toMap() {
        Map<String, AttributeValue> map = new HashMap<>();
        map.put("userId", new AttributeValue(_userId));
        map.put("imageId", new AttributeValue(_imageId));
        map.put("imageUrl", new AttributeValue(_imageUrl));
        map.put("cardId", new AttributeValue(_cardId));
        return map;
    }
}
