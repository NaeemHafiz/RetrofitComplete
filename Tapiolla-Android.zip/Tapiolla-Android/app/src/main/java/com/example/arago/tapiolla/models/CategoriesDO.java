package com.example.arago.tapiolla.models;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;
import com.example.arago.tapiolla.models.stamp.CSImageEntity;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

@DynamoDBTable(tableName = "tapiolla-mobilehub-396882117-categories")

public class CategoriesDO implements Serializable {
    private String _userId;
    private String _categoryId;
    private List<Category> _categories;

    @DynamoDBHashKey(attributeName = "userId")
    @DynamoDBAttribute(attributeName = "userId")
    public String getUserId() {
        return _userId;
    }

    public void setUserId(final String _userId) {
        this._userId = _userId;
    }

    @DynamoDBAttribute(attributeName = "categoryId")
    public String getCategoryId() {
        return _categoryId;
    }

    public void setCategoryId(final String _categoryId) {
        this._categoryId = _categoryId;
    }

    @DynamoDBAttribute(attributeName = "categories")
    public List<Category> getCategories() {
        return _categories;
    }

    public void setCategories(final List<Category> _categories) {
        this._categories = _categories;
    }
}
