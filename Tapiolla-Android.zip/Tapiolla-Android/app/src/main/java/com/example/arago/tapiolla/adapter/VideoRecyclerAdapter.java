package com.example.arago.tapiolla.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.models.user.Video;

import java.util.ArrayList;

public class VideoRecyclerAdapter extends RecyclerView.Adapter<VideoRecyclerAdapter.ViewHolder>{

    public static final String TAG = "CarRecyclerAdapter";
    private ItemClickListener mClickListener;
    private ArrayList<Video> mData;

    public VideoRecyclerAdapter(){

    }

    public VideoRecyclerAdapter(ArrayList<Video> data){
        this.mData = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater linf = LayoutInflater.from(viewGroup.getContext());
        View itemView = linf.inflate(R.layout.template, viewGroup, false);
        ViewHolder itemViewHolder = new ViewHolder(itemView);
        return itemViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
        viewHolder.videoImage.setImageBitmap(mData.get(position).getVideoThumbnailBm());
        Log.d("TAG","View: created!");
    }

    @Override
    public int getItemCount() {
        if(mData == null) {
            return 1;
        }
        return mData.size();
    }

    public void changeData( ArrayList<Video> data){
        this.mData = data;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener{

        ImageView videoImage;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            videoImage = itemView.findViewById(R.id.template_image);

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null) mClickListener.onItemClick(view, getAdapterPosition());
            Log.d("TAG","View: Clicked!");
        }

        @Override
        public boolean onLongClick(View v) {
            return false;
        }
    }
    public void setmClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }
}
