package com.example.arago.tapiolla.motion_views.utils;

import android.content.res.Resources;
import android.graphics.Typeface;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * extracting Typeface from Assets is a heavy operation,
 * we want to make sure that we cache the typefaces for reuse
 */
public class FontProvider {

    private static final String DEFAULT_FONT_NAME = "Helvetica";
    private static final String TAG = "FontProvider";
    private final Map<String, Typeface> typefaces;
    private final Map<String, String> fontNameToTypefaceFile;
    private final Resources resources;
    private final List<String> fontNames;

    public FontProvider(Resources resources) {
        this.resources = resources;

        typefaces = new HashMap<>();

        // populate fonts
        fontNameToTypefaceFile = new HashMap<>();
        fontNameToTypefaceFile.put("Arial", "Arial.ttf");
        fontNameToTypefaceFile.put("Eutemia", "Eutemia.ttf");
        fontNameToTypefaceFile.put("GREENPIL", "GREENPIL.ttf");
        fontNameToTypefaceFile.put("Grinched", "Grinched.ttf");
        fontNameToTypefaceFile.put("Helvetica", "Helvetica.ttf");
        fontNameToTypefaceFile.put("Libertango", "Libertango.ttf");
        fontNameToTypefaceFile.put("Metal Macabre", "MetalMacabre.ttf");
        fontNameToTypefaceFile.put("Parry Hotter", "ParryHotter.ttf");
        fontNameToTypefaceFile.put("SCRIPTIN", "SCRIPTIN.ttf");
        fontNameToTypefaceFile.put("The Godfather v2", "TheGodfather_v2.ttf");
        fontNameToTypefaceFile.put("Aka Dora", "akaDora.ttf");
        fontNameToTypefaceFile.put("Waltograph", "waltograph42.ttf");


        fontNames = new ArrayList<>(fontNameToTypefaceFile.keySet());
        //fontNames.add("Bold");
        //fontNames.add("Italic");
        Log.d(TAG,"BOLD: FontProvider:  called");
        for(int x = 0; x < fontNameToTypefaceFile.size(); x ++) {
            Typeface tf = Typeface.createFromAsset(resources.getAssets(),"fonts/" + fontNameToTypefaceFile.get(fontNames.get(x)));
            /* Bold Type */
            Typeface bold = Typeface.create(tf,Typeface.BOLD);
            typefaces.put("Bold_" + fontNames.get(x),bold);
            /* Italic Type */
            Typeface italic = Typeface.create(tf,Typeface.ITALIC);
            typefaces.put("Italic_" + fontNames.get(x) ,italic);
            /* Bold|Italic Type */
            Typeface boldItalic = Typeface.create(tf, Typeface.BOLD_ITALIC);
            typefaces.put("BoldItalic_" + fontNames.get(x), boldItalic);

        }



    }

    /**
     * @param typefaceName must be one of the font names provided from {@link FontProvider#getFontNames()}
     * @return the Typeface associated with {@code typefaceName}, or {@link Typeface#DEFAULT} otherwise
     */
    public Typeface getTypeface(@Nullable String typefaceName) {
        if (TextUtils.isEmpty(typefaceName)) {
            return Typeface.DEFAULT;
        } else {
            //noinspection Java8CollectionsApi
            if (typefaces.get(typefaceName) == null) {
                if(typefaceName.startsWith("Bold_")) {
                    typefaceName = typefaceName.replaceFirst("Bold_","");
                    Log.d(TAG,"BOLD: typefaceName: " + typefaceName);
                    return typefaces.get(typefaceName);
                }
                else if(typefaceName.startsWith("Italic_")) {
                    typefaceName = typefaceName.replaceFirst("Italic_","");
                    Log.d(TAG,"ITALIC: typefaceName: " + typefaceName);
                    return typefaces.get(typefaceName);
                } else if(typefaceName.startsWith("BoldItalic")) {
                    typefaceName = typefaceName.replaceFirst("BoldItalic","");
                    Log.d(TAG,"ITALIC: typefaceName: " + typefaceName);
                    return typefaces.get(typefaceName);

                }
                else {
                    typefaces.put(typefaceName,
                            Typeface.createFromAsset(resources.getAssets(), "fonts/" + fontNameToTypefaceFile.get(typefaceName)));
                }

            }
            return typefaces.get(typefaceName);
        }
    }

    /**
     * use {@link FontProvider#getTypeface(String) to get Typeface for the font name}
     *
     * @return list of available font names
     */
    public List<String> getFontNames() {
        return fontNames;
    }

    /**
     * @return Default Font Name - <b>Helvetica</b>
     */
    public String getDefaultFontName() {
        return DEFAULT_FONT_NAME;
    }
}