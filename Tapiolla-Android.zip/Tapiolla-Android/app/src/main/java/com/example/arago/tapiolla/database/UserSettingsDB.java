package com.example.arago.tapiolla.database;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.example.arago.tapiolla.models.UserDO;
import com.example.arago.tapiolla.models.user.UserSettings;


public class UserSettingsDB {
    private Context context;
    private String userId;
    private static DynamoDBMapper dynamoDBMapper;
    public static final String DONE_LOAD_USER_INFO = "loadUserInfoDone";

    public UserSettingsDB(Context context) {
        this.context = context;
        userId = DynamoSettings.getUserId();
        dynamoDBMapper = DynamoSettings.getDynamoDBMapper();
    }

    /**
     * get all user info
     */
    public void getUserInfo() {

        new LoadUserInfoTask().execute();
    }

    /**
     * save user Info
     * @param userDO user info object
     */
    public void saveUserInfo(final UserDO userDO) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                dynamoDBMapper.save(userDO);
            }
        }).start();
    }
    /**
     * Asyn task for get user info
     */
    private class LoadUserInfoTask extends AsyncTask<Void, Void, UserDO> {
        LoadUserInfoTask(){
        }

        @Override
        protected UserDO doInBackground(Void... voids) {
            UserDO result;
            result = dynamoDBMapper.load(UserDO.class, userId);
            return  result;
        }

        protected void onPostExecute(UserDO userDO) {
            Log.i("loadResult", "Loaded");
            if(userDO == null) {
                Log.i("loadResult", "Loaded null");
                userDO = new UserDO();
                userDO.setUserId(userId);
                UserSettings userSettings = new UserSettings();
                //Create new in db
                userSettings.setFindable(false);
                userSettings.setSearchable(false);
                userSettings.setNewsAndUpdate(false);
                userSettings.setShowPreview(false);
                userSettings.setSharing(false);
                userDO.setUserSettings(userSettings);
            }

                Intent broadCast = new Intent();
                broadCast.setAction(DONE_LOAD_USER_INFO);
                broadCast.putExtra("user_data",userDO);

                context.sendBroadcast(broadCast);

        }
    }
}
