package com.example.arago.tapiolla.controller.fragment;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import com.example.arago.tapiolla.R;

public class FragmentControl {
    static Context context;

    public FragmentControl(Context context) {
        this.context = context;
    }

    public static void displayFragment(FragmentTransaction ft,Fragment fragment, int fragmentContainerId,  boolean isReverse)
    {

        if (!isReverse)
            ft.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left);
        else
            ft.setCustomAnimations(R.anim.enter_from_left, R.anim.exit_to_right);
        ft.replace(fragmentContainerId, fragment).
                addToBackStack(null).commit();
    }

    public static void closeFragment(FragmentManager fragmentManager,int fragmentContainerId) {
      //  FragmentManager fragmentManager = getSupportFragmentManager();

        Fragment fragment = (Fragment) fragmentManager
                .findFragmentById(fragmentContainerId);

        if(fragment != null) {
            FragmentTransaction fragmentTransaction
                    = fragmentManager.beginTransaction();
            fragmentTransaction.remove(fragment).commit();
        }
    }
}
