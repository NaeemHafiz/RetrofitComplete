package com.example.arago.tapiolla.models.entities;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;

import java.util.List;
import java.util.Map;
import java.util.Set;

@DynamoDBTable(tableName = "tapiolla-mobilehub-396882117-imageEntities")

public class ImageEntitiesDO {
    private String _userId;
    private String _entityId;
    private String _cardId;
    private String _imageSource;
    private Boolean _isFlipped;
    private String _rotationInDegrees;
    private String _scale;
    private String _x;
    private String _y;
    private String _hyperlink;

    @DynamoDBHashKey(attributeName = "userId")
    @DynamoDBIndexHashKey(attributeName = "userId", globalSecondaryIndexName = "list_image")
    public String getUserId() {
        return _userId;
    }

    public void setUserId(final String _userId) {
        this._userId = _userId;
    }

    @DynamoDBRangeKey(attributeName = "entityId")
    @DynamoDBIndexHashKey(attributeName = "entityId", globalSecondaryIndexName = "image_card")
    public String getEntityId() {
        return _entityId;
    }

    public void setEntityId(final String _entityId) {
        this._entityId = _entityId;
    }
    @DynamoDBIndexRangeKey(attributeName = "cardId", globalSecondaryIndexNames = {"list_image","image_card",})
    public String getCardId() {
        return _cardId;
    }

    public void setCardId(final String _cardId) {
        this._cardId = _cardId;
    }
    @DynamoDBAttribute(attributeName = "imageSource")
    public String getImageSource() {
        return _imageSource;
    }

    public void setImageSource(final String _imageSource) {
        this._imageSource = _imageSource;
    }
    @DynamoDBAttribute(attributeName = "isFlipped")
    public Boolean getIsFlipped() {
        return _isFlipped;
    }

    public void setIsFlipped(final Boolean _isFlipped) {
        this._isFlipped = _isFlipped;
    }
    @DynamoDBAttribute(attributeName = "rotationInDegrees")
    public String getRotationInDegrees() {
        return _rotationInDegrees;
    }

    public void setRotationInDegrees(final String _rotationInDegrees) {
        this._rotationInDegrees = _rotationInDegrees;
    }
    @DynamoDBAttribute(attributeName = "scale")
    public String getScale() {
        return _scale;
    }

    public void setScale(final String _scale) {
        this._scale = _scale;
    }
    @DynamoDBAttribute(attributeName = "x")
    public String getX() {
        return _x;
    }

    public void setX(final String _x) {
        this._x = _x;
    }
    @DynamoDBAttribute(attributeName = "y")
    public String getY() {
        return _y;
    }

    public void setY(final String _y) {
        this._y = _y;
    }

    @DynamoDBAttribute(attributeName = "hyperlink")
    public String getHyperlink() {
        return _hyperlink;
    }

    public void setHyperlink(String _hyperlink) {
        this._hyperlink = _hyperlink;
    }

}
