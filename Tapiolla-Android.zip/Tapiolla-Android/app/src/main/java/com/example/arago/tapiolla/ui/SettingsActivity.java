package com.example.arago.tapiolla.ui;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.authentication.AWSLoginModel;
import com.example.arago.tapiolla.controller.PopUP;
import com.example.arago.tapiolla.controller.fragment.FragmentControl;
import com.example.arago.tapiolla.database.DynamoSettings;
import com.example.arago.tapiolla.database.UserSettingsDB;
import com.example.arago.tapiolla.fragments.AccountInfoFragment;
import com.example.arago.tapiolla.fragments.SettingsFragment;
import com.example.arago.tapiolla.models.UserDO;
import com.example.arago.tapiolla.models.user.UserSettings;


public class SettingsActivity extends AppCompatActivity implements SettingsFragment.OnSettingsFragmentInteractionListener,
        AccountInfoFragment.OnFragmentInteractionListener, View.OnClickListener {

    FragmentManager fm;
    FragmentTransaction ft;

    ImageView backBtn;

    String userEmail;
    Dialog dialog;
    AWSLoginModel awsLoginModel;
    UserSettingsDB userSettingsDB;

    BroadcastReceiver dataReceiver;

    UserDO useInfo;
    //save user settings
    UserSettings settings;
    // fragment
    SettingsFragment sf;
    AccountInfoFragment aif;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        //getSupportActionBar().hide();

        initialize();


        //create a dialog
        dialog = new Dialog(this, R.style.PauseDialog);

        backBtn = findViewById(R.id.backBtn);
        backBtn.setOnClickListener(this);

        fm = getSupportFragmentManager();
        if (savedInstanceState == null) {
            // init user info
            innitUserInfo();
        } else {
            useInfo = (UserDO) savedInstanceState.getSerializable("userInfo");
        }

        // initialize fragment
        sf = new SettingsFragment();
        aif = new AccountInfoFragment();
        // initialize data receiver
        dataReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction().equals(UserSettingsDB.DONE_LOAD_USER_INFO)) {
                    useInfo = (UserDO) intent.getSerializableExtra("user_data");

                    settings = useInfo.getUserSettings();

                    ft = fm.beginTransaction();
                    FragmentControl.displayFragment(ft, sf.newInstance(settings),R.id.settingsContainer,  true);

                }
            }
        };
    }

    private void initialize() {
        DynamoSettings dynamoSettings = new DynamoSettings();
       // awsLoginModel = new AWSLoginModel(this, dynamoSettings);
        userSettingsDB = new UserSettingsDB(this);
    }

    @Override
    public void onStart() {
        super.onStart();
    }
    @Override
    protected void onPause() {
        // Unregister since the activity is paused.
        super.onPause();
        unregisterReceiver(dataReceiver);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // An IntentFilter can match against actions, categories, and data
        IntentFilter filter = new IntentFilter(UserSettingsDB.DONE_LOAD_USER_INFO);
        registerReceiver(dataReceiver,filter);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("userInfo", useInfo);
    }

    /**
     * Fragment account setting clicked
     * Display the AccountInfoFragment
     */
    @Override
    public void onAccountSettingClick() {
        // display account info fragment
        ft = fm.beginTransaction();
        FragmentControl.displayFragment(ft, aif.newInstance(useInfo),R.id.settingsContainer,  false);
    }
    /**
     * Switches in Settings fragment change state
     * Save the state to database
     */
    @Override
    public void onSwitchNewsUpdates(boolean state) {
        settings.setNewsAndUpdate(state);
        useInfo.setUserSettings(settings);
        userSettingsDB.saveUserInfo(useInfo);
    }

    @Override
    public void onSwitchShowPreview(boolean state) {
        settings.setShowPreview(state);
        useInfo.setUserSettings(settings);
        userSettingsDB.saveUserInfo(useInfo);
    }

    @Override
    public void onSwitchSharing(boolean state) {
        settings.setSharing(state);
        useInfo.setUserSettings(settings);
        userSettingsDB.saveUserInfo(useInfo);
    }

    @Override
    public void onSwitchFindable(boolean state) {
        settings.setFindable(state);
        useInfo.setUserSettings(settings);
        userSettingsDB.saveUserInfo(useInfo);
    }

    @Override
    public void onSwitchSearchable(boolean state) {
        settings.setSearchable(state);
        useInfo.setUserSettings(settings);
        userSettingsDB.saveUserInfo(useInfo);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backBtn:
                Fragment fragment =  fm.findFragmentById(R.id.settingsContainer);
                if(fragment instanceof AccountInfoFragment) {
                    ft = fm.beginTransaction();
                    FragmentControl.displayFragment(ft, sf.newInstance(settings),R.id.settingsContainer,  true);
                } else {
                    finish();
                }

                break;
            default:
                break;
        }
    }

    /**
     * This function load user information from database
     */
    private void innitUserInfo() {
        userSettingsDB.getUserInfo();
    }
    /**
     * call when user click an Item in the user information fragment
     */
    @Override
    public void onItemClick(View v) {
        switch (v.getId()) {
            case R.id.changePassword_Setting:
                PopUP.openChangePasswordPopup(dialog, SettingsActivity.this, awsLoginModel, userEmail);
                break;
            case R.id.editProfile:
                PopUP.openEditProfilePopup(dialog, SettingsActivity.this, userSettingsDB, useInfo);
                break;
            case R.id.editPayment:
                PopUP.openPaymentPopup(dialog, SettingsActivity.this);
                break;

        }
    }
}
