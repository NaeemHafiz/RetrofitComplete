package com.example.arago.tapiolla.controller;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.arago.tapiolla.database.CardDynamoDB;
import com.example.arago.tapiolla.database.ShareCardDynamoDB;
import com.example.arago.tapiolla.models.Card;
import com.example.arago.tapiolla.models.CardsDO;
import com.example.arago.tapiolla.models.SharedCardsDO;

public class DownloadImage {
    /**
     *
     * @param context
     * @param card
     * @param successCLoadSharedCard
     */
    public static void downloadImages(Context context, final CardsDO card, final SharedCardsDO cardsDO, final ShareCardDynamoDB.OnSuccessDownloadImage successCLoadSharedCard) {
        final Bitmap[] temp = new Bitmap[1];
        Glide.with(context)
                .asBitmap()
                .load(card.getThumbnailImgId())
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        Card c = new Card(card, resource);
                        successCLoadSharedCard.onSuccessDownloadImage(c, cardsDO);
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                    }
                });
    }
    public static void downloadImages(Context context, final CardsDO card, final CardDynamoDB.OnSuccessSearchCards successSearchCards) {
        final Bitmap[] temp = new Bitmap[1];
        Glide.with(context)
                .asBitmap()
                .load(card.getThumbnailImgId())
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        Card c = new Card(card, resource);
                        successSearchCards.onSuccessSearchCards(c);
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                    }
                });
    }
}
