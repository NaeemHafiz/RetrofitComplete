package com.example.arago.tapiolla;

import android.Manifest;

public class Constant {

    public static final String BASE_URL = "http://tapiolla-api.shayansolutions.com/api/";
    public static final String LOGIN = "login";
    public static final String REGISTER = "register";

    public static final int C_TEMPLATE = 0;
    public static final int C_BACKGROUND = 1;
    public static final int C_TEXT = 2;
    public static final int C_CAMERA = 3;
    public static final int C_SOCIAL_MEDIA = 4;
    public static final int C_CARD_STAMP = 5;

    public static final int PERMISSION_ALL_CODE = 1;

    public static final int HYPERLINK_LAYOUT = R.layout.hyperlink;

    public static final String FACEBOOK = "facebook";
    public static final String GOOGLE = "google";
    public static final String INSTAGRAM = "instagram";
    public static final String LINKEDIN = "linkedin";
    public static final String EMAIL = "email";
    public static final String PINTEREST = "pinterest";
    public static final String SKYPE = "skype";
    public static final String TUMBLR = "tumblr";
    public static final String TWITTER = "twitter";
    public static final String WHATSAPP = "whatsapp";
    public static final String VIDEO_TYPE = "videoType";
    public static final String FIRST_NAME = "firstName";
    public static final String LAST_NAME = "lastName";
    public static final String TITLE = "title";
    public static final String ADDRESS = "address";
    //public static final String EMAIL = "email";
    public static final String PHONE = "phone";
    public static final String WEBLINK = "weblink";

    public static final String SOCIAL_MEDIA = "socialMedia";

    public static final int ROTATION_SNAP_RANGE = 2;
    public static final float RELATIVE_SNAP_RANGE = 1;

    public final static String BUCKET_NAME = "tapiolla-userfiles-mobilehub-396882117";
    public final static String PREFIX_URL = "https://" + BUCKET_NAME + ".s3.us-east-2.amazonaws.com/";
    public final static String VIDEO_THUMBNAIL_FOLDER = "video_thumbnails";
    public final static String UPLOAD_VIDEO_THUMBNAIL_S3_COMPLETED = "uploadVideoThumbnailS3Completed";
    public final static String EXTRA_THUMBNAIL_URL_DATA = "extraUrlVideoThumbnail";
    //Regions s3region = Regions.US_EAST_2;
    public static final String UPLOAD_VIDEO_S3_COMPLETED = "uploadVideoS3Completed";
    public static final String EXTRA_URL_DATA = "extraUrlData";
    public static final String VIDEO_FOLDER = "videos";

    public static final String LOAD_VIDEO_INFO_DONE = "load_video_info_done";
    public static final String EXTRA_VIDEO_INFO = "extra_video_info";
    public static final String LOAD_SINGLE_VIDEO_INFO_DONE = "load_single_video_info_done";
    public static final String EXTRA_SINGLE_VIDEO_INFO = "extra_single_video_info";


    public static final String[] permissions = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.BLUETOOTH,
            Manifest.permission.BLUETOOTH_ADMIN,
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.CHANGE_WIFI_STATE,
            Manifest.permission.CALL_PHONE
    };

    public static final String CONFIRM_REMOVE_CARD = "confirm_remove_card";
    public static final String CONFIRM_DELETE_CARD = "confirm_delete_card";
    public static final String CATEGORY_POSITION = "category_position";
    public static final String DONE_LOAD_USER_CATEGORY = "done_load_category";
    public static final String DONE_LOAD_OVERLAYS = "done_load_overlay";

}
