package com.example.arago.tapiolla.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.DragEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.models.CategoriesDO;
import com.example.arago.tapiolla.models.Category;
import com.example.arago.tapiolla.ui.Rolodex;

import java.util.ArrayList;


public class CategoriesRecyclerAdapter extends RecyclerView.Adapter<CategoriesRecyclerAdapter.ViewHolder>{
    private ArrayList<Category> categories ;
    private ItemClickListener itemClickListener;
    private ItemDragListener itemDragListener;
    private int selectedPosition = 0;
    Context context;
    public CategoriesRecyclerAdapter(Context context, ArrayList<Category> categories){
        this.categories = categories;
        this.context = context;
    }

    public void setData(ArrayList<Category> nameList) {
        this.categories = nameList;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_item_button,parent,false);
        final ViewHolder holder = new ViewHolder(view);
        return holder;

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {

            if(position == 0) {
                holder.name.setText("All");
            } else {
                holder.name.setText(categories.get(position-1).getCategoryName());
            }
            holder.item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    selectedPosition = position;
                    notifyDataSetChanged();
                    itemClickListener.onItemClick(view, position);
                }
            });

            if(selectedPosition == position){
                holder.item.setBackground(ContextCompat.getDrawable(context, R.drawable.highlightedroundbtn));
                holder.name.setTextColor(Color.parseColor("#ffffff"));
            } else {
                holder.item.setBackground(ContextCompat.getDrawable(context, R.drawable.roundbtn));
                holder.name.setTextColor(Color.parseColor("#ffffff"));
            }


    }

    @Override
    public int getItemCount() {
        if(categories != null)
            return categories.size() + 1;
        else
            return 1;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnDragListener, View.OnLongClickListener {
        TextView name;
        ConstraintLayout item;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.categoryName);
            item = itemView.findViewById(R.id.item_constraint_layout);
            item.setOnDragListener(this);
            item.setOnLongClickListener(this);
        }

        @Override
        public boolean onDrag(View v, DragEvent event) {
            switch(event.getAction()) {

                case DragEvent.ACTION_DROP:
                   // View vw = (View) event.getLocalState();
                    //if(vw.getId() == R.id.cardImage)
                    itemDragListener.onItemDrag(v,getAdapterPosition(), event);
                    break;
                default: break;
            }

            return true;
        }

        @Override
        public boolean onLongClick(View v) {
            itemClickListener.onItemLongClick(v, getAdapterPosition());
            return true;
        }
    }

    public int getSelectedPosition() {
        return selectedPosition;
    }
//
//    public void setSelectedPosition(int selectedPosition) {
//        this.selectedPosition = selectedPosition;
//    }

    public void setClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }
    public void setItemDragListener(ItemDragListener itemDragListener) {
        this.itemDragListener = itemDragListener;
    }

}