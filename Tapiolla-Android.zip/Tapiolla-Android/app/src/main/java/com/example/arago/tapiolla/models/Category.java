package com.example.arago.tapiolla.models;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBDocument;

import java.io.Serializable;
import java.util.List;
@DynamoDBDocument

public class Category implements Serializable {
    private String _categoryName;
    private List<String> _cardList;

    @DynamoDBAttribute(attributeName = "categoryName")
    public String getCategoryName() {
        return _categoryName;
    }

    public void setCategoryName(final String _categoryName) {
        this._categoryName = _categoryName;
    }

    @DynamoDBAttribute(attributeName = "cardList")
    public List<String> getCardList() {
        return _cardList;
    }

    public void setCardList(final List<String> _cardList) {
        this._cardList = _cardList;
    }
}
