package com.example.arago.tapiolla.database;

import android.os.AsyncTask;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBQueryExpression;
import com.example.arago.tapiolla.models.hyperlinks.Hyperlink;

import java.util.List;

public class HyperlinkDynamoDB {
    private String userId;
    private DynamoDBMapper dynamoDBMapper;
    private OnSuccessLoadHyperlink mOnSuccessLoadHyperlink;

    public HyperlinkDynamoDB(DynamoSettings dynamoSettings, OnSuccessLoadHyperlink mOnSuccessLoadHyperlink) {
        userId = dynamoSettings.getUserId();
        this.dynamoDBMapper = dynamoSettings.getDynamoDBMapper();
        this.mOnSuccessLoadHyperlink = mOnSuccessLoadHyperlink;

    }

    public String getUserId() {
        return userId;
    }

    public void saveHyperlink(final Hyperlink hyperlink) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                dynamoDBMapper.save(hyperlink);
            }
        }).start();
    }


    public void getHyperlinks() {
        Hyperlink hyperlink = new Hyperlink();
        hyperlink.setUserId(getUserId());
        new LoadTask().execute(hyperlink);
    }

    private class LoadTask extends AsyncTask<Hyperlink, Void, List<Hyperlink>> {

        LoadTask() {

        }
        @Override
        protected List<Hyperlink> doInBackground(Hyperlink... hyperlinks) {
            Hyperlink hyperlink = new Hyperlink();
            hyperlink.setUserId(getUserId());
            DynamoDBQueryExpression<Hyperlink> queryExpression = new DynamoDBQueryExpression<Hyperlink>()
                    .withHashKeyValues(hyperlink);
            List<Hyperlink> hyperlinkList = dynamoDBMapper.query(Hyperlink.class, queryExpression);
            return hyperlinkList;
        }

        @Override
        protected void onPostExecute(List<Hyperlink> hyperlinks) {
            mOnSuccessLoadHyperlink.OnSuccessLoadHyperlink(hyperlinks);
        }
    }

    public interface OnSuccessLoadHyperlink {
        void OnSuccessLoadHyperlink(List<Hyperlink> hyperlinkList);
    }
}
