package com.example.arago.tapiolla.models.user;

import android.graphics.Bitmap;
import com.example.arago.tapiolla.models.VideosDO;

import java.io.Serializable;

/**
 * This class contains all information about a video object
 */
public class Video implements Serializable {
    private VideosDO videosDO;
    private Bitmap videoThumbnailBm;

    public Video() {
    }

    public Video(VideosDO videosDO , Bitmap videoThumbnailBm) {
        this.videosDO = videosDO;
        this.videoThumbnailBm = videoThumbnailBm;
    }
    // Getters And Setters
    public VideosDO getVideosDO() {
        return videosDO;
    }

    public void setVideosDO(VideosDO videosDO) {
        this.videosDO = videosDO;
    }

    public Bitmap getVideoThumbnailBm() {
        return videoThumbnailBm;
    }

    public void setVideoThumbnailBm(Bitmap videoThumbnailBm) {
        this.videoThumbnailBm = videoThumbnailBm;
    }
}
