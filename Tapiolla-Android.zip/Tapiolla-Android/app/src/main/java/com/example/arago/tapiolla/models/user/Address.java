package com.example.arago.tapiolla.models.user;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBDocument;

import java.io.Serializable;


@DynamoDBDocument
public class Address implements Serializable {
    private String _address1;
    private String _address2;
    private String _city;
    private String _state;
    private String _country;
    private String _zipcode;

    @DynamoDBAttribute(attributeName = "address1")
    public String getAddress1() {
        return _address1;
    }
    public void setAddress1(final String _address1) {
        this._address1 = _address1;
    }

    @DynamoDBAttribute(attributeName = "address2")
    public String getAddress2() {
        return _address2;
    }
    public void setAddress2(final String _address2) {
        this._address2 = _address2;
    }

    @DynamoDBAttribute(attributeName = "city")
    public String getCity() {
        return _city;
    }
    public void setCity(final String _city) { this._city = _city; }

    @DynamoDBAttribute(attributeName = "state")
    public String getState() {
        return _state;
    }
    public void setState(final String _state) {
        this._state = _state;
    }

    @DynamoDBAttribute(attributeName = "country")
    public String getCountry() {
        return _country;
    }
    public void setCountry(final String _country) {
        this._country = _country;
    }

    @DynamoDBAttribute(attributeName = "zipcode")
    public String getZipcode() {
        return _zipcode;
    }
    public void setZipcode(final String _zipcode) {
        this._zipcode = _zipcode;
    }


}
