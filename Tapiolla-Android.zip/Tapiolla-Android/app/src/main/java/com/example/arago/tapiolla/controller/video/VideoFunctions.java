package com.example.arago.tapiolla.controller.video;

import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.webkit.MimeTypeMap;

import com.amazonaws.util.IOUtils;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.database.DatabaseInterface;
import com.example.arago.tapiolla.database.VideoDyanamoDB;
import com.example.arago.tapiolla.models.VideosDO;
import com.example.arago.tapiolla.models.user.Video;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.UUID;

import static com.example.arago.tapiolla.Constant.EXTRA_SINGLE_VIDEO_INFO;
import static com.example.arago.tapiolla.Constant.EXTRA_VIDEO_INFO;
import static com.example.arago.tapiolla.Constant.LOAD_SINGLE_VIDEO_INFO_DONE;
import static com.example.arago.tapiolla.Constant.LOAD_VIDEO_INFO_DONE;

public class VideoFunctions {
    public static final int GET_VIDEO_DEVICE = 101;
    public static final int GET_VIDEO_STORAGE = 102;

    /**
     * this method put play button overlay the image
     * @param context current context
     * @param uri image uri
     * @return Bitmap that have overlay img
     */
    public static Bitmap putOverlay(Context context, Uri uri) {

        MediaMetadataRetriever mMMR = new MediaMetadataRetriever();
        mMMR.setDataSource(context, uri);
        Bitmap bmAt0 = mMMR.getFrameAtTime();
        Bitmap bmOverlay = Bitmap.createBitmap(bmAt0.getWidth(), bmAt0.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmOverlay);
        Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.playbtn2);
        float left = (bmAt0.getWidth() / 2) - (bitmap.getWidth() / 2);
        float top = (bmAt0.getHeight() / 2) - (bitmap.getHeight() / 2);
        canvas.drawBitmap(bmAt0, 0, 0, null);
        canvas.drawBitmap(bitmap, left, top, null);

        return bmOverlay;
    }

    /**
     * This function is helper for upload image to S3
     * Create a file from uri
     * @param context current context
     * @param srcUri  file uri
     * @param desFile destination file
     */
    public static void createFile(Context context, Uri srcUri, File desFile) {

        try {
            InputStream inputStream = context.getContentResolver().openInputStream(srcUri);
            if (inputStream == null)
                return;
            OutputStream outputStream = new FileOutputStream(desFile);
            IOUtils.copy(inputStream, outputStream);
            inputStream.close();
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * this method is helper for upload image to s3
     * get the file extension from the uri
     * @param uri file uri
     * @return file extension
     */
    public static String getFileExtension(Context context, Uri uri) {
        ContentResolver contentResolver = context.getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();

        return mime.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    /**
     * This function save new video to DB
     * @param videosDO video Do object
     * @param videoDyanamoDB video dynamodb instance
     */
    public static void saveVideoInfoToDynamo(VideosDO videosDO, VideoDyanamoDB videoDyanamoDB) {

        videoDyanamoDB.saveNewVideoToDB(videosDO);
    }

    /**
     * This function create new video object
     * @param bitmap2 video thumbnail bitmap
     * @param userId user id
     * @return Video object
     */
    public static Video createNewVideoObject(Bitmap bitmap2, String userId) {
        Video newVideo = new Video();
        newVideo.setVideoThumbnailBm(bitmap2);
        // new video DO object
        VideosDO videosDO = new VideosDO();
        // create new id for videoDO
        String videoId = UUID.randomUUID().toString();
        videosDO.setVideoId(videoId);
        videosDO.setUserId(userId);
        newVideo.setVideosDO(videosDO);
        return newVideo;
    }

    /**
     * this function create a new Video list from VideoDO
     * @param videosDOS VideoDO list
     * @return list of Video Object
     */
    public static ArrayList<Video> createNewVideoList(ArrayList<VideosDO> videosDOS){
        ArrayList<Video> list = new ArrayList<>();
        for(VideosDO v : videosDOS) {
            Video vd = new Video();
            vd.setVideosDO(v);
            list.add(vd);
        }
        return list;
    }

    /**
     *
     * @param context
     * @param arrayList
     */
    public static void downloadImages(final Context context, final ArrayList<VideosDO> arrayList, final DatabaseInterface callback) {

        for(VideosDO v : arrayList) {
            final Video vd = new Video();
            vd.setVideosDO(v);
            Glide.with(context)
                    .asBitmap()
                    .load(v.getVideoThumbnailUrl())
                    .into(new CustomTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            vd.setVideoThumbnailBm(resource);
//                            //Broadcast the result
//                            Intent broadcast = new Intent();
//
//                            broadcast.setAction(LOAD_SINGLE_VIDEO_INFO_DONE);
//                            broadcast.putExtra(EXTRA_SINGLE_VIDEO_INFO, vd);
//
//                            context.sendBroadcast(broadcast);
                            callback.onLoadVideoThumbnailDone(vd);
                        }

                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {
                        }
                    });
        }

    }
}
