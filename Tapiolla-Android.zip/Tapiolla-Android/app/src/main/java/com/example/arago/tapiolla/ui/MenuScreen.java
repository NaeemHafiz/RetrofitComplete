package com.example.arago.tapiolla.ui;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.DialogInterface;

import android.content.Intent;
import android.content.pm.ActivityInfo;

import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;


import android.widget.LinearLayout;
import android.widget.Toast;

import com.amazonaws.mobile.auth.core.IdentityManager;
import com.amazonaws.mobile.auth.core.SignInStateChangeListener;
import com.amazonaws.mobile.auth.core.StartupAuthResult;
import com.amazonaws.mobile.auth.core.StartupAuthResultHandler;
import com.amazonaws.mobile.auth.facebook.FacebookSignInProvider;
import com.amazonaws.mobile.auth.google.GoogleSignInProvider;
import com.amazonaws.mobile.auth.userpools.CognitoUserPoolsSignInProvider;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.AWSStartupHandler;
import com.amazonaws.mobile.client.AWSStartupResult;
import com.azoft.carousellayoutmanager.CarouselLayoutManager;
import com.azoft.carousellayoutmanager.CarouselZoomPostLayoutListener;
import com.azoft.carousellayoutmanager.CenterScrollListener;
import com.example.arago.tapiolla.Constant;
import com.example.arago.tapiolla.adapter.CardRecyclerAdapter;
import com.example.arago.tapiolla.R;

import com.example.arago.tapiolla.adapter.ItemClickListener;
import com.example.arago.tapiolla.adapter.RecyclerTouchListener;
import com.example.arago.tapiolla.authentication.CognitoSettings;
import com.example.arago.tapiolla.controller.PopUP;
import com.example.arago.tapiolla.database.CardDynamoDB;
import com.example.arago.tapiolla.database.DynamoSettings;
import com.example.arago.tapiolla.models.Card;
import com.example.arago.tapiolla.models.CardsDO;
import com.example.arago.tapiolla.nearby_connection.NearbyManager;


import java.util.ArrayList;
import java.util.List;

import static com.example.arago.tapiolla.Constant.PERMISSION_ALL_CODE;

public class MenuScreen extends AppCompatActivity implements CardDynamoDB.OnSuccessCardsThumbnail {

    final String TAG = "MenuScreen";
    Button cardMaker, rolodex;
    RecyclerView mRecyclerView;
    CardRecyclerAdapter myAdapter;
    ArrayList<Bitmap> mCardList;
    static ArrayList<CardsDO> mCardListDetails;
    ImageView sendCard;
    ImageView cardToBeSend, openMenu;

    boolean mPermissionsGranted = false;
    String username = "";

    public static String SERVICE_ID;
    NearbyManager nearbyManager;

    CardDynamoDB cardDynamoDB;
    ConstraintLayout cardViewHolder;
    static CarouselLayoutManager layoutManager;

    private String cardDetails;
    DynamoSettings dynamoSettings;

    ItemClickListener itemClickListener;
    Dialog dialog;
    PopUP popUp;
    String[] permissions = Constant.permissions;


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_screen);
        //getSupportActionBar().hide();

        //Intent intent = getIntent();
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        dynamoSettings = new DynamoSettings();


        mCardList = new ArrayList<>();
        mCardListDetails = new ArrayList<>();

        //open menu button
        openMenu = findViewById(R.id.menu_main_more);
        openMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopUP.openMenuPopup(MenuScreen.this, v);
            }
        });

        //set recyclerview with  carousel animation
        mRecyclerView = findViewById(R.id.menu_card_recycler);
        myAdapter = new CardRecyclerAdapter(mCardList);
        layoutManager = new CarouselLayoutManager(CarouselLayoutManager.HORIZONTAL,true);
        dialog = new Dialog(this);
        popUp = new PopUP(this);

        mRecyclerView.setHasFixedSize(true);
        layoutManager.setPostLayoutListener(new CarouselZoomPostLayoutListener());
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.addOnScrollListener(new CenterScrollListener());
        mRecyclerView.setAdapter(myAdapter);
        mRecyclerView.addOnItemTouchListener(new RecyclerTouchListener(this,
                mRecyclerView, new ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {

            }

            @Override
            public void onItemLongClick(View view, int position) {
                PopUP.openShareCardOffline(MenuScreen.this, view, mCardList.get(position), mCardListDetails.get(position));
            }
        }));
        checkPermissions();

        cardMaker = (Button) findViewById(R.id.cardMaker);
        rolodex = (Button) findViewById(R.id.rolodex);

        int width = getResources().getDisplayMetrics().widthPixels;
        int height = getResources().getDisplayMetrics().heightPixels;
        int newHeight = (int) (height * 0.10);
        int newWidth = (int) (width * 0.70);
        rolodex.setLayoutParams(new LinearLayout.LayoutParams(newWidth, newHeight));
        cardMaker.setLayoutParams(new LinearLayout.LayoutParams(newWidth, newHeight));

        int cardListHeight = (int) (height * 0.40);
        mRecyclerView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, cardListHeight));
        sendCard = findViewById(R.id.sendCard);

        cardToBeSend = findViewById(R.id.cardView);
        cardViewHolder = findViewById(R.id.cardViewHolder);
        Bundle bundle = new Bundle();
        username = bundle.getString("username");

        SERVICE_ID = getApplicationContext().getPackageName();
        nearbyManager = new NearbyManager(getApplicationContext(), MenuScreen.this);
        nearbyManager.setDynamoSettings(dynamoSettings);

        cardMaker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MenuScreen.this,CardMaker.class);
                startActivity(i);
                finish();

            }
        });

        rolodex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MenuScreen.this,Rolodex.class);
                i.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(i);

            }
        });
        sendCard.setLongClickable(true);
        //do the sending
        sendCard.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                    if(mCardList.size() != 0) {


//                        if (isNfcSupported() && !nfcAdapter.isEnabled()) {
//                            Intent intent = new Intent(Settings.ACTION_NFC_SETTINGS);
//                            startActivity(intent);
//                        }
                        checkPermissions();
                        if(mPermissionsGranted) {
                            int position = layoutManager.getCenterItemPosition();

                            cardDetails = mCardListDetails.get(position).getUserId()+"@"+
                                    mCardListDetails.get(position).getCardId()+"@"+
                                    mCardListDetails.get(position).getThumbnailImgId();

                            nearbyManager.setCardDetails(cardDetails);
                            nearbyManager.stopAdvertising();
                            nearbyManager.startDiscovery();
                            //do the sending
                            sendCardAnimation(position);

                        } else {
                            checkPermissions();
                        }

                    } else {
                        Toast.makeText(MenuScreen.this, "You must have card in order to sent", Toast.LENGTH_SHORT).show();
                    }

                } else if (event.getAction() == android.view.MotionEvent.ACTION_UP) {
                    cardDetails = null;
                    //stopCardAnimation();
                }
                return true;
            }

        });
        nearbyManager.startAdvertising();


        IdentityManager.getDefaultIdentityManager().addSignInStateChangeListener(new SignInStateChangeListener() {
            @Override
            public void onUserSignedIn() {
               // Log.d(LOG_TAG, "User Signed In");
            }

            @Override
            public void onUserSignedOut() {
                startActivity(new Intent(MenuScreen.this, SplashActivity.class));
            }
        });
    }

    public String getUserId() {
        return DynamoSettings.getUserId();
    }


    @Override
    public void onStart() {
        super.onStart();
//        AWSMobileClient.getInstance().initialize(MenuScreen.this, new AWSStartupHandler() {
//            @Override
//            public void onComplete(AWSStartupResult awsStartupResult) {
//                IdentityManager identityManager = IdentityManager.getDefaultIdentityManager();
//                identityManager.resumeSession(MenuScreen.this, new StartupAuthResultHandler() {
//                    @Override
//                    public void onComplete(StartupAuthResult authResults) {
//                        if (!authResults.isUserSignedIn()) {
//
//                            startActivity(new Intent(MenuScreen.this, LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
//                        }
//                    }
//                });
//            }
//        }).execute();
        cardDynamoDB = new CardDynamoDB(getApplicationContext(), this);
        initMyCards();//initialize Card List

    }
//    @Override
//    public void onResume() {
//        super.onResume();
//
//        //Refresh stuff here
//        if(mCardList.size() != 0 && mCardListDetails.size() != 0)
//        {
//            mCardList = new ArrayList<>();
//            mCardListDetails = new ArrayList<>();
//        }
//
//        initMyCards();//initialize Card List
//
//    }
    public void sendCardAnimation(int position){
        mRecyclerView.setVisibility(View.INVISIBLE);
        cardViewHolder.setVisibility(View.VISIBLE);
        cardToBeSend.setImageBitmap(mCardList.get(position));
        Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.send_card_animation);
        cardToBeSend.startAnimation(animation);
    }

    public void stopCardAnimation(int anim){
        Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), anim);
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                cardViewHolder.setVisibility(View.INVISIBLE);
                mRecyclerView.setVisibility(View.VISIBLE);
                nearbyManager.startAdvertising();
                nearbyManager.stopDiscovery();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        cardToBeSend.startAnimation(animation);

    }

    public int getCurrentPosition() {
        return layoutManager.getCenterItemPosition();
    }

    public String getCardDetails() {
        return mCardListDetails.get(getCurrentPosition()).getUserId()+"@"+
                mCardListDetails.get(getCurrentPosition()).getCardId()+"@"+
                mCardListDetails.get(getCurrentPosition()).getThumbnailImgId();
    }

    public void checkPermissions() {

        List<String> listPermissionGranted = new ArrayList<>();
        for (int i = 0; i < permissions.length; i++) {
            int permisionNeeded = ContextCompat.checkSelfPermission(this, permissions[i]);
            if (permisionNeeded != PackageManager.PERMISSION_GRANTED) {
                listPermissionGranted.add(permissions[i]);
            }
        }

        if (!listPermissionGranted.isEmpty()) {
            //not granted ask for permission
            requestPermission(listPermissionGranted);
            mPermissionsGranted = false;
        } else {
            mPermissionsGranted = true;
        }

    }

    public void requestPermission(final List<String> listPermissionGranted) {

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                || ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)
                || ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_COARSE_LOCATION)) {
            //Toast.makeText(this,"Permission is needed to use the camera/gallery",Toast.LENGTH_SHORT).show();
            if (!mPermissionsGranted) {
                new android.support.v7.app.AlertDialog.Builder(this)
                        .setTitle("Permission")
                        .setMessage("Tapiolla needs your location to use the share function")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                ActivityCompat.requestPermissions(MenuScreen.this,
                                        listPermissionGranted.toArray(new String[listPermissionGranted.size()]), PERMISSION_ALL_CODE);

                            }
                        })
                        .setNegativeButton("CANCEL", null)
                        .create().show();
            }


        } else {
            ActivityCompat.requestPermissions(this,
                    listPermissionGranted.toArray(new String[listPermissionGranted.size()]), PERMISSION_ALL_CODE);
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        int x = 0;

        if (requestCode == PERMISSION_ALL_CODE) {
            if(grantResults.length > 0) {
                for (int grantResult : grantResults) {
                    if (grantResult != PackageManager.PERMISSION_GRANTED) {
                        x++;
                    }
                }
                mPermissionsGranted = x == 0;
            } else {
                mPermissionsGranted = false;
            }
        }
        else {
            mPermissionsGranted = false;
        }
    }

    public void initMyCards() {
        cardDynamoDB.getAllCards();
    }

    public static String getCurrentCardId() {
        int position = layoutManager.getCenterItemPosition();
        return mCardListDetails.get(position).getCardId();
    }

    @Override
    public void onSuccessLoadCardsThumbnail(List<Card> cardList) {

        if (cardList.size() > 0) {
            for (Card card : cardList) {
                mCardList.add(card.getCardBitmap());
                mCardListDetails.add(card.getCardsDO());
            }
        }
        myAdapter.notifyDataSetChanged();
    }

//    private void downloadImages(String url) {
//        Glide.with(getApplicationContext())
//                .asBitmap()
//                .load(url)
//                .into(new CustomTarget<Bitmap>() {
//                    @Override
//                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
//                        // do Recieve card Animation
//                        cardViewHolder.setVisibility(View.INVISIBLE);
//                        cardToBeSend.setImageBitmap(resource);
//                    }
//
//                    @Override
//                    public void onLoadCleared(@Nullable Drawable placeholder) {
//                    }
//                });
//    }
}
