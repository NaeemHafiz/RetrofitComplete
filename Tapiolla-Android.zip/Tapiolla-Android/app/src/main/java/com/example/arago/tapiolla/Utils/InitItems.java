package com.example.arago.tapiolla.Utils;

import com.example.arago.tapiolla.R;

import java.util.ArrayList;
import java.util.List;

public class InitItems {

    public List<Integer> initSocialMedia() {
        List<Integer> mListSocialMedia = new ArrayList<>();
        mListSocialMedia.add(R.drawable.social_media_facebook);
        mListSocialMedia.add(R.drawable.social_media_google);
        mListSocialMedia.add(R.drawable.social_media_instagram);
        mListSocialMedia.add(R.drawable.social_media_linkedin);
        mListSocialMedia.add(R.drawable.social_media_mail);
        mListSocialMedia.add(R.drawable.social_media_pinterest);
        mListSocialMedia.add(R.drawable.social_media_skype);
        mListSocialMedia.add(R.drawable.social_media_tumblr);
        mListSocialMedia.add(R.drawable.social_media_twitter);
        mListSocialMedia.add(R.drawable.social_media_whatsapp);

        return  mListSocialMedia;
    }

    public List<Integer> initCardStamp() {
        List<Integer> mListCardStamp = new ArrayList<>();
        mListCardStamp.add(R.drawable.cs_fname);
        mListCardStamp.add(R.drawable.cs_lname);
        mListCardStamp.add(R.drawable.cs_title);
        mListCardStamp.add(R.drawable.cs_address);
        mListCardStamp.add(R.drawable.cs_email);
        mListCardStamp.add(R.drawable.cs_phone);
        mListCardStamp.add(R.drawable.cs_weblink);
        mListCardStamp.add(R.drawable.cs_socialmedia);

        return mListCardStamp;
    }

    public List<Integer> initText() {
        List<Integer> mListText = new ArrayList<>();
        mListText.add(R.drawable.font_edit);
        mListText.add(R.drawable.font_increase);
        mListText.add(R.drawable.font_decrease);
        mListText.add(R.drawable.font_color);
        mListText.add(R.drawable.font_type);
        mListText.add(R.drawable.font_bold);
        mListText.add(R.drawable.font_italic);

        return mListText;
    }
}
