package com.example.arago.tapiolla.database;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapperConfig;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ComparisonOperator;
import com.amazonaws.services.dynamodbv2.model.Condition;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.arago.tapiolla.controller.DownloadImage;
import com.example.arago.tapiolla.models.Card;
import com.example.arago.tapiolla.models.CardsDO;
import com.example.arago.tapiolla.models.ImagesDO;
import com.example.arago.tapiolla.models.SharedCardsDO;

import java.util.ArrayList;
import java.util.List;

public class ShareCardDynamoDB {
    private Context context;
    public static String userId;
    private DynamoDBMapper dynamoDBMapper;
    private OnSuccessCLoadSharedCard successCLoadSharedCard;
    private OnSuccessDownloadImage mDownloadImageCallback;

    private int count = 0; // count the current downloaded card
    private int totalCard = 0; // total cards need to be downloaded

    public ShareCardDynamoDB() {
        userId = DynamoSettings.getUserId();
        this.dynamoDBMapper = DynamoSettings.getDynamoDBMapper();
    }
    public ShareCardDynamoDB(Context context, final OnSuccessCLoadSharedCard successCLoadSharedCard ) {
        this.context = context;
        userId = DynamoSettings.getUserId();
        this.dynamoDBMapper = DynamoSettings.getDynamoDBMapper();
        this.successCLoadSharedCard = successCLoadSharedCard;
        final ArrayList<Card> cards = new ArrayList<>();
        final ArrayList<SharedCardsDO> sharedCardsDOS = new ArrayList<>();
        mDownloadImageCallback = new OnSuccessDownloadImage() {
            @Override
            public void onSuccessDownloadImage(Card card, SharedCardsDO sharedCardsDO) {
                cards.add(card);
                sharedCardsDOS.add(sharedCardsDO);
                count++;
                if(count == totalCard) {
                    successCLoadSharedCard.onSuccessCLoadSharedCard(cards, sharedCardsDOS);
                }
            }
        };
    }

    public void saveSharedCard(final SharedCardsDO sharedCardsDO) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                dynamoDBMapper.save(sharedCardsDO);
                // Item saved
            }
        }).start();
    }

    public void saveSharedCard2(final SharedCardsDO sharedCardsDO) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                dynamoDBMapper.save(sharedCardsDO);
                // Item saved
            }
        }).start();
    }

    public void loadAllSharedCards() {
        SharedCardsDO template = new SharedCardsDO();
        template.setUserId(userId);
        new LoadCardsTask().execute(template);
    }

    /**
     * This task load all the shared cards of a user
     */
    private class LoadCardsTask extends AsyncTask<SharedCardsDO, Void, List<SharedCardsDO>> {

        LoadCardsTask(){
        }

        @Override
        protected List<SharedCardsDO> doInBackground(SharedCardsDO... sharedCardsDO) {

            DynamoDBQueryExpression<SharedCardsDO> queryExpression = new DynamoDBQueryExpression<SharedCardsDO>();
            queryExpression.setHashKeyValues(sharedCardsDO[0]);

            List<SharedCardsDO> awsqlist = dynamoDBMapper.query(SharedCardsDO.class, queryExpression);

            return awsqlist;
        }

        protected void onPostExecute(List<SharedCardsDO> result) {
            if(result.size() > 0) {
                totalCard = result.size();
                for (int i = 0; i< totalCard; i++) {
                    new LoadCardsDetailTask(result.get(i)).execute(result.get(i));
                }
            }
        }
    }


    public void delete(final SharedCardsDO deleteItem) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                dynamoDBMapper.delete(deleteItem);
                // Item deleted
            }
        }).start();
    }
    /**
     * This task load all the shared cards detail of a user
     */
    private class LoadCardsDetailTask extends AsyncTask<SharedCardsDO, Void, CardsDO> {
        private SharedCardsDO sharedCardsDO;

        LoadCardsDetailTask(SharedCardsDO sharedCardDO){
            this.sharedCardsDO = sharedCardDO;
        }

        @Override
        protected CardsDO doInBackground(SharedCardsDO... sharedCardsDO) {

            String uid = sharedCardsDO[0].getSenderId();
            String cid = sharedCardsDO[0].getCardId();

            CardsDO item = dynamoDBMapper.load(CardsDO.class, uid,cid);

            return item;
        }

        protected void onPostExecute(CardsDO result) {
            if(result != null) {

                DownloadImage.downloadImages(context,result, sharedCardsDO , mDownloadImageCallback);
            }
        }
    }


    public interface OnSuccessCLoadSharedCard {
        void onSuccessCLoadSharedCard(ArrayList<Card> cards, ArrayList<SharedCardsDO> sharedCardsDOS);

    }

    public interface OnSuccessDownloadImage {
        void onSuccessDownloadImage(Card card, SharedCardsDO cardsDO);
    }

}
