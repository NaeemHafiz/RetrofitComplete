package com.example.arago.tapiolla.controller;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.motion_views.widget.MotionView;
import com.example.arago.tapiolla.motion_views.widget.entity.MotionEntity;

import java.util.List;

public class SnapHelper {
    public static final String TAG = "SnapHelp";
    private static final float range = 0.007F;
    private MotionView motionView; //View we're working on - canvas
    private View relativeHorizontalLineView; //view that shows when y coordinate snaps
    private View relativeVerticalLineView; //view that shows when x coordinate snaps
    private View centerHorizontalView; //center x line view
    private View centerVerticalView; // center y line view

    public SnapHelper(MotionView motionView) {
        this.motionView = motionView;
        initLines();
    }

    private void initLines() {
        //X View at the center
        centerHorizontalView = new View(motionView.getContext());
        centerHorizontalView.setLayoutParams(new FrameLayout.LayoutParams(3, ViewGroup.LayoutParams.MATCH_PARENT));
        centerHorizontalView.setBackgroundColor(Color.parseColor("#ff0000"));
        centerHorizontalView.setVisibility(View.INVISIBLE);


        //Y View at the center
        centerVerticalView = new View(motionView.getContext());
        centerVerticalView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 3));
        centerVerticalView.setBackgroundColor(Color.parseColor("#ff0000"));

        centerVerticalView.setVisibility(View.INVISIBLE);

        //X line
        relativeHorizontalLineView = new View(motionView.getContext());
        relativeHorizontalLineView.setLayoutParams(new FrameLayout.LayoutParams(3, 200));
        //view.setBackground(getResources().getDrawable(R.drawable.dotted_line));
        relativeHorizontalLineView.setBackgroundColor(Color.parseColor("#ff0000"));
        relativeHorizontalLineView.setVisibility(View.INVISIBLE);

        //Y Line
        relativeVerticalLineView = new View(motionView.getContext());
        relativeVerticalLineView.setLayoutParams(new FrameLayout.LayoutParams(200, 3));
        //view.setBackground(getResources().getDrawable(R.drawable.dotted_line));
        relativeVerticalLineView.setBackgroundColor(Color.parseColor("#ff0000"));
        relativeVerticalLineView.setVisibility(View.INVISIBLE);

        motionView.addView(centerHorizontalView);
        motionView.addView(centerVerticalView);
        motionView.addView(relativeHorizontalLineView);
        motionView.addView(relativeVerticalLineView);
    }

    /**
     * hide visible lines
     */
    public void hideLines() {
        relativeHorizontalLineView.setVisibility(View.INVISIBLE);
        relativeVerticalLineView.setVisibility(View.INVISIBLE);
        centerHorizontalView.setVisibility(View.INVISIBLE);
        centerVerticalView.setVisibility(View.INVISIBLE);
    }

    /**
     *
     * @param selectedEntity current entity
     */
    public void checkSnapOnCanvasCenterXY(MotionEntity selectedEntity) {
        float x = selectedEntity.getLayer().getX();
        float y = selectedEntity.getLayer().getY();

        float centerX = 0.21915781F;
        //center y
        if (y >= -range && y <= range) {
            selectedEntity.getLayer().setY(0);
            centerVerticalView.setY(selectedEntity.absoluteCenterY());
            centerVerticalView.setVisibility(View.VISIBLE);
        } else {
            centerVerticalView.setVisibility(View.INVISIBLE);
        }
        //center x
        if (x >= centerX -range && x <= centerX + range) {
            selectedEntity.getLayer().setX(centerX);
            centerHorizontalView.setX(selectedEntity.absoluteCenterX());
            centerHorizontalView.setVisibility(View.VISIBLE);
        } else {
            centerHorizontalView.setVisibility(View.INVISIBLE);
        }
    }

    /**
     *
     * @param selectedEntity current entity
     */
    public void checkXMovement(MotionEntity selectedEntity, List<MotionEntity> relativeEntities) {
        int snapped = 0;//if entity snapped set line to visible

        for (int i = 0; i < relativeEntities.size(); i++) {
            if (selectedEntity != relativeEntities.get(i)) {
                Log.d(TAG, "checkXMovement: positionxx: " + i);
                float selectedEntityCenterX = selectedEntity.getLayer().getX();
                float selectedEntityScale = selectedEntity.getLayer().getScale();
                float selectedEntityLeftX = selectedEntityCenterX - (selectedEntityScale / 2);
                float selectedEntityRightX = selectedEntityCenterX + (selectedEntityScale / 2);

                MotionEntity relativeEntity = relativeEntities.get(i);

                float relativeCenterX = relativeEntity.getLayer().getX();
                float relativeScale = relativeEntity.getLayer().getScale();

                float relativeEntityLeftX = relativeEntity.getLayer().getX() - (relativeScale/7.9F);
                float relativeEntityRightX = relativeEntity.getLayer().getX() + (relativeScale/7.9F);



                if((selectedEntityCenterX >= (relativeEntityRightX - range)
                        && selectedEntityCenterX <= (relativeEntityRightX + range))
                        || (selectedEntityCenterX >= (relativeEntityLeftX - range)
                        && selectedEntityCenterX <= (relativeEntityLeftX + range))
                        || (selectedEntityCenterX >= (relativeCenterX - range)
                        && selectedEntityCenterX <= (relativeCenterX + range))) {
                    snapped++;
                    int height = (int) (selectedEntity.absoluteCenterY() - relativeEntity.absoluteCenterY());
                    //if selected entity Y is less than relative entity Y
                    if (height < 0) {
                        Log.d(TAG, "checkXMovement: height is negative");
                        height *= -1;
                        relativeHorizontalLineView.setY(selectedEntity.absoluteCenterY());
                    } else {
                        relativeHorizontalLineView.setY(relativeEntity.absoluteCenterY());
                    }
                    ViewGroup.LayoutParams layoutParams = new FrameLayout.LayoutParams(3, height);

                    /* CenterX <=> RightX */
                    if (selectedEntityCenterX >= (relativeEntityRightX - range)
                            && selectedEntityCenterX <= (relativeEntityRightX + range)) {
                        selectedEntity.getLayer().setX(relativeEntityRightX);
                        relativeHorizontalLineView.setX(selectedEntity.absoluteCenterX());
                        relativeHorizontalLineView.setVisibility(View.VISIBLE);
                    }

                    /* CenterX <=> LeftX */
                    if (selectedEntityCenterX >= (relativeEntityLeftX - range)
                            && selectedEntityCenterX <= (relativeEntityLeftX + range)) {
                        selectedEntity.getLayer().setX(relativeEntityLeftX);
                        relativeHorizontalLineView.setX(selectedEntity.absoluteCenterX());
                        relativeHorizontalLineView.setVisibility(View.VISIBLE);
                    }

                    /* CenterX <=> CenterX */
                    if (selectedEntityCenterX >= (relativeCenterX - range)
                            && selectedEntityCenterX <= (relativeCenterX + range)) {
                        selectedEntity.getLayer().setX(relativeCenterX);
                        relativeHorizontalLineView.setX(selectedEntity.absoluteCenterX());
                        relativeHorizontalLineView.setVisibility(View.VISIBLE);
                    }

                    relativeHorizontalLineView.setLayoutParams(layoutParams);
                } else {
                    relativeHorizontalLineView.setVisibility(View.INVISIBLE);
                }
            } 
        }

        if (snapped > 0) {
            relativeHorizontalLineView.setVisibility(View.VISIBLE);
        }


        /* LeftX to RightX */
//        Log.d(TAG, "checkXMovement: selectedEntityLeft: " + selectedEntityLeftX + " relativeEntityRight: "+relativeEntityRightX);
//        Log.d(TAG, "checkXMovement: selectedEntityX: " + selectedEntity.getLayer().getX() +" relativeEntityX: " + relativeEntity.getLayer().getX());
//        if (selectedEntityLeftX >= (relativeEntityRightX - (relativeScale/3.5F) - 0.01)
//            && selectedEntityLeftX <= (relativeEntityRightX - (relativeScale/3.5F) + 0.01)) {
//            selectedEntity.getLayer().setX(relativeCenterX + (relativeScale/3.5F));
//        }

    }

    /**
     *
     * @param selectedEntity current entity
     */
    public void checkYMovement(MotionEntity selectedEntity, List<MotionEntity> relativeEntities) {
        int snapped = 0;

        for (int i = 0; i < relativeEntities.size(); i++) {
            if (selectedEntity != relativeEntities.get(i)) {
                float selectedEntityCenterY = selectedEntity.getLayer().getY();
                float selectedEntityScale = selectedEntity.getLayer().getScale();
                float selectedEntityTopY = selectedEntityCenterY - (selectedEntityScale / 2);
                float selectedEntityBtmY = selectedEntityCenterY + (selectedEntityScale / 2);

                MotionEntity relativeEntity = relativeEntities.get(i);

                float relativeScale = relativeEntity.getLayer().getScale();
                float relativeCenterY = relativeEntity.getLayer().getY();
                float relativeEntityTopY = relativeEntity.getLayer().getY() - (relativeScale/4.5F);
                float relativeEntityBtmY = relativeEntity.getLayer().getY() + (relativeScale/4.5F);

                if((selectedEntityCenterY >= (relativeEntityBtmY - range)
                        && selectedEntityCenterY <= (relativeEntityBtmY + range))
                        || (selectedEntityCenterY >= (relativeEntityTopY - range)
                        && selectedEntityCenterY <= (relativeEntityTopY + range))
                        || (selectedEntityCenterY >= (relativeCenterY - range)
                        && selectedEntityCenterY <= (relativeCenterY + range))) {
                    snapped++;
                    int width = (int) (selectedEntity.absoluteCenterX() - relativeEntity.absoluteCenterX());
                    //if selected entity X is less than relative entity X
                    if (width < 0) {
                        width *= -1;
                        relativeVerticalLineView.setX(selectedEntity.absoluteCenterX());
                    } else {
                        relativeVerticalLineView.setX(relativeEntity.absoluteCenterX());
                    }
                    ViewGroup.LayoutParams layoutParams = new FrameLayout.LayoutParams(width, 3);


                    /* CenterY <=> BottomY */
                    if (selectedEntityCenterY >= (relativeEntityBtmY - range)
                            && selectedEntityCenterY <= (relativeEntityBtmY + range)) {
                        selectedEntity.getLayer().setY(relativeEntityBtmY);
                        relativeVerticalLineView.setY(selectedEntity.absoluteCenterY());
                        relativeVerticalLineView.setVisibility(View.VISIBLE);
                    }
                    /* CenterY <=> TopY */
                    if (selectedEntityCenterY >= (relativeEntityTopY - range)
                            && selectedEntityCenterY <= (relativeEntityTopY + range)) {
                        selectedEntity.getLayer().setY(relativeEntityTopY);
                        relativeVerticalLineView.setY(selectedEntity.absoluteCenterY());
                        relativeVerticalLineView.setVisibility(View.VISIBLE);
                    }
                    /* CenterY <=> CenterY */
                    if (selectedEntityCenterY >= (relativeCenterY - range)
                            && selectedEntityCenterY <= (relativeCenterY + range)) {
                        selectedEntity.getLayer().setY(relativeCenterY);
                        relativeVerticalLineView.setY(selectedEntity.absoluteCenterY());
                        relativeVerticalLineView.setVisibility(View.VISIBLE);
                    }
                    relativeVerticalLineView.setLayoutParams(layoutParams);
                } else {
                    relativeVerticalLineView.setVisibility(View.INVISIBLE);
                }
            }
            if (snapped > 0) {
                relativeVerticalLineView.setVisibility(View.VISIBLE);
            }

        }

    }

}
