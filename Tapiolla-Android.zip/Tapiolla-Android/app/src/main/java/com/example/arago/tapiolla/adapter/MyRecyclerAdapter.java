package com.example.arago.tapiolla.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.models.hyperlinks.SocialMedia;

import java.util.ArrayList;
import java.util.List;

public class MyRecyclerAdapter extends RecyclerView.Adapter<MyRecyclerAdapter.ViewHolder> {
    public static final String TAG = "MyRecyclerAdapter";
    private LayoutInflater mLayoutInflater;
    private List<Integer> mData;
    private List<Bitmap> mBitmap2 = new ArrayList<>();

    private ItemClickListener mClickListener;
    private int layoutResource;

    private Boolean isBitmap;
    private Boolean myCards = false;
    public int selectedPosition = -1;
    //Hyperlink
    private Boolean isHyperlink;
    private List<SocialMedia> mSocialMedia = new ArrayList<>();

    public MyRecyclerAdapter(Context context, List<Integer> data){
        this.mLayoutInflater = LayoutInflater.from(context);
        this.mData = data;
        this.isBitmap = false;
        this.isHyperlink = false;
        this.myCards = false;
        layoutResource = R.layout.template;
    }

    public MyRecyclerAdapter(Context context, List<Bitmap> data, Boolean setBtmp){
        this.mLayoutInflater = LayoutInflater.from(context);
        this.mBitmap2 = data;
        this.isBitmap = setBtmp;
        this.isHyperlink = false;
        this.myCards = false;
        layoutResource = R.layout.template;
    }

    public MyRecyclerAdapter(Context context, List<Bitmap> data, Boolean setBtmp, Boolean myCards){
        this.mLayoutInflater = LayoutInflater.from(context);
        this.mBitmap2 = data;
        this.isBitmap = setBtmp;
        this.myCards = myCards;
        this.isHyperlink = false;
        layoutResource = R.layout.template;
    }

    public MyRecyclerAdapter(Context context, List<SocialMedia> mSocialMedia, int layoutResource) {
        this.mLayoutInflater = LayoutInflater.from(context);
        this.isBitmap = false;
        this.isHyperlink = true;
        this.layoutResource = layoutResource;
        this.mSocialMedia = mSocialMedia;
        this.myCards = false;

    }

    public MyRecyclerAdapter(Context context){
        this.mLayoutInflater = LayoutInflater.from(context);
    }

    public void setLayoutResource(int resource) {
        layoutResource = resource;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = mLayoutInflater.inflate(layoutResource, viewGroup,false);
        final ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {

        if (isBitmap && myCards) {
            if (selectedPosition == position) {
                viewHolder.imageView.setBackgroundColor(Color.BLUE);
            } else {
                viewHolder.imageView.setBackgroundColor(Color.TRANSPARENT);
            }

            viewHolder.imageView.setImageBitmap(mBitmap2.get(position));
        }
        else if(isBitmap) {
            viewHolder.imageView.setImageBitmap(mBitmap2.get(position));
        }
        else if(isHyperlink){
            viewHolder.textView.setText(mSocialMedia.get(position).getSmName());
        } else {

            viewHolder.imageView.setImageResource(mData.get(position));
        }

    }

    public void setSelectedPosition(int selectedPosition) {
        this.selectedPosition = selectedPosition;
    }

    public int getSelectedPosition() {
        return selectedPosition;
    }

    public void replaceItem(int position, Bitmap bitmap) {
        mBitmap2.set(position, bitmap);
        notifyItemChanged(position);
    }

    public void toggle(int position, int i) {
        mData.set(position, i);
        notifyItemChanged(position);
    }

    public void toggleOff() {

    }

    @Override
    public int getItemCount() {
        if(isBitmap) {
            return mBitmap2.size();
        } else if (isHyperlink){
            Log.d(TAG, "Social media Size: : " + mSocialMedia.size());
            return mSocialMedia.size();
        } else {
            return mData.size();
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener{
        ImageView imageView;
        TextView textView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.template_image);
            textView = itemView.findViewById(R.id.hyperlink_text);
            itemView.setOnClickListener(this);
            itemView.setOnLongClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null) {
                Log.d("TAG","View: Clicked!");
                if (myCards) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        mClickListener.onItemClick(view, position);
                    }
                    selectedPosition = position;
                } else {
                    mClickListener.onItemClick(view, getAdapterPosition());
                }
            }

        }

        @Override
        public boolean onLongClick(View v) {
            mClickListener.onItemLongClick(v, getAdapterPosition());
            Log.d("TAG","View:Long Clicked!");
            return true;
        }
    }

    // allows clicks events to be caught
    public void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
        Log.d("TAG","Success: Clicked!");
    }
    public interface
    ItemClickListener {
        void onItemClick(View view, int position);
        void onItemLongClick(View view, int position);
    }

}
