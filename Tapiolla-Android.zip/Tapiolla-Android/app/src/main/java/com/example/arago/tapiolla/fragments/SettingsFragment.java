package com.example.arago.tapiolla.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Switch;

import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.models.user.UserSettings;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link SettingsFragment.OnSettingsFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link SettingsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SettingsFragment extends Fragment {
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "accountSettings";

    private UserSettings settings;

    Switch switchSharing, switchNewsUpdates, switchShowPreview, switchSearching, switchFinding;
    ConstraintLayout frameAccountInfo;
    EditText settingSearchUsers;

    private OnSettingsFragmentInteractionListener mListener;

    public SettingsFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param settings Parameter 1.
     * @return A new instance of fragment SettingsFragment.
     */
    public static SettingsFragment newInstance(UserSettings settings) {
        SettingsFragment fragment = new SettingsFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PARAM1, settings);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            settings = (UserSettings) getArguments().getSerializable(ARG_PARAM1);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_settings, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // find all views
        frameAccountInfo = view.findViewById(R.id.frameAccountInfo);
        switchSharing = view.findViewById(R.id.switchSharing);
        switchNewsUpdates = view.findViewById(R.id.switchNewsUpdates);
        switchShowPreview = view.findViewById(R.id.switchShowPreview);
        switchSearching = view.findViewById(R.id.switchSearching);
        switchFinding = view.findViewById(R.id.switchFinding);
        settingSearchUsers = view.findViewById(R.id.settingSearchUsers);

        if (settings != null) {
            switchSearching.setChecked(settings.getSearchable());
            switchFinding.setChecked(settings.getFindable());
            switchNewsUpdates.setChecked(settings.getNewsAndUpdate());
            switchShowPreview.setChecked(settings.getShowPreview());
            switchSharing.setChecked(settings.getSharing());

        }
        // Account setting frame click listener
        frameAccountInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onAccountSettingClick();

            }
        });

        //Sharing switch listener
        switchSharing.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked) {
                    // change the Sharing cards of this user on.
                    mListener.onSwitchSharing(true);
                } else {
                    // turn off the Sharing cards of this user.
                    mListener.onSwitchSharing(false);
                }
            }
        });

        //switchNewsUpdates listener
        switchNewsUpdates.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked) {
                    // change the Sharing cards of this user on.
                    mListener.onSwitchNewsUpdates(true);
                } else {
                    // turn off the Sharing cards of this user.
                    mListener.onSwitchNewsUpdates(false);
                }
            }
        });
        //switchShowPreview listener
        switchShowPreview.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked) {
                    // change the Sharing cards of this user on.
                    mListener.onSwitchShowPreview(true);
                } else {
                    // turn off the Sharing cards of this user.
                    mListener.onSwitchShowPreview(false);
                }
            }
        });
        //switchSearching listener
        switchSearching.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked) {
                    // change the Sharing cards of this user on.
                    mListener.onSwitchSearchable(true);
                } else {
                    // turn off the Sharing cards of this user.
                    mListener.onSwitchSearchable(false);
                }
            }
        });
        //switchFinding listener
        switchFinding.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked) {
                    // change the Sharing cards of this user on.
                    mListener.onSwitchFindable(true);
                } else {
                    // turn off the Sharing cards of this user.
                    mListener.onSwitchFindable(false);
                }
            }
        });
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnSettingsFragmentInteractionListener) {
            mListener = (OnSettingsFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnSettingsFragmentInteractionListener {
        void onAccountSettingClick();
        void onSwitchNewsUpdates(boolean state);
        void onSwitchShowPreview(boolean state);
        void onSwitchSharing(boolean state);
        void onSwitchFindable(boolean state);
        void onSwitchSearchable(boolean state);

    }
}
