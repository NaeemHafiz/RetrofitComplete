package com.example.arago.tapiolla.adapter;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.models.Image;

import java.util.ArrayList;

public class ImageRecyclerAdapter extends RecyclerView.Adapter<ImageRecyclerAdapter.ViewHolder> {
    private LayoutInflater mLayoutInflater;
    private ArrayList<Image> mData;
    private int layoutResource;
    private ItemClickListener mClickListener;


    public ImageRecyclerAdapter(Context context, ArrayList<Image> data) {
        this.mLayoutInflater = LayoutInflater.from(context);
        this.mData = data;

        layoutResource = R.layout.template;
    }


    public void setLayoutResource(int resource) {
        layoutResource = resource;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = mLayoutInflater.inflate(layoutResource, viewGroup, false);
        final ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {

        viewHolder.imageView.setImageBitmap(mData.get(position).getImageBitmap());
    }

        @Override
        public int getItemCount () {

            return mData.size();

        }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener {
            ImageView imageView;
            TextView textView;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                imageView = itemView.findViewById(R.id.template_image);
                textView = itemView.findViewById(R.id.hyperlink_text);
                itemView.setOnClickListener(this);
                itemView.setOnLongClickListener(this);
            }

            @Override
            public void onClick(View view) {
                if (mClickListener != null) {
                    mClickListener.onItemClick(view, getAdapterPosition());
                }

            }

            @Override
            public boolean onLongClick(View v) {
                mClickListener.onItemLongClick(v, getAdapterPosition());
                Log.d("TAG", "View:Long Clicked!");
                return true;
            }
        }

        // allows clicks events to be caught
        public void setClickListener (ItemClickListener itemClickListener){
            this.mClickListener = itemClickListener;
        }

}
