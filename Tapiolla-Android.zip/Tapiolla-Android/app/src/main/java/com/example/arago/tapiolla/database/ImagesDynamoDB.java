package com.example.arago.tapiolla.database;

import android.os.AsyncTask;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBQueryExpression;
import com.example.arago.tapiolla.models.ImagesDO;
import com.example.arago.tapiolla.models.entities.ImageEntitiesDO;
import com.example.arago.tapiolla.models.entities.TextEntitiesDO;

import java.util.List;
import java.util.UUID;

public class ImagesDynamoDB {
   // private DynamoSettings dynamoSettings;

    private String userId;
    private DynamoDBMapper dynamoDBMapper;
    private List<ImagesDO> returnList;
    private OnSuccessLoadDynamo mOnSuccess;
    public List<ImagesDO> getReturnList() {
        return returnList;
    }

    public void setReturnList(List<ImagesDO> returnList) {
        this.returnList = returnList;
    }

    public ImagesDynamoDB( OnSuccessLoadDynamo callback) {
     //   this.dynamoSettings = dynamoSettings;

        userId = DynamoSettings.getUserId();
        this.dynamoDBMapper = DynamoSettings.getDynamoDBMapper();
        mOnSuccess = callback;

    }

    public String getUserId() {
        return userId;
    }


    public void getAllImages() {
        ImagesDO template = new ImagesDO();
        template.setUserId(userId);
        new LoadTask().execute(template);

    }

    public void addNewImage(final ImagesDO newImage) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                dynamoDBMapper.save(newImage);
                // Item saved
            }
        }).start();
    }
    public void addNewImageEntity(final ImageEntitiesDO newImage) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                dynamoDBMapper.save(newImage);
                // Item saved
            }
        }).start();
    }
    public void delete(final ImagesDO deleteItem) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                dynamoDBMapper.delete(deleteItem);
                // Item deleted
            }
        }).start();
        //   mOnSuccess.onSuccessLoadDynamo();
    }
    public void addNewImageToDB(String url) {
        final ImagesDO newsItem = new ImagesDO();
        String imageId = UUID.randomUUID().toString();

        newsItem.setUserId(userId);
        newsItem.setImageId(imageId);
        newsItem.setImageUrl(url);
       // newsItem.setFolderPath(folderPath);
        // save to dynamo
        addNewImage(newsItem);
    }

    public DynamoDBMapper getDynamoDBMapper() {
        return dynamoDBMapper;
    }

    public void addNewTextEntity(final TextEntitiesDO newEntity) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                dynamoDBMapper.save(newEntity);
                // Item saved
            }
        }).start();
    }

    private class LoadTask extends AsyncTask<ImagesDO, Void, List<ImagesDO>> {

        LoadTask(){
        }

        @Override
        protected List<ImagesDO> doInBackground(ImagesDO... imagesDOS) {

            DynamoDBQueryExpression<ImagesDO> queryExpression = new DynamoDBQueryExpression<ImagesDO>();
            queryExpression.setHashKeyValues(imagesDOS[0]);

            List<ImagesDO> awsqlist = dynamoDBMapper.query(ImagesDO.class, queryExpression);

            return awsqlist;
        }

        protected void onPostExecute(List<ImagesDO> result) {
           // setReturnList(result);
            // Log.i("returnList",String.valueOf(returnList.size()));
            mOnSuccess.onSuccessLoadDynamo(result);
        }
    }
    public interface OnSuccessLoadDynamo {
        void onSuccessLoadDynamo(List<ImagesDO> result);
    }
}