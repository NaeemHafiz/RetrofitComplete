package com.example.arago.tapiolla.convertion;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class ConvertObject implements Serializable{
    //convert businesscard object to byte
    public byte[] getByteObjects(BusinessCard businessCard) {
        byte [] byteObjects = null;

        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(bos);
            oos.writeObject(businessCard);

            oos.close();
            bos.close();
            byteObjects = bos.toByteArray();
        }catch (Exception e) {
            e.printStackTrace();
            return byteObjects;
        }

        return byteObjects;
    }

    //convert byte to object
    public BusinessCard getJavaObject(byte[] convertObject) {
        BusinessCard businessCard = null;

        ByteArrayInputStream bais;
        ObjectInputStream ins;
        try {

            bais = new ByteArrayInputStream(convertObject);

            ins = new ObjectInputStream(bais);
            businessCard =(BusinessCard) ins.readObject();

            ins.close();

        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return businessCard;
    }

}
