package com.example.arago.tapiolla.motion_views.widget.entity;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.support.annotation.IntRange;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.ImageView;

import com.example.arago.tapiolla.motion_views.viewmodel.Layer;
import com.example.arago.tapiolla.ui.CardMaker;


public class ImageEntity extends MotionEntity {

    @NonNull
    private Bitmap bitmap;

    private Bitmap bitmapCopy;
    private Paint paint = new Paint();
    private int opacity = 255;
    private String imageSrc;
    private String imageLink;
    private String clickableType;
    private String duplicateName;

    public ImageEntity(@NonNull Layer layer,
                       @NonNull Bitmap bitmap,
                       @IntRange(from = 1) int canvasWidth,
                       @IntRange(from = 1) int canvasHeight) {
        super(layer, canvasWidth, canvasHeight);

        this.bitmap = bitmap;
        float width = bitmap.getWidth();
        float height = bitmap.getHeight();

        bitmapCopy = bitmap;//copy of bitmap
        paint.setAlpha(255);
        float widthAspect = 1.0F * canvasWidth / width;
        float heightAspect = 1.0F * canvasHeight / height;
        // fit the smallest size
        holyScale = Math.min(widthAspect, heightAspect);

        // initial position of the entity
        srcPoints[0] = 0; srcPoints[1] = 0;
        srcPoints[2] = width; srcPoints[3] = 0;
        srcPoints[4] = width; srcPoints[5] = height;
        srcPoints[6] = 0; srcPoints[7] = height;
        srcPoints[8] = 0; srcPoints[8] = 0;
    }
    public ImageEntity(@NonNull Layer layer,
                       @NonNull Bitmap bitmap,
                       @IntRange(from = 1) int canvasWidth,
                       @IntRange(from = 1) int canvasHeight,
                       String imageSrc) {
        super(layer, canvasWidth, canvasHeight);

        this.bitmap = bitmap;
        float width = bitmap.getWidth();
        float height = bitmap.getHeight();

        bitmapCopy = bitmap;//copy of bitmap
        paint.setAlpha(255);

        float widthAspect = 1.0F * canvasWidth / width;
        float heightAspect = 1.0F * canvasHeight / height;
        // fit the smallest size
        holyScale = Math.min(widthAspect, heightAspect);

        // initial position of the entity
        srcPoints[0] = 0; srcPoints[1] = 0;
        srcPoints[2] = width; srcPoints[3] = 0;
        srcPoints[4] = width; srcPoints[5] = height;
        srcPoints[6] = 0; srcPoints[7] = height;
        srcPoints[8] = 0; srcPoints[8] = 0;
        this.imageSrc = imageSrc;

    }
    @Override
    public void drawContent(@NonNull Canvas canvas, @Nullable Paint drawingPaint) {
        canvas.drawBitmap(bitmap, matrix, drawingPaint);
    }

    @NonNull
    public Bitmap getBitmap(){
        return bitmap;
    }


    public void applyOpacity() {
        Bitmap newBitmap = Bitmap.createBitmap(bitmapCopy.getWidth(), bitmapCopy.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(newBitmap);
        paint.setAlpha(opacity);
        canvas.drawBitmap(bitmapCopy, 0, 0, paint);
        bitmap = newBitmap;

    }
    public void setOpacity(int alpha) {
        opacity = alpha;
    }

    public int getOpacity() {
        return opacity;
    }

    @Override
    public int getWidth() {
        return bitmap.getWidth();
    }

    @Override
    public int getHeight() {
        return bitmap.getHeight();
    }

    @Override
    public void release() {
        if (!bitmap.isRecycled()) {
            bitmap.recycle();
        }
    }

    public String getImageSrc() {
        return imageSrc;
    }

    public void setImageSrc(String imageSrc) {
        this.imageSrc = imageSrc;
    }

    public String getImageLink() {
        return imageLink;
    }

    public void setImageLink(String imageLink) {
        this.imageLink = imageLink;
    }

    public String getClickableType() {
        return clickableType;
    }

    public void setClickableType(String clickableType) {
        this.clickableType = clickableType;
    }

    public String getDuplicateName() {
        return duplicateName;
    }

    public void setDuplicateName(String duplicateName) {
        this.duplicateName = duplicateName;
    }

}