package com.example.arago.tapiolla.models.user;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBDocument;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

@DynamoDBDocument

public class UserSettings implements Serializable {
    private boolean _searchable;
    private boolean _newsAndUpdate;
    private boolean _findable;
    private boolean _sharing;
    private boolean _showPreview;

    @DynamoDBAttribute(attributeName = "searchable")
    public boolean getSearchable() {
        return _searchable;
    }

    public void setSearchable(final boolean _searchable) {
        this._searchable = _searchable;
    }
    @DynamoDBAttribute(attributeName = "newsAndUpdate")
    public boolean getNewsAndUpdate() {
        return _newsAndUpdate;
    }

    public void setNewsAndUpdate(final boolean _newsAndUpdate) {
        this._newsAndUpdate = _newsAndUpdate;
    }
    @DynamoDBAttribute(attributeName = "findable")
    public boolean getFindable() {
        return _findable;
    }

    public void setFindable(final boolean _findable) {
        this._findable = _findable;
    }
    @DynamoDBAttribute(attributeName = "sharing")
    public boolean getSharing() {
        return _sharing;
    }

    public void setSharing(final boolean _sharing) {
        this._sharing = _sharing;
    }
    @DynamoDBAttribute(attributeName = "showPreview")
    public boolean getShowPreview() {
        return _showPreview;
    }

    public void setShowPreview(final boolean _showPreview) {
        this._showPreview = _showPreview;
    }
}
