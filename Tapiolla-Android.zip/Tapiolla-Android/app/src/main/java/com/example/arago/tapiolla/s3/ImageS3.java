package com.example.arago.tapiolla.s3;

//TODO: Fix the delete from s3


import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.DeleteObjectsRequest;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.util.IOUtils;
import com.example.arago.tapiolla.database.ImagesDynamoDB;
import com.example.arago.tapiolla.models.CardsDO;
import com.example.arago.tapiolla.models.ImagesDO;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;
import static com.example.arago.tapiolla.Constant.*;
public class ImageS3 {
    Context context;
    TransferUtility transferUtility;
    ImagesDynamoDB imagesDynamoDB;
    private OnSuccessS3 callback;
    private AmazonS3Client s3Client;
    Regions s3region = Regions.US_EAST_2;


    /**
     * Constructor
     *
     * @param context
     * @param imagesDynamoDB
     * @param callback
     */
    public ImageS3(Context context, ImagesDynamoDB imagesDynamoDB, OnSuccessS3 callback) {
        this.imagesDynamoDB = imagesDynamoDB;
        this.context = context;

        this.s3Client = new AmazonS3Client(AWSMobileClient.getInstance().getCredentialsProvider());
        s3Client.setRegion(Region.getRegion(s3region));
        //s3Client.getBucket
        transferUtility =
                TransferUtility.builder()
                        .context(context)
                        .awsConfiguration(AWSMobileClient.getInstance().getConfiguration())
                        .s3Client(s3Client)
                        .build();
        this.callback = callback;

    }

    /**
     * This function delete image in S3
     */
    public void deleteImageS3(String url, CardsDO cardsDO) {
//        int last = fileUrl.lastIndexOf("/");
//        String folder = fileUrl.substring(0,last);
//        int secondLast = folder.lastIndexOf("/");
//        final String folderPath = fileUrl.substring(secondLast + 1);
        if(url == null && cardsDO != null)
            url = cardsDO.getThumbnailImgId();

        final String folderPath;
        folderPath = url.substring(PREFIX_URL.length());
      //  Log.i("folderPath",filePath );
        Log.i("folderpath", folderPath);
        new Thread(new Runnable() {
            @Override
            public void run() {

               s3Client.deleteObject(new DeleteObjectRequest(BUCKET_NAME, folderPath));

            }
        }).start();
    }

    /**
     * This function upload the image Bitmap to amazon S3
     * convert from bitmap to uri and call the upload to S3 using Uri
     * @param bitmap
     * @param folder
     * @param cardsDO
     */
    public void uploadImageS3(Bitmap bitmap, String folder, CardsDO cardsDO, final boolean saveNew) {
        Uri uri = getImageUri(context,bitmap);
        uploadImageS3(uri, folder, cardsDO, saveNew);
    }

    /**
     * This function upload the image Uri to amazon S3
     * @param fileUri
     * @param folder
     * @param cardsDO
     */
    public void uploadImageS3(Uri fileUri, final String folder, final CardsDO cardsDO, final boolean saveNew) {

        if (fileUri != null) {
            final String fileName = cardsDO.getUserId()+"-" + System.currentTimeMillis();

            final File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "/" + fileName);

            createFile(context, fileUri, file);

            final String fileExtention =  getFileExtension(fileUri);
            String filePath;

            filePath = folder+ fileName + "." + fileExtention;
//            if(saveNew) {
//                filePath = folder+ fileName + "." + fileExtention;
//                Log.i("folderPath3",filePath );
//            } else {
//                String url = cardsDO.getThumbnailImgId();
//
//                filePath = url.substring(PREFIX_URL.length());
//                Log.i("folderPath",filePath );
//
//            }


            TransferObserver uploadObserver =
                    transferUtility.upload( filePath, file);

            uploadObserver.setTransferListener(new TransferListener() {

                @Override
                public void onStateChanged(int id, TransferState state) {
                    if (TransferState.COMPLETED == state) {
                        Toast.makeText(context, "Upload Completed!", Toast.LENGTH_SHORT).show();
                        if(folder.equals("images/")) {
                            //String folderPath = "images/" + fileName + "."+fileExtention;
                            imagesDynamoDB.addNewImageToDB(
                                    PREFIX_URL + folder + fileName +"."+ fileExtention
                            );
                            callback.onSuccessUploadS3(
                                    PREFIX_URL+ folder + fileName +"."+fileExtention
                            );
                        } else if(folder.equals("thumbnails/")){
                                if(!saveNew) {
                                    deleteImageS3(null, cardsDO);
                                }
                            cardsDO.setThumbnailImgId(
                                    PREFIX_URL + folder + fileName+"."+fileExtention
                            );

                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    imagesDynamoDB.getDynamoDBMapper().save(cardsDO);
                                }
                            }).start();
                        }

                        file.delete();
                    } else if (TransferState.FAILED == state) {
                        file.delete();
                    }
                }

                @Override
                public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
                    float percentDonef = ((float) bytesCurrent / (float) bytesTotal) * 100;
                    int percentDone = (int) percentDonef;
                }

                @Override
                public void onError(int id, Exception ex) {
                    ex.printStackTrace();
                }

            });
        }
    }

    public void uploadVideoThumbnailS3(Bitmap bitmap) {
        Uri fileUri = getImageUri(context,bitmap);

        if (fileUri != null) {
            final String fileName = String.valueOf(System.currentTimeMillis());

            final File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "/" + fileName);

            createFile(context, fileUri, file);

            final String fileExtention =  getFileExtension(fileUri);
            TransferObserver uploadObserver =
                    transferUtility.upload( VIDEO_THUMBNAIL_FOLDER + "/"+ fileName + "." + fileExtention, file);

            uploadObserver.setTransferListener(new TransferListener() {

                @Override
                public void onStateChanged(int id, TransferState state) {
                    if (TransferState.COMPLETED == state) {
                        Toast.makeText(context, "Upload Completed!", Toast.LENGTH_SHORT).show();
                        String url = PREFIX_URL + VIDEO_THUMBNAIL_FOLDER + "/" + fileName +"."+ fileExtention;

                            //Broadcast the result
                            Intent broadcast = new Intent();

                            broadcast.setAction(UPLOAD_VIDEO_THUMBNAIL_S3_COMPLETED);
                            broadcast.putExtra(EXTRA_THUMBNAIL_URL_DATA,url );

                            context.sendBroadcast(broadcast);

                    }
                }

                @Override
                public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
                    float percentDonef = ((float) bytesCurrent / (float) bytesTotal) * 100;
                    int percentDone = (int) percentDonef;
                }

                @Override
                public void onError(int id, Exception ex) {
                    ex.printStackTrace();
                }

            });
        }
    }
    /**
     * this method is helper for upload image to s3
     * get the file extension from the uri
     * @param uri
     * @return
     */
    private String getFileExtension(Uri uri) {
        ContentResolver contentResolver = context.getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();

        return mime.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    /**
     * This function is helper for upload image to S3
     * Create a file from uri
     * @param context
     * @param srcUri
     * @param dstFile
     */
    private void createFile(Context context, Uri srcUri, File dstFile) {
        try {
            InputStream inputStream = context.getContentResolver().openInputStream(srcUri);
            if (inputStream == null) return;
            OutputStream outputStream = new FileOutputStream(dstFile);
            IOUtils.copy(inputStream, outputStream);
            inputStream.close();
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     *
     * @param inContext
     * @param inImage
     * @return
     */
    private Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    /**
     * This interface for callback when successful upload to S3
     */
    public interface OnSuccessS3 {
        void onSuccessUploadS3(String url);
    }
}
