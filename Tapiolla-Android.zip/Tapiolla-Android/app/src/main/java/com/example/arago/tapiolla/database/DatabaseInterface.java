package com.example.arago.tapiolla.database;

import com.example.arago.tapiolla.models.user.Video;

public interface DatabaseInterface {
    /**
     *
     * @param video
     */
    void onLoadVideoThumbnailDone(Video video);
}
