package com.example.arago.tapiolla.Utils;

import com.example.arago.tapiolla.models.Image;

import java.util.ArrayList;

public class GetIndex {
    public static Image getTheImageDataFromUrl(String url, ArrayList<Image> arrayList) {
        if(url != null && arrayList != null)
        for (Image im : arrayList) {
            if (im.getImageUrl().equals(url))
                return im;
        }
        return null;
    }
}
