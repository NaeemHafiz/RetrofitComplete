package com.example.arago.tapiolla.authentication;

import android.content.Context;

import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUserPool;
import com.amazonaws.regions.Regions;

public class CognitoSettings {
    private Context context;
    private String userPoolId = "us-west-2_vUQ5AFyty";
    private String clientId = "kcp2nckle9eu0j3om4lluc41a";
    private String clientSecret = "n6b61qfed7vh6ogfbemm8qf4cifjk76vl1nn2smdm5ojmjhmc10";
    private Regions regions = Regions.US_WEST_2;

    public CognitoUserPool getUserPool(){
        return new CognitoUserPool(context, userPoolId, clientId, clientSecret, regions);
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public String getUserPoolId() {
        return userPoolId;
    }

    public void setUserPoolId(String userPoolId) {
        this.userPoolId = userPoolId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientSecret() {
        return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

    public Regions getRegions() {
        return regions;
    }

    public void setRegions(Regions regions) {
        this.regions = regions;
    }

    public CognitoSettings(Context context) {
        this.context = context;
    }
}
