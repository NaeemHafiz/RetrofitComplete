package com.example.arago.tapiolla.convertion;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.example.arago.tapiolla.motion_views.widget.entity.MotionEntity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class BusinessCard implements Serializable {
    private List<MotionEntity> motionEntities;
    private Bitmap background;
    private Bitmap backsplash;
    private Bitmap thumbnail;
    private String backgroundUrl;
    private String backsplashUrl;
    private String cardId;
    public BusinessCard(List<MotionEntity> motionEntities, Bitmap background, Bitmap backsplash, Bitmap thumbnail) {
        this.motionEntities = motionEntities;
        this.background = background;
        this.backsplash = backsplash;
        this.thumbnail = thumbnail;
    }

    public  BusinessCard() {
        this.motionEntities = new ArrayList<>();
        background = null;
        backsplash = null;
        thumbnail = null;
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
        // This will serialize all fields that you did not mark with 'transient'
        // (Java's default behaviour)
        oos.defaultWriteObject();
        // Now, manually serialize all transient fields that you want to be serialized
        if(background!=null){
            ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
            ByteArrayOutputStream byteStream1 = new ByteArrayOutputStream();
            ByteArrayOutputStream byteStream2 = new ByteArrayOutputStream();
            boolean success = background.compress(Bitmap.CompressFormat.PNG, 100, byteStream);
            boolean success1 = backsplash.compress(Bitmap.CompressFormat.PNG, 100, byteStream1);
            boolean success2 = thumbnail.compress(Bitmap.CompressFormat.PNG, 100, byteStream2);
            if(success && success1 && success2){
                oos.writeObject(byteStream.toByteArray());
                oos.writeObject(byteStream1.toByteArray());
                oos.writeObject(byteStream2.toByteArray());
            }
        }
    }

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException{
        // Now, all again, deserializing - in the SAME ORDER!
        // All non-transient fields
        ois.defaultReadObject();
        // All other fields that you serialized
        byte[] image = (byte[]) ois.readObject();
        if(image != null && image.length > 0){
            background = BitmapFactory.decodeByteArray(image, 0, image.length);
        }
    }

    public void setMotionEntities(List<MotionEntity> motionEntityList) {
        if(motionEntityList != null) {
            this.motionEntities.addAll(motionEntityList);
        }
    }

    public String getBackgroundUrl() {
        return backgroundUrl;
    }

    public void setBackgroundUrl(String backgroundUrl) {
        this.backgroundUrl = backgroundUrl;
    }

    public String getBacksplashUrl() {
        return backsplashUrl;
    }

    public void setBacksplashUrl(String backsplashUrl) {
        this.backsplashUrl = backsplashUrl;
    }

    public void setBackground(Bitmap bg) {
        background = bg;
    }

    public void setBacksplash(Bitmap bp) {
        backsplash = bp;
    }

    public void setThumbnail(Bitmap tn) {
        thumbnail = tn;
    }

    public List<MotionEntity> getMotionEntities() {
        return motionEntities;
    }

    public Bitmap getBackground() {
        return background;
    }

    public Bitmap getBacksplash() {
        return backsplash;
    }

    public Bitmap getThumbnail() {
        return thumbnail;
    }

}
