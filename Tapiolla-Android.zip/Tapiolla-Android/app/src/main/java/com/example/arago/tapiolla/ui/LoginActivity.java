package com.example.arago.tapiolla.ui;

/*
    RolodexCardOptionObject
    Tapiolla

    Created by Gradeur Apps INC. 2018- 2019
    Copyright C 2019 Gradeur Apps Inc.All Rights Reserved

    Cuong Thinh Dao

 */

/*
    TODO: MUST FIXED: Error when saving (AWS ERROR)
    TODO: Facebook/Google: Adding fb/google user to user pool. (Still can't find a solution)
    TODO: Rolodex-I: 2 state toggle button at the very top right above the search.
    TODO: ROlodex-II: Left - my community - search. Right - entire community - search database and NOT/EXCLUDING the shared cards they have.
    TODO: Rolodex: Clickable (i.e. Phone - call number. emailto:, hyperlink (web), socialmedia)
    TODO: CardMaker: Snap positions
 */


import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.amazonaws.mobile.auth.core.IdentityManager;
import com.amazonaws.mobile.auth.core.StartupAuthResult;
import com.amazonaws.mobile.auth.core.StartupAuthResultHandler;
import com.amazonaws.mobile.auth.facebook.FacebookButton;
import com.amazonaws.mobile.auth.google.GoogleButton;
import com.amazonaws.mobile.auth.ui.AuthUIConfiguration;
import com.amazonaws.mobile.auth.ui.SignInUI;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.AWSStartupHandler;
import com.amazonaws.mobile.client.AWSStartupResult;
import com.amazonaws.services.cognitoidentityprovider.model.NotAuthorizedException;
import com.amazonaws.services.cognitoidentityprovider.model.UserNotConfirmedException;
import com.amazonaws.services.cognitoidentityprovider.model.UserNotFoundException;
import com.example.arago.tapiolla.Constant;
import com.example.arago.tapiolla.R;
import java.util.ArrayList;
import java.util.List;
import static com.example.arago.tapiolla.Constant.PERMISSION_ALL_CODE;
import com.example.arago.tapiolla.authentication.AWSLoginHandler;
import com.example.arago.tapiolla.authentication.AWSLoginModel;
import com.example.arago.tapiolla.controller.PopUP;
import com.example.arago.tapiolla.database.DynamoSettings;
import com.facebook.AccessToken;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener, AWSLoginHandler {

    TextView loginEmail, loginPassword, forgotPassword, changePassinfo, loginWithThirdParty;
    LinearLayout createAccount;
    EditText emailReceiveCode;
    Button loginBtn, btnSendCode;

    String[] permissions = Constant.permissions;

    boolean mPermissionsGranted = false;

    AWSLoginModel awsLoginModel;


    private ProgressDialog progressDialog;
    Dialog dialog;

    boolean isLoggedIn = false;
    AccessToken accessToken;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        checkPermissions();

        // instantiating AWSLoginModel(context, callback)
        awsLoginModel = new AWSLoginModel(this, this);

        loginEmail = findViewById(R.id.loginEmail);
        loginPassword = findViewById(R.id.loginPassword);

        createAccount = findViewById(R.id.createAccount);
        forgotPassword = findViewById(R.id.forgotPassword);
        loginBtn = findViewById(R.id.login);
        loginWithThirdParty = findViewById(R.id.loginWithThirdParty);


        accessToken = AccessToken.getCurrentAccessToken();
        isLoggedIn = accessToken != null && !accessToken.isExpired();

        if (isLoggedIn) {
            //LoginManager.getInstance().logOut();
        }

        //login listener
        loginBtn.setOnClickListener(this);
        createAccount.setOnClickListener(this);
        forgotPassword.setOnClickListener(this);
        loginWithThirdParty.setOnClickListener(this);
        progressDialog = new ProgressDialog(this);
        dialog = new Dialog(this);
    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in
        AWSMobileClient.getInstance().initialize(LoginActivity.this, new AWSStartupHandler() {
            @Override
            public void onComplete(AWSStartupResult awsStartupResult) {
                IdentityManager identityManager = IdentityManager.getDefaultIdentityManager();
                identityManager.resumeSession(LoginActivity.this, new StartupAuthResultHandler() {
                    @Override
                    public void onComplete(StartupAuthResult authResults) {
                        if (authResults.isUserSignedIn()) {
                            startActivity(new Intent(LoginActivity.this, MenuScreen.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                        }
                    }
                });
            }
        }).execute();

    }

    public void checkPermissions() {

        List<String> listPermissionGranted = new ArrayList<>();
        for (int i = 0; i < permissions.length; i++) {
            int permisionNeeded = ContextCompat.checkSelfPermission(this, permissions[i]);
            if (permisionNeeded != PackageManager.PERMISSION_GRANTED) {
                listPermissionGranted.add(permissions[i]);
            }
        }

        if (!listPermissionGranted.isEmpty()) {
            //not granted ask for permission
            requestPermission(listPermissionGranted);
            mPermissionsGranted = false;
        } else {
            mPermissionsGranted = true;
        }

    }

    public void requestPermission(final List<String> listPermissionGranted) {

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                || ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)
                || ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_COARSE_LOCATION)) {
            //Toast.makeText(this,"Permission is needed to use the camera/gallery",Toast.LENGTH_SHORT).show();
            if (!mPermissionsGranted) {
                new AlertDialog.Builder(this)
                        .setTitle("Permission")
                        .setMessage("Tapiolla needs your permission to fully access all of the applications feature")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                ActivityCompat.requestPermissions(LoginActivity.this,
                                        listPermissionGranted.toArray(new String[listPermissionGranted.size()]), PERMISSION_ALL_CODE);

                            }
                        })
                        .setNegativeButton("CANCEL", null)
                        .create().show();
            }


        } else {
            ActivityCompat.requestPermissions(this,
                    listPermissionGranted.toArray(new String[listPermissionGranted.size()]), PERMISSION_ALL_CODE);
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        int x = 0;

        if (requestCode == PERMISSION_ALL_CODE) {
            if(grantResults.length > 0) {
                for (int i = 0; i < grantResults.length; i ++) {
                    if(grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                        x++;
                    }
                }
                mPermissionsGranted = x == 0;
            } else {
                mPermissionsGranted = false;
            }
        }
        else {
            mPermissionsGranted = false;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.login:
                login();
                break;
            case R.id.createAccount:
                PopUP.openRegisterPopup(dialog, LoginActivity.this, progressDialog, awsLoginModel);
                break;
            case R.id.forgotPassword:
                PopUP.openForgotPasswordPopup(dialog, LoginActivity.this, progressDialog);
                break;
            case R.id.loginWithThirdParty:
                loginWithThird();
                break;
                default:
                    break;
        }
    }

    private void loginWithThird() {
                AWSMobileClient.getInstance().initialize(this, new AWSStartupHandler() {
            @Override
            public void onComplete(AWSStartupResult awsStartupResult) {
                AuthUIConfiguration config =

                        new AuthUIConfiguration.Builder()
                               // .userPools(true)  // true? show the Email and Password UI
                                .signInButton(FacebookButton.class) // Show Facebook button
                                .signInButton(GoogleButton.class) // Show Google button
                                .logoResId(R.drawable.newlogo) // Change the logo
                               // .backgroundColor(Color.BLACK) // Change the backgroundColor
                                .isBackgroundColorFullScreen(true) // Full screen backgroundColor the backgroundColor full screenff
                                //.fontFamily("sans-serif-light") // Apply sans-serif-light as the global font
                                .canCancel(true)
                                .build();
                SignInUI signinUI = (SignInUI) AWSMobileClient.getInstance().getClient(LoginActivity.this, SignInUI.class);
                signinUI.login(LoginActivity.this, MenuScreen.class).authUIConfiguration(config).execute();
            }
        }).execute();
    }

    private void login() {

        if(TextUtils.isEmpty(loginEmail.getText().toString())){
            Toast.makeText(LoginActivity.this,"Please fill up email",Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(loginPassword.getText().toString())){
            Toast.makeText(LoginActivity.this,"Please fill up password",Toast.LENGTH_SHORT).show();
            return;
        }
        progressDialog.setMessage("Login ...");
        progressDialog.show();
        //call the aws login
        awsLoginModel.signInUser(String.valueOf(loginEmail.getText()).trim(), String.valueOf(loginPassword.getText()).trim());
    }

    @Override
    public void onRegisterSuccess(boolean mustConfirmToComplete, String email) {
        if (mustConfirmToComplete) {
            Toast.makeText(LoginActivity.this, "Almost done! Confirm code to complete registration", Toast.LENGTH_LONG).show();
            progressDialog.dismiss();
            dialog.dismiss();
            Intent intent = new Intent(LoginActivity.this, VerifyUserActivity.class);
            intent.putExtra("emailAddress", email);
            startActivity(intent);
        } else {
            Toast.makeText(LoginActivity.this, "Registered! Login Now!", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onSuccess(int process) {
        progressDialog.dismiss();
        switch (process) {
            case AWSLoginModel.PROCESS_SIGN_IN:
                AWSMobileClient.getInstance().initialize(LoginActivity.this, new AWSStartupHandler() {
                    @Override
                    public void onComplete(AWSStartupResult awsStartupResult) {
                        IdentityManager identityManager = IdentityManager.getDefaultIdentityManager();
                        identityManager.resumeSession(LoginActivity.this, new StartupAuthResultHandler() {
                            @Override
                            public void onComplete(StartupAuthResult authResults) {
                                progressDialog.dismiss();
                                if (authResults.isUserSignedIn()) {

                                    startActivity(new Intent(LoginActivity.this, MenuScreen.class));
                                    finish();

                                }
                            }
                        });
                    }
                }).execute();

                break;
            case AWSLoginModel.PROCESS_FORGOT_PASSWORD_SENT_CODE:

//                emailReceiveCode.setVisibility(View.GONE);
//                changePassinfo.setVisibility(View.GONE);
//                btnSendCode.setVisibility(View.GONE);
                break;
            case AWSLoginModel.PROCESS_CHANGE_PASSWORD:
                Toast.makeText(LoginActivity.this, "Your Password has been changed", Toast.LENGTH_SHORT).show();

                break;
        }

    }

    @Override
    public void onFailure(int process, Exception exception) {
        progressDialog.dismiss();
        String whatProcess = "";
        switch (process) {
            case AWSLoginModel.PROCESS_SIGN_IN:
                whatProcess = "Sign In:";
                //call the function to catch the exception
                failedSignInException(exception);
                break;
            case AWSLoginModel.PROCESS_REGISTER:
                whatProcess = "Registration:";
                break;
            case AWSLoginModel.PROCESS_CONFIRM_REGISTRATION:
                whatProcess = "Registration Confirmation:";
                break;
            case AWSLoginModel.PROCESS_FORGOT_PASSWORD:
                dialog.dismiss();
                //user is not found
                if (exception instanceof UserNotFoundException) {
                    Toast.makeText(LoginActivity.this, "user does not exist", Toast.LENGTH_SHORT).show();

                    //email password not correct
                } else {
                    Toast.makeText(LoginActivity.this, "Account is not verified", Toast.LENGTH_SHORT).show();
                }

                break;
        }
        Toast.makeText(LoginActivity.this, whatProcess + exception.getMessage(), Toast.LENGTH_LONG).show();
    }

    private void failedSignInException(Exception exception) {
        progressDialog.dismiss();

        if (exception instanceof UserNotConfirmedException) {
            Toast.makeText(LoginActivity.this, "You must verify your account before login", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(LoginActivity.this, VerifyUserActivity.class);
            intent.putExtra("emailAddress", String.valueOf(loginEmail.getText()));
            startActivity(intent);
            return;
        }
        //user is not found
        if (exception instanceof UserNotFoundException) {
            Toast.makeText(LoginActivity.this, "user does not exist", Toast.LENGTH_SHORT).show();

            //email password not correct
            return;
        } else if (exception instanceof NotAuthorizedException) {
            Toast.makeText(LoginActivity.this, "incorrect username or password", Toast.LENGTH_SHORT).show();
            return;
        } else {
            Toast.makeText(LoginActivity.this, exception.getLocalizedMessage(), Toast.LENGTH_SHORT).show();

             return;
        }
    }
}
