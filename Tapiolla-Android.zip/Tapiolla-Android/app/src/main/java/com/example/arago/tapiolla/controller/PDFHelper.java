package com.example.arago.tapiolla.controller;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.widget.Toast;

import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.models.CardsDO;
import com.example.arago.tapiolla.models.stamp.CSImageEntity;
import com.example.arago.tapiolla.models.stamp.CSTextEntity;
import com.example.arago.tapiolla.motion_views.widget.entity.ImageEntity;
import com.example.arago.tapiolla.motion_views.widget.entity.MotionEntity;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfAction;
import com.itextpdf.text.pdf.PdfAnnotation;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import static com.example.arago.tapiolla.Constant.ADDRESS;
import static com.example.arago.tapiolla.Constant.EMAIL;
import static com.example.arago.tapiolla.Constant.GOOGLE;
import static com.example.arago.tapiolla.Constant.VIDEO_TYPE;
import static com.example.arago.tapiolla.Constant.WHATSAPP;

public class PDFHelper {
    private static final String TAG = "tag";
    Context context;

    public PDFHelper(Context context) {
        this.context = context;
    }

    public void generatePdf (Bitmap bitmapThumbnail, CardsDO cardsDO) {
        
        List<CSImageEntity> imageEntities = cardsDO.getImagesEntities();
        List<CSTextEntity> textEntities = cardsDO.getTextEntities();
        int width = 700;
        int height = 400;

        ByteArrayOutputStream byteAOS = new ByteArrayOutputStream();
        bitmapThumbnail = Bitmap.createScaledBitmap(bitmapThumbnail, width, height, true);
        bitmapThumbnail.compress(Bitmap.CompressFormat.PNG,100,byteAOS);

        byte[] byteBtmpThumbnail = byteAOS.toByteArray();//for image

        Rectangle pageSize = new Rectangle(width, height);//size of document/pdf
        Document document = new Document(pageSize, 0, 0, 0, 0);

        //path for locally saving pdf for testing
        String targetPdf = Environment.getExternalStorageDirectory() + File.separator + "Tapiolla";
        File filePath = new File(targetPdf);
        if (!filePath.exists()) {
            filePath.mkdirs();
        }

        File file = new File(filePath, "card_" + cardsDO.getCardId() + ".pdf");

        ByteArrayOutputStream pdfBytes = new ByteArrayOutputStream();
        try {
            PdfWriter.getInstance(document, pdfBytes);
            //PdfWriter.getInstance(document, new FileOutputStream(file));
            document.open();
            Image image = Image.getInstance(byteBtmpThumbnail);
            document.add(image);
            document.close();
        } catch (Exception e) {
            Toast.makeText(context, "Error (Writing): " + e.toString(), Toast.LENGTH_LONG).show();
        }
        byte[] pdf = pdfBytes.toByteArray();

        //Debugging purposes

        float entityWidth;
        float entityHeight;
        float entityXAxis;
        float entityYAxis;

        //add clickables
        try {

            PdfReader pdfReader = new PdfReader(pdf);
            PdfStamper stamper = new PdfStamper(pdfReader, new FileOutputStream(file));//replace iwth byteOutputSttream
            PdfContentByte pdfContentByte = stamper.getOverContent(1);

            for (int i = 0; i < imageEntities.size(); i++) {
                if (imageEntities.get(i).getHyperlink() != null) {
                    float h = Float.parseFloat(imageEntities.get(i).getHeight());
                    float w = Float.parseFloat(imageEntities.get(i).getWidth());
                    float scale = Float.parseFloat(imageEntities.get(i).getScale());

                    entityWidth =  w * scale / 8;
                    entityHeight = h * scale / 8;
                    entityXAxis = Float.parseFloat(imageEntities.get(i).getX()) - 0.22F;
                    entityYAxis = Float.parseFloat(imageEntities.get(i).getY());
                    float xMovement  = document.getPageSize().getWidth() * entityXAxis; // x-axis position of the entity
                    float yMovement = document.getPageSize().getHeight() * entityYAxis; // y-axis position of the entity

                    int llx = (int) ((document.getPageSize().getWidth() / 2) - entityWidth / 2); //center-x (lower-left x)
                    int lly = (int) ((document.getPageSize().getHeight()/ 2) - entityHeight / 2); //center y (lower left y)

                    //move lower left (x, y) of rectangle to pdf
                    lly -= yMovement;
                    llx += xMovement;


                    int urx = (int) (llx + entityWidth); // upper-right x(width)
                    int ury = (int) (lly + entityHeight); // upper-right y(height)

                    Rectangle rectangle = new Rectangle(llx, lly, urx, ury);

                    rectangle.setBackgroundColor(new BaseColor(255, 255, 255, 0));//(r, g, b, opacity)
                    //rectangle.setBackgroundColor(BaseColor.BLUE);
                    pdfContentByte.rectangle(rectangle);
                    PdfAnnotation annotation;
                    if(imageEntities.get(i).getClickableType().equalsIgnoreCase(EMAIL)) {
                        annotation = PdfAnnotation.createLink(
                                stamper.getWriter(), rectangle, PdfAnnotation.HIGHLIGHT_INVERT,
                                new PdfAction("mailto:" + imageEntities.get(i).getHyperlink())
                        );
                    } else if (imageEntities.get(i).getClickableType().equalsIgnoreCase(WHATSAPP)) {
                        String number = imageEntities.get(i).getHyperlink();
                        String phoneNumber = number.replaceAll("[^0-9]","");
                        annotation = PdfAnnotation.createLink(
                                stamper.getWriter(), rectangle, PdfAnnotation.HIGHLIGHT_INVERT,
                                new PdfAction("tel:" + number)
                        );
                    } else {
                        annotation = PdfAnnotation.createLink(
                                stamper.getWriter(), rectangle, PdfAnnotation.HIGHLIGHT_INVERT,
                                new PdfAction(imageEntities.get(i).getHyperlink())
                        );
                    }

                    annotation.setTitle(imageEntities.get(i).getHyperlink());
                    stamper.addAnnotation(annotation, 1);

                }
            }

            for (int i = 0; i < textEntities.size(); i++) {
                if (textEntities.get(i).getClickableType().equalsIgnoreCase(ADDRESS)) {
                    float h = Float.parseFloat(textEntities.get(i).getHeight());
                    float w = Float.parseFloat(textEntities.get(i).getWidth());
                    float scale = Float.parseFloat(textEntities.get(i).getScale());

                    entityWidth =  w * scale / 8;
                    entityHeight = h * scale / 8;
                    entityXAxis = Float.parseFloat(textEntities.get(i).getX());
                    entityYAxis = Float.parseFloat(textEntities.get(i).getY()) - 0.4F;
                    float xMovement  = document.getPageSize().getWidth() * entityXAxis; // x-axis position of the entity
                    float yMovement = document.getPageSize().getHeight() * entityYAxis; // y-axis position of the entity

                    int llx = (int) ((document.getPageSize().getWidth() / 2) - entityWidth / 2); //center-x (lower-left x)
                    int lly = (int) ((document.getPageSize().getHeight()/ 2) - entityHeight / 2); //center y (lower left y)

                    //move lower left (x, y) of rectangle to pdf
                    lly -= yMovement;
                    llx += xMovement;


                    int urx = (int) (llx + entityWidth); // upper-right x(width)
                    int ury = (int) (lly + entityHeight); // upper-right y(height)

                    int newLLX = (int) (llx - (100 * scale));
                    int newLLY = (int) (lly - (50 * scale));
                    int newURX = (int) (urx + (100 * scale));
                    //int newURY = (int) (ury + (10 * scale));

                    Rectangle rectangle = new Rectangle(newLLX, newLLY, newURX, ury);

                    rectangle.setBackgroundColor(new BaseColor(255, 255, 255, 0));//(r, g, b, opacity)
                    //rectangle.setBackgroundColor(BaseColor.BLUE);
                    pdfContentByte.rectangle(rectangle);

                    String root = "https://www.google.com/maps/place/";


                    PdfAnnotation annotation = PdfAnnotation.createLink(
                            stamper.getWriter(), rectangle, PdfAnnotation.HIGHLIGHT_INVERT,
                            new PdfAction(root+textEntities.get(i).getText())
                    );
                    annotation.setTitle(textEntities.get(i).getText());
                    stamper.addAnnotation(annotation, 1);
                }
            }

            stamper.close();

        } catch (Exception e) {
            Toast.makeText(context, "Error (Reading): " + e.toString(), Toast.LENGTH_LONG).show();
            Log.d(TAG, "generatePdf: " + e.getMessage());
        }
    }

    public void generateImage(Bitmap bitmapThumbnail, CardsDO cardsDO) {
        try {
            String filePath = Environment.getExternalStorageDirectory() + File.separator + "Tapiolla";
            File dir = new File(filePath);
            if (!dir.exists()) { //if directory doesn't exist create one
                dir.mkdirs();
            }
            File file = new File(dir, "image_" + cardsDO.getCardId() + ".png");
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            bitmapThumbnail.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
