package com.example.arago.tapiolla.Utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.DisplayMetrics;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.example.arago.tapiolla.models.Card;
import com.example.arago.tapiolla.models.CardsDO;
import com.example.arago.tapiolla.models.Image;

import java.util.ArrayList;

import static com.example.arago.tapiolla.Constant.DONE_LOAD_OVERLAYS;

public class DownloadImages {

    private Context context;
    private int currentDoneNumber = 0;
    private int downloadSize = 0;
    private  int width;
    private ArrayList<Image> downloadedImages;

    public DownloadImages(Context context, ArrayList<String> urls, ArrayList<Image> downloadedImages, int width) {
        this.context = context;
        this.downloadedImages = downloadedImages;
        this.width = width;
        if (urls != null) {
            this.downloadSize = urls.size();
            //downloadedImages = new ArrayList<>();

            for(String url : urls) {
                downloadImage(url);
            }
        }

    }

    /**
     *
     * @param url
     */
    private void downloadImage(final String url) {
        DisplayMetrics displayMetrics = new DisplayMetrics();

        Glide.with(context)
                .asBitmap()
                .load(url)
                .apply(new RequestOptions().override(width, (int) (width* 0.65)))
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        currentDoneNumber++;
                        Image im = new Image(url, resource);
                        downloadedImages.add(im);
//                        if (currentDoneNumber == downloadSize) {
//                            // broadcast the result
//                            Intent broadCast = new Intent();
//                            broadCast.setAction(DONE_LOAD_OVERLAYS);
//                            //broadCast.putExtra("overlays_data", downloadedImages);
//
//                            context.sendBroadcast(broadCast);
//                        }
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                    }
                });

    }
}
