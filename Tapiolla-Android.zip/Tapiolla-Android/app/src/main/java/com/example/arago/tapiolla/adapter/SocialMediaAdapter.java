package com.example.arago.tapiolla.adapter;

public class SocialMediaAdapter {
}
