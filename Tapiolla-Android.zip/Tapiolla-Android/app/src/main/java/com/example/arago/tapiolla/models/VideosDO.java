package com.example.arago.tapiolla.models;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

@DynamoDBTable(tableName = "tapiolla-mobilehub-396882117-videos")

public class VideosDO implements Serializable {
    private String _userId;
    private String _videoId;
    private String _videoUrl;
    private String _videoThumbnailUrl;

    @DynamoDBHashKey(attributeName = "userId")
    @DynamoDBAttribute(attributeName = "userId")
    public String getUserId() {
        return _userId;
    }

    public void setUserId(final String _userId) {
        this._userId = _userId;
    }
    @DynamoDBRangeKey(attributeName = "videoId")
    @DynamoDBAttribute(attributeName = "videoId")
    public String getVideoId() {
        return _videoId;
    }

    public void setVideoId(final String _videoId) {
        this._videoId = _videoId;
    }

    @DynamoDBAttribute(attributeName = "videoUrl")
    public String getVideoUrl() {
        return _videoUrl;
    }

    public void setVideoUrl(final String _videoUrl) {
        this._videoUrl = _videoUrl;
    }
    @DynamoDBAttribute(attributeName = "videoThumbnailUrl")
    public String getVideoThumbnailUrl() {
        return _videoThumbnailUrl;
    }

    public void setVideoThumbnailUrl(final String _videoThumbnailUrl) {
        this._videoThumbnailUrl = _videoThumbnailUrl;
    }

}
