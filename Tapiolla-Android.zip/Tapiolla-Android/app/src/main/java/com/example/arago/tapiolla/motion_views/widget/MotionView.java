package com.example.arago.tapiolla.motion_views.widget;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GestureDetectorCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;


import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.controller.SnapHelper;
import com.example.arago.tapiolla.models.Card;
import com.example.arago.tapiolla.motion_views.gestures.MoveGestureDetector;
import com.example.arago.tapiolla.motion_views.gestures.RotateGestureDetector;
import com.example.arago.tapiolla.motion_views.widget.entity.ImageEntity;
import com.example.arago.tapiolla.motion_views.widget.entity.MotionEntity;
import com.example.arago.tapiolla.motion_views.widget.entity.TextEntity;
import com.example.arago.tapiolla.ui.CardMaker;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created on 9/29/16.
 */

public class MotionView extends FrameLayout implements Serializable {

    private static final String TAG = MotionView.class.getSimpleName();


    public interface Constants {
        float SELECTED_LAYER_ALPHA = 0.15F;
    }

    public interface MotionViewCallback {
        void onEntitySelected(@Nullable MotionEntity entity);
        void onEntityDoubleTap(@NonNull MotionEntity entity);
        void onEntityDeselect(boolean selected);
    }

    // layers
    private final List<MotionEntity> entities = new ArrayList<>();
    private final List<MotionEntity> undoEntities = new ArrayList<>();
    private final List<MotionEntity> deletedEntities = new ArrayList<>();
    boolean lastMoveIsDelete = false;
    @Nullable
    private MotionEntity selectedEntity;

    private Paint selectedLayerPaint;

    private Context context;

    SnapHelper snapHelper;


    // callback
    @Nullable
    private MotionViewCallback motionViewCallback;

    // gesture detection
    private ScaleGestureDetector scaleGestureDetector;
    private RotateGestureDetector rotateGestureDetector;
    private MoveGestureDetector moveGestureDetector;
    private GestureDetectorCompat gestureDetectorCompat;

    // constructors
    public MotionView(Context context) {
        super(context);
        init(context);

    }

    public MotionView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public MotionView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    @SuppressWarnings("unused")
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public MotionView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context);
    }

    private void init(@NonNull Context context) {
        this.context = context;
         snapHelper = new SnapHelper(this);
        // I fucking love Android
        setWillNotDraw(false);

        selectedLayerPaint = new Paint();
        selectedLayerPaint.setAlpha((int) (255 * Constants.SELECTED_LAYER_ALPHA));
        selectedLayerPaint.setAntiAlias(true);

        // init listeners
        this.scaleGestureDetector = new ScaleGestureDetector(context, new ScaleListener());
        this.rotateGestureDetector = new RotateGestureDetector(context, new RotateListener());
        this.moveGestureDetector = new MoveGestureDetector(context, new MoveListener());
        this.gestureDetectorCompat = new GestureDetectorCompat(context, new TapsListener());

        setOnTouchListener(onTouchListener);

        updateUI();
    }

    public MotionEntity getSelectedEntity() {
        return selectedEntity;
    }

    public List<MotionEntity> getEntities() {
        return entities;
    }

    public void deleteEntities(){
        if(entities != null){
            entities.clear();
            invalidate();
        }
    }

    public void setMotionViewCallback(@Nullable MotionViewCallback callback) {
        this.motionViewCallback = callback;
    }

    public void addEntity(@Nullable MotionEntity entity) {
        if (entity != null) {
            snapHelper.hideLines();
            initEntityBorder(entity);
            entities.add(entity);
            selectEntity(entity, false);
        }
    }

    public void addEntityAndPosition(@Nullable MotionEntity entity) {
        if (entity != null) {
            snapHelper.hideLines();
            initEntityBorder(entity);
            initialTranslateAndScale(entity);
            entities.add(entity);
            selectEntity(entity, true);
        }
    }

    public void duplicateEntity(@Nullable MotionEntity entity) {
        if(entity != null){
            snapHelper.hideLines();
            initEntityBorder(entity);
            entity.moveToCanvasCenter();
            entity.getLayer().setScale(getSelectedEntity().getLayer().getScale());
            entities.add(entity);
            selectEntity(entity,true);
        }
    }

    public void duplicateImageEntity(ImageEntity imageEntity) {
        initEntityBorder(imageEntity);
        imageEntity.moveToCanvasCenter();
        imageEntity.getLayer().setScale(getSelectedEntity().getLayer().getScale());
        entities.add(imageEntity);
        selectEntity(imageEntity, true);
    }

    private void initEntityBorder(@NonNull MotionEntity entity ) {
        // init stroke
        int strokeSize = getResources().getDimensionPixelSize(R.dimen.stroke_size);
        Paint borderPaint = new Paint();
        borderPaint.setStrokeWidth(strokeSize);
        borderPaint.setAntiAlias(true);
        borderPaint.setColor(ContextCompat.getColor(getContext(), R.color.stroke_color));

        entity.setBorderPaint(borderPaint);
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);

        // dispatch draw is called after child views is drawn.
        // the idea that is we draw background stickers, than child views (if any), and than selected item
        // to draw on top of child views - do it in dispatchDraw(Canvas)
        // to draw below that - do it in onDraw(Canvas)
        if (selectedEntity != null) {
            selectedEntity.draw(canvas, selectedLayerPaint);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        drawAllEntities(canvas);

        super.onDraw(canvas);
    }

    /**
     * draws all entities on the canvas
     * @param canvas Canvas where to draw all entities
     */
    private void drawAllEntities(Canvas canvas) {
        for (int i = 0; i < entities.size(); i++) {
            entities.get(i).draw(canvas, null);
        }
    }

    /**
     * as a side effect - the method deselects Entity (if any selected)
     * @return bitmap with all the Entities at their current positions
     */
    public Bitmap getThumbnailImage() {
        selectEntity(null, false);

        Bitmap bmp = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);
        // IMPORTANT: always create white background, cos if the image is saved in JPEG format,
        // which doesn't have transparent pixels, the background will be black
        bmp.eraseColor(Color.WHITE);
        Canvas canvas = new Canvas(bmp);

        drawAllEntities(canvas);

        return bmp;
    }

    private void updateUI() {
        invalidate();
    }

    private void handleTranslate(PointF delta) {
        if (selectedEntity != null) {
            float newCenterX = selectedEntity.absoluteCenterX() + delta.x;
            float newCenterY = selectedEntity.absoluteCenterY() + delta.y;

            // limit entity center to screen bounds
            boolean needUpdateUI = false;
            if (newCenterX >= 0 && newCenterX <= getWidth()) {
                selectedEntity.getLayer().postTranslate(delta.x / getWidth(), 0.0F);
                needUpdateUI = true;
            }
            if (newCenterY >= 0 && newCenterY <= getHeight()) {
                selectedEntity.getLayer().postTranslate(0.0F, delta.y / getHeight());
                needUpdateUI = true;
            }

            snapHelper.checkSnapOnCanvasCenterXY(selectedEntity);
            snapHelper.checkXMovement(selectedEntity, getEntities());
            snapHelper.checkYMovement(selectedEntity, getEntities());



            if (needUpdateUI) {
                updateUI();
            }
        }
    }



    private void initialTranslateAndScale(@NonNull MotionEntity entity) {
        entity.moveToCanvasCenter();
        entity.getLayer().setScale(entity.getLayer().initialScale());
    }

    private void selectEntity(@Nullable MotionEntity entity, boolean updateCallback) {
        if (selectedEntity != null) {
            selectedEntity.setIsSelected(false);
        }
        if (entity != null) {
            entity.setIsSelected(true);
        }
        selectedEntity = entity;
        invalidate();
        if (updateCallback && motionViewCallback != null) {
            motionViewCallback.onEntitySelected(entity);
        }
    }

    public void unselectEntity() {
        if (selectedEntity != null) {
            Log.d(TAG, "unselectEntity: called");
            selectEntity(null, true);
        }
    }



    @Nullable
    private MotionEntity findEntityAtPoint(float x, float y) {
        MotionEntity selected = null;
        PointF p = new PointF(x, y);
        for (int i = entities.size() - 1; i >= 0; i--) {
            if (entities.get(i).pointInLayerRect(p)) {
                selected = entities.get(i);
                break;
            }
        }
        return selected;
    }

    private void updateSelectionOnTap(MotionEvent e) {
        MotionEntity entity = findEntityAtPoint(e.getX(), e.getY());
        selectEntity(entity, true);
        if(motionViewCallback != null) {
            if(entity == null ) {
                Log.d(TAG, "updateSelectionOnTap: deselect");
                motionViewCallback.onEntityDeselect(false);
                snapHelper.hideLines();
            } else {
                Log.d(TAG, "updateSelectionOnTap: select");
                motionViewCallback.onEntityDeselect(true);
            }

        }
    }

    public void hideSnapHelperLines() {
        snapHelper.hideLines();
    }

    private void updateOnLongPress(MotionEvent e) {
        // if layer is currently selected and point inside layer - move it to front
        if (selectedEntity != null) {
            PointF p = new PointF(e.getX(), e.getY());
            if (selectedEntity.pointInLayerRect(p)) {
                bringLayerToFront(selectedEntity);
            }
        }
    }

    private void deleteEntity(@NonNull MotionEntity entity) {
        if(selectedEntity == null){
            return;
        }

        entities.remove(entity);
        snapHelper.hideLines();
        invalidate();
    }

    private void bringLayerToFront(@NonNull MotionEntity entity) {
        //get entity position
        int position = 0;
        for(int x = 0; x < entities.size(); x++) {
            if(entity == entities.get(x)) {
                position = x;
                Log.d(TAG,"bringLayerToFront: position: " + position);
            }
        }
        // removing and adding brings layer up by 1
        if (entities.remove(entity)) {
            if(entities.size() - 1 < position) {
                entities.add(position,entity);
                invalidate();
            }
            else {
                entities.add(position + 1,entity);
                invalidate();
            }


        }
    }

    private void moveEntityToBack(@Nullable MotionEntity entity) {
        if (entity == null) {
            return;
        }
        int position = 0;
        for(int x = 0; x < entities.size(); x++) {
            if(entity == entities.get(x)) {
                position = x;
            }
        }
        if (entities.remove(entity)) {
            if(position > 0) {
                entities.add(position - 1, entity);
                invalidate();
            }
            else {
                entities.add(position , entity);
                invalidate();
            }

        }
    }

    public void flipSelectedEntity() {
        if (selectedEntity == null) {
            return;
        }
        selectedEntity.getLayer().flip();
        invalidate();
    }


    public void moveSelectedBack() {
        moveEntityToBack(selectedEntity);
    }

    public void moveSelectedFront(){
        bringLayerToFront(selectedEntity);}

    public void deleteSelectedEntity() {
        if (selectedEntity == null) {
            return;
        }

        lastMoveIsDelete = true;
        undoEntities.add(selectedEntity);
        entities.remove(selectedEntity);
        unselectEntity();
    }

    public void undo(){
        if(lastMoveIsDelete && undoEntities.size() > 0){
            lastMoveIsDelete = false;
            unselectEntity();
            redo();
        }
        else if(entities.size() > 0) {
            unselectEntity();
            lastMoveIsDelete = false;
            MotionEntity undoEntity = entities.get(entities.size() - 1);
            entities.remove(entities.get(entities.size()-1));
            undoEntities.add(undoEntity);
            invalidate();
        }



    }
    public void redo(){
        Log.d(TAG,"redo: lastMoveIsDelete: " + lastMoveIsDelete);
        if(undoEntities.size() > 0) {
            lastMoveIsDelete = false;
            unselectEntity();
            MotionEntity redoEntity = undoEntities.get(undoEntities.size() - 1);
            undoEntities.remove(undoEntities.size() - 1);
            entities.add(redoEntity);
            invalidate();
        }



    }

    // memory
    public void release() {
        for (MotionEntity entity : entities) {
            entity.release();
        }
    }

    // gesture detectors

    private final View.OnTouchListener onTouchListener = new View.OnTouchListener() {

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (scaleGestureDetector != null) {
                scaleGestureDetector.onTouchEvent(event);
                rotateGestureDetector.onTouchEvent(event);
                moveGestureDetector.onTouchEvent(event);
                gestureDetectorCompat.onTouchEvent(event);
            }
            return true;
        }
    };

    private class TapsListener extends GestureDetector.SimpleOnGestureListener {
        @Override
        public boolean onDoubleTap(MotionEvent e) {
            if (motionViewCallback != null && selectedEntity != null) {
                motionViewCallback.onEntityDoubleTap(selectedEntity);
            }
            return true;
        }

        @Override
        public void onLongPress(MotionEvent e) {
            //updateOnLongPress(e);
        }

        @Override
        public boolean onSingleTapUp(MotionEvent e) {
            updateSelectionOnTap(e);
            return true;
        }
    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            if (selectedEntity != null) {
                float scaleFactorDiff = detector.getScaleFactor();
                selectedEntity.getLayer().postScale(scaleFactorDiff - 1.0F);
                updateUI();
            }
            return true;
        }
    }

    private class RotateListener extends RotateGestureDetector.SimpleOnRotateGestureListener {
        @Override
        public boolean onRotate(RotateGestureDetector detector) {
            if (selectedEntity != null) {
                //Log.d(TAG,"rotationDegreesDelta: " + detector.getRotationDegreesDelta());
                Log.d(TAG,"rotationDegreesDelta: " +  selectedEntity.getLayer().getRotationInDegrees());
                selectedEntity.getLayer().postRotate(-detector.getRotationDegreesDelta());
                //Snap to zero degrees
                if(selectedEntity.getLayer().getRotationInDegrees() <= 2 && selectedEntity.getLayer().getRotationInDegrees() >= -2) {
                    selectedEntity.getLayer().setRotationInDegrees(0);
                }
                //Snap to 90 degrees
                else if(selectedEntity.getLayer().getRotationInDegrees() >= 88 && selectedEntity.getLayer().getRotationInDegrees() <= 92) {
                    selectedEntity.getLayer().setRotationInDegrees(90);
                }
                //Snap to 180 degrees
                else if (selectedEntity.getLayer().getRotationInDegrees() >= 178
                        && selectedEntity.getLayer().getRotationInDegrees() <= 182){
                    selectedEntity.getLayer().setRotationInDegrees(180);
                }
                //Snap to 270 degrees
                else if (selectedEntity.getLayer().getRotationInDegrees() >= 268
                        && selectedEntity.getLayer().getRotationInDegrees() <= 272){
                    selectedEntity.getLayer().setRotationInDegrees(270);
                }
                //do normal rotation
                else {
                    selectedEntity.getLayer().postRotate(-detector.getRotationDegreesDelta());
                }
                updateUI();
            }
            return true;
        }
    }

    private class MoveListener extends MoveGestureDetector.SimpleOnMoveGestureListener {

        @Override
        public boolean onMove(MoveGestureDetector detector) {

            handleTranslate(detector.getFocusDelta());

            if (selectedEntity != null) {
                float[] i = selectedEntity.getDestPoints();
            }
            return true;
        }
    }
}
