package com.example.arago.tapiolla.adapter;

import android.view.DragEvent;
import android.view.View;

public interface ItemDragListener {
    void onItemDrag (View v, int position, DragEvent event);
}
