package com.example.arago.tapiolla.database;

import android.annotation.SuppressLint;
import android.os.AsyncTask;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBQueryExpression;
import com.example.arago.tapiolla.models.stamp.CardStamp;
import com.example.arago.tapiolla.models.stamp.TextStampDO;

import java.util.List;

public class TextStampDynamoDB {
    private String userId;
    private DynamoDBMapper dynamoDBMapper;
    private OnSuccessLoadText mOnSuccess;
    private OnSuccessLoadStamp mOnLoadStamp;

    public TextStampDynamoDB(DynamoSettings dynamoSetting, OnSuccessLoadText callback, OnSuccessLoadStamp loadStamp) {
        userId = dynamoSetting.getUserId();
        this.dynamoDBMapper = dynamoSetting.getDynamoDBMapper();
        mOnSuccess = callback;
        mOnLoadStamp = loadStamp;
    }

    public String getUserId() { return userId; }

    public void addTextStamp(final TextStampDO textStampDO) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                dynamoDBMapper.save(textStampDO);
            }
        }).start();
    }

    public void addCardStamp(final CardStamp cardStamp) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                dynamoDBMapper.save(cardStamp);
            }
        }).start();
    }

    public void delete(final TextStampDO textStampDO) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                dynamoDBMapper.delete(textStampDO);
            }
        }).start();
    }

    public void deleteCardStamp(final CardStamp cardStamp) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                dynamoDBMapper.delete(cardStamp);
            }
        }).start();
    }

    public void getAllTextStamp() {
        TextStampDO textStamp = new TextStampDO();
        textStamp.setUserId(userId);
        new LoadTask().execute(textStamp);
    }

    public void getAllCardStamp() {
        CardStamp cardStamp = new CardStamp();
        cardStamp.setUserId(userId);
        new LoadStamp().execute(cardStamp);
    }

    @SuppressLint("StaticFieldLeak")
    private class LoadTask extends AsyncTask<TextStampDO, Void, List<TextStampDO>> {

        LoadTask() {

        }

        @Override
        protected List<TextStampDO> doInBackground(TextStampDO... textStampDOS) {

            TextStampDO partitionKey = new TextStampDO();
            partitionKey.setUserId(getUserId());
            DynamoDBQueryExpression<TextStampDO> queryExpression = new DynamoDBQueryExpression<TextStampDO>()
                    .withHashKeyValues(partitionKey);

            List<TextStampDO> itemList = dynamoDBMapper.query(TextStampDO.class, queryExpression);
            return itemList;
        }

        @Override
        protected void onPostExecute(List<TextStampDO> textStampDOS) {
            mOnSuccess.onSuccessLoadText(textStampDOS);
        }
    }

    public interface OnSuccessLoadText {
        void onSuccessLoadText(List<TextStampDO> textStampDOS);

    }

    public interface OnSuccessLoadStamp {
        void onSuccessLoadStamp(List<CardStamp> cardStamps);
    }


    public class LoadStamp extends AsyncTask<CardStamp, Void, List<CardStamp>> {

        LoadStamp() {

        }

        @Override
        protected List<CardStamp> doInBackground(CardStamp... cardStamps) {
            CardStamp cardStampKey = new CardStamp();
            cardStampKey.setUserId(getUserId());
            DynamoDBQueryExpression<CardStamp> queryExpression = new DynamoDBQueryExpression<CardStamp>()
                    .withHashKeyValues(cardStampKey);

            List<CardStamp> itemList = dynamoDBMapper.query(CardStamp.class, queryExpression);


            return itemList;
        }

        @Override
        protected void onPostExecute(List<CardStamp> cardStamps) {
            mOnLoadStamp.onSuccessLoadStamp(cardStamps);
        }


    }


}
