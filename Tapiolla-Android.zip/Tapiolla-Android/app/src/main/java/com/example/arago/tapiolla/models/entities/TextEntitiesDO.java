package com.example.arago.tapiolla.models.entities;


import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMarshalling;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;
import com.example.arago.tapiolla.models.marshaller.FontMarshaller;
import com.example.arago.tapiolla.motion_views.viewmodel.Font;

@DynamoDBTable(tableName = "tapiolla-mobilehub-396882117-textEntities")

public class TextEntitiesDO {
    private String _userId;
    private String _textEntityId;
    private String _cardId;
    private Font _font;
    private String _content;
    private String _rotationInDegrees;
    private String _scale;
    private String _x;
    private String _y;


    @DynamoDBHashKey(attributeName = "userId")
    @DynamoDBIndexHashKey(attributeName = "userId", globalSecondaryIndexName = "user_card")
    public String getUserId() {
        return _userId;
    }

    public void setUserId(final String _userId) {
        this._userId = _userId;
    }
    @DynamoDBRangeKey(attributeName = "textEntityId")
    @DynamoDBIndexHashKey(attributeName = "textEntityId", globalSecondaryIndexName = "item_card")
    public String getTextEntityId() {
        return _textEntityId;
    }

    public void setTextEntityId(final String _textEntityId) {
        this._textEntityId = _textEntityId;
    }
    @DynamoDBIndexRangeKey(attributeName = "cardId", globalSecondaryIndexNames = {"user_card","item_card",})
    public String getCardId() {
        return _cardId;
    }

    public void setCardId(final String _cardId) {
        this._cardId = _cardId;
    }
    @DynamoDBMarshalling(marshallerClass = FontMarshaller.class)
    public Font getFont() { return _font; }
    public void setFont(Font _font) { this._font = _font; }

    @DynamoDBAttribute(attributeName = "content")
    public String getContent() {
        return _content;
    }
    public void setContent(final String _content) {
        this._content = _content;
    }
    @DynamoDBAttribute(attributeName = "rotationInDegrees")
    public String getRotationInDegrees() {
        return _rotationInDegrees;
    }

    public void setRotationInDegrees(final String _rotationInDegrees) {
        this._rotationInDegrees = _rotationInDegrees;
    }
    @DynamoDBAttribute(attributeName = "scale")
    public String getScale() {
        return _scale;
    }

    public void setScale(final String _scale) {
        this._scale = _scale;
    }
    @DynamoDBAttribute(attributeName = "x")
    public String getX() {
        return _x;
    }

    public void setX(final String _x) {
        this._x = _x;
    }
    @DynamoDBAttribute(attributeName = "y")
    public String getY() {
        return _y;
    }

    public void setY(final String _y) {
        this._y = _y;
    }

}

