package com.example.arago.tapiolla.controller.card;

public class SaveCard {
}
