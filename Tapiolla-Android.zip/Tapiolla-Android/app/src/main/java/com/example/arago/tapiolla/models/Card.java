package com.example.arago.tapiolla.models;

import android.graphics.Bitmap;

public class Card {
    private CardsDO cardsDO;
    private Bitmap cardBitmap;

    public Card(CardsDO cardsDO, Bitmap cardBitmap) {
        this.cardsDO = cardsDO;
        this.cardBitmap = cardBitmap;
    }

    public CardsDO getCardsDO() {
        return cardsDO;
    }

    public void setCardsDO(CardsDO cardsDO) {
        this.cardsDO = cardsDO;
    }

    public Bitmap getCardBitmap() {
        return cardBitmap;
    }

    public void setCardBitmap(Bitmap cardBitmap) {
        this.cardBitmap = cardBitmap;
    }
}
