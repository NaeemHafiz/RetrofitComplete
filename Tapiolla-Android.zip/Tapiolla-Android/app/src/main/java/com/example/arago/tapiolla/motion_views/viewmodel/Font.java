package com.example.arago.tapiolla.motion_views.viewmodel;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBDocument;

@DynamoDBDocument
public class Font {

    /**
     * color value (ex: 0xFF00FF)
     */
    private int _color;
    /**
     * name of the font
     */
    private String _typeface;
    /**
     * size of the font, relative to parent
     */
    private float _size;


    public void increaseSize(float diff) {
        _size = _size + diff;
    }

    public void decreaseSize(float diff) {
        if (_size - diff >= Limits.MIN_FONT_SIZE) {
            _size = _size - diff;
        }
    }
    @DynamoDBAttribute(attributeName = "color")
    public int getColor() {
        return _color;
    }
    public void setColor(int color) {
        this._color = color;
    }

    @DynamoDBAttribute(attributeName = "typeFace")
    public String getTypeface() {
        return _typeface;
    }
    public void setTypeface(String typeface) {
        this._typeface = typeface;
    }

    @DynamoDBAttribute(attributeName = "size")
    public float getSize() {
        return _size;
    }
    public void setSize(float size) {
        this._size = size;
    }

    private interface Limits {
        float MIN_FONT_SIZE = 0.01F;
    }
}