package com.example.arago.tapiolla.models.entities;

public class TextFont {
}
