package com.example.arago.tapiolla.models.marshaller;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMarshaller;
import com.example.arago.tapiolla.motion_views.viewmodel.Font;

public class FontMarshaller implements DynamoDBMarshaller<Font>
{
//    public FontMarshaller() {
//    }

    @Override
    public String marshall(Font font) {
        String s= "";
        s += String.valueOf(font.getColor()) + "@";
        s += font.getTypeface() + "@";
        s += String.valueOf(font.getSize());
        return s;
    }

    @Override
    public Font unmarshall(Class<Font> clazz, String s) {
        String[] fontProp = s.split("@");
        String color = fontProp[0];
        String typeFace = fontProp[1];
        String size = fontProp[2];
        Font newFont = new Font();
        newFont.setColor(Integer.parseInt(color));
        newFont.setSize(Float.parseFloat(size));
        newFont.setTypeface(typeFace);
        return newFont;
    }
}
