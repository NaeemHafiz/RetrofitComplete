package com.example.arago.tapiolla.s3;
/**
 * @author dao cuong Thinh
 * This class perform video interaction with S3
 */

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;

import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility;
import com.amazonaws.services.s3.AmazonS3Client;
import com.example.arago.tapiolla.controller.video.VideoFunctions;
import static com.example.arago.tapiolla.Constant.*;

import java.io.File;

public class VideoS3 {
    Context context;
    TransferUtility transferUtility;
    private AmazonS3Client s3Client;

    public VideoS3(Context context) {
        this.context = context;

        this.s3Client = new AmazonS3Client(AWSMobileClient.getInstance().getCredentialsProvider());
        transferUtility =
                TransferUtility.builder()
                        .context(context)
                        .awsConfiguration(AWSMobileClient.getInstance().getConfiguration())
                        .s3Client(s3Client)
                        .build();
    }

    /**
     * This function upload video to s3
     * @param uri / the uri get from onActivityResult
     */
    public void uploadVideoS3(final Context context, Uri uri) {
        if (uri != null) {
            final String fileName = String.valueOf(System.currentTimeMillis());
            final File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                    "/" + fileName);

            VideoFunctions.createFile(context, uri, file);
            final String fileExtention =  VideoFunctions.getFileExtension(context, uri);
            final String url = PREFIX_URL + VIDEO_FOLDER + "/" + fileName +"."+ fileExtention;
            TransferObserver uploadObserver =
                    transferUtility.upload( VIDEO_FOLDER + "/" + fileName + "." + fileExtention, file);
            uploadObserver.setTransferListener(new TransferListener() {

                @Override
                public void onStateChanged(int id, TransferState state) {
                    if (TransferState.COMPLETED == state) {
                        //Broadcast the result
                        Intent broadcast = new Intent();

                        broadcast.setAction(UPLOAD_VIDEO_S3_COMPLETED);
                        broadcast.putExtra(EXTRA_URL_DATA,url );

                        context.sendBroadcast(broadcast);
                    }
                }

                @Override
                public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {

                }

                @Override
                public void onError(int id, Exception ex) {

                }
            });
        }

    }



}
