package com.example.arago.tapiolla.models;

import android.graphics.Bitmap;

import java.io.Serializable;

public class Image implements Serializable {
    private String imageUrl;
    private Bitmap imageBitmap;

    public Image(String imageUrl, Bitmap imageBitmap) {
        this.imageUrl = imageUrl;
        this.imageBitmap = imageBitmap;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Bitmap getImageBitmap() {
        return imageBitmap;
    }

    public void setImageBitmap(Bitmap imageBitmap) {
        this.imageBitmap = imageBitmap;
    }
}
