package com.example.arago.tapiolla.adapter;

import android.graphics.Bitmap;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.arago.tapiolla.R;

import java.util.ArrayList;

public class CardRecyclerAdapter extends RecyclerView.Adapter<CardRecyclerAdapter.ViewHolder>{
    private ArrayList<Bitmap> cardList = new ArrayList<>();
    final String TAG = "CardRecyclerAdapter";
    ItemClickListener itemClickListener;

    public CardRecyclerAdapter(ArrayList<Bitmap> cards){
        //Log.d(TAG,"CardRecyclerAdapter: size: " + cards.size());
        this.cardList = cards;
    }

    public void setData(ArrayList<Bitmap> cardList) {
        this.cardList = cardList;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Log.d(TAG,"onCreateViewHolder: called");
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_layout,parent,false);
        final ViewHolder holder = new ViewHolder(view);
        return holder;

    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
                //Log.d(TAG,"ID: " + cardList.get(position));
                if(cardList != null)
                    holder.cardImage.setImageBitmap(cardList.get(position));
                else
                    holder.cardImage.setImageResource(R.drawable.testimage);

    }

    @Override
    public int getItemCount() {
        if(cardList != null)
            return cardList.size();
        else
            return 1;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements ItemClickListener{
        ImageView cardImage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardImage = itemView.findViewById(R.id.cardImage);
        }

        @Override
        public void onItemClick(View view, int position) {
            if (itemClickListener != null) itemClickListener.onItemClick(view, getAdapterPosition());
        }

        @Override
        public void onItemLongClick(View view, int position) {
            if (itemClickListener != null) itemClickListener.onItemLongClick(view, getAdapterPosition());
        }
    }

    public void setClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }



}
