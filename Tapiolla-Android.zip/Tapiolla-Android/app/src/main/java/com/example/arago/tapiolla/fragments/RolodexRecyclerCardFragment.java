package com.example.arago.tapiolla.fragments;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearSnapHelper;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SnapHelper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.azoft.carousellayoutmanager.CarouselLayoutManager;
import com.azoft.carousellayoutmanager.CarouselZoomPostLayoutListener;
import com.azoft.carousellayoutmanager.CenterScrollListener;
import com.azoft.carousellayoutmanager.DefaultChildSelectionListener;
import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.adapter.CardNameRecyclerAdapter;
import com.example.arago.tapiolla.adapter.CardRecyclerAdapter;
import com.example.arago.tapiolla.adapter.ItemClickListener;
import com.example.arago.tapiolla.adapter.RecyclerTouchListener;
import com.example.arago.tapiolla.controller.ClickableHelper;
import com.example.arago.tapiolla.controller.PopUP;
import com.example.arago.tapiolla.models.CardsDO;
import com.example.arago.tapiolla.ui.MenuScreen;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link RolodexRecyclerCardFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link RolodexRecyclerCardFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class RolodexRecyclerCardFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private ArrayList<Bitmap> mCardList;//businesscard list
    private ArrayList<CardsDO> mCardsDOList;
    private ArrayList<String> nameList = new ArrayList<>();
    private int centerPosition = 0;

    RecyclerView mRecyclerView, nameRecyclerView;
    CardRecyclerAdapter mCardAdapter;
    CardNameRecyclerAdapter mNameRecycler;
    CarouselLayoutManager layoutManager;
    SnapHelper snapHelper;
    private OnFragmentInteractionListener mListener;

    public RolodexRecyclerCardFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param mCardList Parameter 1.
     * @return A new instance of fragment RolodexRecyclerCardFragment.
     */
    public static RolodexRecyclerCardFragment newInstance(ArrayList<Bitmap> mCardList, ArrayList<CardsDO> mCardsDOList) {
        RolodexRecyclerCardFragment fragment = new RolodexRecyclerCardFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PARAM1, mCardList);
        args.putSerializable(ARG_PARAM2, mCardsDOList);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mCardList = (ArrayList<Bitmap>) getArguments().getSerializable(ARG_PARAM1);
            mCardsDOList = (ArrayList<CardsDO>) getArguments().getSerializable(ARG_PARAM2);

            //mCardAdapter.notifyDataSetChanged();
        }
        //setRetainInstance(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        char[] alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();

        for (char letter : alphabet) {
            String let = String.valueOf(letter);
            nameList.add(let);
        }
        nameList.add("Others");

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_rolodex_recycler_card, container, false);


    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        final Dialog dialog = new Dialog(getActivity());
        //Set RecyclerView
        mCardAdapter = new CardRecyclerAdapter(mCardList);
        mRecyclerView = view.findViewById(R.id.rolodex_recycler_view);
        layoutManager = new CarouselLayoutManager(CarouselLayoutManager.VERTICAL,true);
        layoutManager.setPostLayoutListener(new CarouselZoomPostLayoutListener());
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.addOnScrollListener(new CenterScrollListener());
        mRecyclerView.setAdapter(mCardAdapter);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                mListener.centerPoistion(layoutManager.getCenterItemPosition());
            }
        });
        snapHelper = new LinearSnapHelper() ;
        snapHelper.attachToRecyclerView(mRecyclerView);

//        DefaultChildSelectionListener.initCenterItemListener(new DefaultChildSelectionListener.OnCenterItemClickListener() {
//            @Override
//            public void onCenterItemClicked(@NonNull RecyclerView recyclerView, @NonNull CarouselLayoutManager carouselLayoutManager, @NonNull View v) {
//                //Log.d(TAG, "onItemLongClick: MenuScreen");
//                int position = carouselLayoutManager.getCenterItemPosition();
//                PopUP popUP = new PopUP(getContext());
//                popUP.openRolodexPopup(dialog, mCardList.get(position), mCardsDOList.get(position));
//            }
//        }, mRecyclerView, layoutManager);


        mRecyclerView.addOnItemTouchListener(new RecyclerTouchListener(getContext(),
                mRecyclerView, new ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                PopUP popUP = new PopUP(getContext());
                popUP.openRolodexPopup(dialog, mCardList.get(position), mCardsDOList.get(position));
            }

            @Override
            public void onItemLongClick(View view, int position) {
                //PopUP.openShareCardOffline(MenuScreen.this, view, mCardList.get(position), mCardListDetails.get(position));
                mListener.onItemDrag(view, position, mCardList.get(position));
            }
        }));

        // name recycler view
        mNameRecycler = new CardNameRecyclerAdapter(getContext(), nameList);
        ItemClickListener  itemClickListener = new ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                mListener.onItemNameClick(view, position);

            }

            @Override
            public void onItemLongClick(View view, int position) {

            }
        };
        nameRecyclerView = view.findViewById(R.id.rolodex_cardName);
        mNameRecycler.setClickListener(itemClickListener);
        nameRecyclerView.setLayoutManager(new GridLayoutManager(getContext(), 1));
        nameRecyclerView.setAdapter(mNameRecycler);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public int getRvCenterPosition() {
//        View view =  mRecyclerView.getFocusedChild();
//        mRecyclerView.getChildAdapterPosition(view);

        return centerPosition;
    }
    //    @Override
//    public void onSaveInstanceState(Bundle outState) {
//        super.onSaveInstanceState(outState);
//        //Clear the Activity's bundle of the subsidiary fragments' bundles.
//        outState.clear();
//    }
    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        void onItemNameClick(View view, int postion);
        void onItemDrag(View view, int position, Bitmap bitmap);
        void centerPoistion(int position);
    }
}
