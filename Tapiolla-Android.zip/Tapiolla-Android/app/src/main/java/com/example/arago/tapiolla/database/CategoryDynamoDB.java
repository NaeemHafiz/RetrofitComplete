package com.example.arago.tapiolla.database;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.example.arago.tapiolla.models.CategoriesDO;
import com.example.arago.tapiolla.models.Category;
import com.example.arago.tapiolla.models.UserDO;
import com.example.arago.tapiolla.models.user.UserSettings;
import com.example.arago.tapiolla.ui.Rolodex;

import java.util.ArrayList;
import java.util.UUID;

import static com.example.arago.tapiolla.Constant.DONE_LOAD_USER_CATEGORY;

public class CategoryDynamoDB {
    private Context context;
    private String userId;
    private DynamoDBMapper dynamoDBMapper;


    public CategoryDynamoDB(Context context) {

        userId = DynamoSettings.getUserId();
        this.context = context;
        this.dynamoDBMapper = DynamoSettings.getDynamoDBMapper();
    }

    /**
     *
     * @param categoriesDO category Dynamodb object
     */
    public void saveCategory(final CategoriesDO categoriesDO) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                dynamoDBMapper.save(categoriesDO);
                // Item saved
            }
        }).start();
    }

    /**
     *
     */
    public void loadCategories() {
        new CategoryDynamoDB.LoadCategoryInfoTask().execute();
    }

    /**
     * Asyn task for get user category
     */
    private class LoadCategoryInfoTask extends AsyncTask<Void, Void, CategoriesDO> {
        LoadCategoryInfoTask(){
        }

        @Override
        protected CategoriesDO doInBackground(Void... voids) {
            CategoriesDO result;
            result = dynamoDBMapper.load(CategoriesDO.class, userId);
            return  result;
        }

        protected void onPostExecute(CategoriesDO categoriesDO) {
            Log.i("loadResult", "Loaded");
            // create new if it is null
            createNewCategoryDO(categoriesDO);

            Intent broadCast = new Intent();
            broadCast.setAction(DONE_LOAD_USER_CATEGORY);
            broadCast.putExtra("category_data",categoriesDO);

            context.sendBroadcast(broadCast);

        }
    }

    /**
     * This function create a new category DO if it is null
     */
    private void createNewCategoryDO(CategoriesDO categoriesDO) {
        if(categoriesDO == null) {
            categoriesDO = new CategoriesDO();
            categoriesDO.setUserId(userId);
            final String uuid = UUID.randomUUID().toString();
            categoriesDO.setCategoryId(uuid);
            ArrayList<Category> temp = new ArrayList<>();
            categoriesDO.setCategories(temp);
        }
    }
}
