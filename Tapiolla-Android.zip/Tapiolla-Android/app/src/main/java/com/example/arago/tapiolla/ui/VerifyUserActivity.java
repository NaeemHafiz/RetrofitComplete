package com.example.arago.tapiolla.ui;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.authentication.AWSLoginModel;
import com.example.arago.tapiolla.authentication.AWSVerificationHandler;

public class VerifyUserActivity extends AppCompatActivity implements AWSVerificationHandler {
    EditText veriCode, email;
    ProgressDialog progressDialog;
    AWSLoginModel awsLoginModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_user);

        awsLoginModel = new AWSLoginModel(this,  this);

        progressDialog = new ProgressDialog(this);
        veriCode = findViewById(R.id.veriCode);
        Intent intent = getIntent();
        final String emailAddress = intent.getExtras().getString("emailAddress");
        final TextView em = findViewById(R.id.verificationInfo);
        em.setText("Check email " + emailAddress + " for verification code");

        Button btnVerify = findViewById(R.id.verify);
        Button btnResend = findViewById(R.id.resendVerificationCode);

        btnResend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                progressDialog.setMessage("Please wait ...");
                progressDialog.show();
                sendCodeAction(emailAddress);
            }
        });
        // set on click for verify button
        btnVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.setMessage("Please wait ...");
                progressDialog.show();
                confirmAction(String.valueOf(veriCode.getText()), emailAddress);

            }
        });
    }

    @Override
    public void onRegisterConfirmed() {
        Toast.makeText(VerifyUserActivity.this, "Registered! Login Now!", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(VerifyUserActivity.this, LoginActivity.class);
        finish();
        startActivity(intent);
    }

    @Override
    public void onFailure(int process, Exception exception) {
        exception.printStackTrace();
        String whatProcess = "";
        switch (process) {
            case AWSLoginModel.PROCESS_SIGN_IN:
                whatProcess = "Sign In:";
                break;
            case AWSLoginModel.PROCESS_REGISTER:
                whatProcess = "Registration:";
                break;
            case AWSLoginModel.PROCESS_CONFIRM_REGISTRATION:
                whatProcess = "Registration Confirmation:";
                break;
        }
        Toast.makeText(VerifyUserActivity.this, whatProcess + exception.getMessage(), Toast.LENGTH_LONG).show();
        progressDialog.dismiss();
    }

    @Override
    public void onSendCodeSuccess() {
        progressDialog.dismiss();
    }

    private void sendCodeAction(String email) {
        // do send code
        awsLoginModel.resendVerificationCode(email);
        Toast.makeText(VerifyUserActivity.this, "We have Sent Code to Email " + email, Toast.LENGTH_LONG).show();
    }

    private void confirmAction(String code, String email) {
        // do confirmation and handles on interface
        awsLoginModel.confirmRegistration(code, email);
    }

}
