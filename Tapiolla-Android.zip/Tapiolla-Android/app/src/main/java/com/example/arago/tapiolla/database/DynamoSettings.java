package com.example.arago.tapiolla.database;

import android.content.Context;
import android.util.Log;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.mobile.auth.core.IdentityManager;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.config.AWSConfiguration;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.facebook.AccessToken;

public class DynamoSettings {
    //Context context;
    private static DynamoDBMapper dynamoDBMapper;
    private static AWSCredentialsProvider credentialsProvider;
    private static String userId;


    public DynamoSettings() {
        //this.context = context;

        userId = IdentityManager.getDefaultIdentityManager().getCachedUserID();

        //      AWSMobileClient.getInstance().initialize(context).execute();
        AWSMobileClient mobileClient = AWSMobileClient.getInstance();

        AWSCredentialsProvider credentialsProvider = mobileClient.getCredentialsProvider();

        AmazonDynamoDBClient dynamoDBClient = new AmazonDynamoDBClient(credentialsProvider);
        dynamoDBMapper = DynamoDBMapper.builder()
                .dynamoDBClient(dynamoDBClient)
                .awsConfiguration(mobileClient.getConfiguration())
                .build();
    }

    public static DynamoDBMapper getDynamoDBMapper() {
        return dynamoDBMapper;
    }

    public static String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }



}