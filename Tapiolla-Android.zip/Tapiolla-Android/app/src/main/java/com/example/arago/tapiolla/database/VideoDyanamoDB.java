package com.example.arago.tapiolla.database;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBQueryExpression;
import com.example.arago.tapiolla.models.ImagesDO;
import com.example.arago.tapiolla.models.VideosDO;
import static com.example.arago.tapiolla.Constant.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class VideoDyanamoDB {
    private static DynamoDBMapper dynamoDBMapper;
    private static String userId;

    /**
     *
     */
    public VideoDyanamoDB() {
        //   this.dynamoSettings = dynamoSettings;

        userId = DynamoSettings.getUserId();
        dynamoDBMapper = DynamoSettings.getDynamoDBMapper();

    }

    /**
     * This function save new video to DB
     * @param videosDO object
     */
    public void saveNewVideoToDB(final VideosDO videosDO) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                dynamoDBMapper.save(videosDO);
                // Item saved
            }
        }).start();
    }

    /**
     * This function get all the video info from the database
     */
    public void getAllVideos(Context context) {
        VideosDO template = new VideosDO();
        template.setUserId(userId);
        new LoadVideoTask(context).execute(template);

    }

    private static class LoadVideoTask extends AsyncTask<VideosDO, Void, List<VideosDO>> {
        private Context context;
        LoadVideoTask(Context context){
            this.context = context;
        }

        @Override
        protected List<VideosDO> doInBackground(VideosDO... videosDOS) {

            DynamoDBQueryExpression<VideosDO> queryExpression = new DynamoDBQueryExpression<VideosDO>();
            queryExpression.setHashKeyValues(videosDOS[0]);

            List<VideosDO> awsqlist = dynamoDBMapper.query(VideosDO.class, queryExpression);

            return awsqlist;
        }

        protected void onPostExecute(List<VideosDO> result) {

            ArrayList<VideosDO> arrayList = new ArrayList<VideosDO>(result);
            //Broadcast the result
            Intent broadcast = new Intent();

            broadcast.setAction(LOAD_VIDEO_INFO_DONE);
            broadcast.putExtra(EXTRA_VIDEO_INFO, arrayList);

            context.sendBroadcast(broadcast);
        }
    }
}
