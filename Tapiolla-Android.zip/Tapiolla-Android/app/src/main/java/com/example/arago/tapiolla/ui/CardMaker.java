package com.example.arago.tapiolla.ui;


import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.amazonaws.mobile.auth.core.IdentityManager;
import com.amazonaws.mobile.auth.core.StartupAuthResult;
import com.amazonaws.mobile.auth.core.StartupAuthResultHandler;
import com.amazonaws.mobile.auth.facebook.FacebookSignInProvider;
import com.amazonaws.mobile.auth.google.GoogleSignInProvider;
import com.amazonaws.mobile.auth.userpools.CognitoUserPoolsSignInProvider;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.AWSStartupHandler;
import com.amazonaws.mobile.client.AWSStartupResult;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.arago.tapiolla.BuildConfig;
import com.example.arago.tapiolla.Constant;
import com.example.arago.tapiolla.Utils.DownloadImages;
import com.example.arago.tapiolla.Utils.GetIndex;
import com.example.arago.tapiolla.Utils.InitItems;
import com.example.arago.tapiolla.adapter.CardRecyclerAdapter;
import com.example.arago.tapiolla.adapter.FieldEntryAdapter;
import com.example.arago.tapiolla.adapter.ImageRecyclerAdapter;
import com.example.arago.tapiolla.adapter.ItemClickListener;
import com.example.arago.tapiolla.adapter.MyRecyclerAdapter;
import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.adapter.VideoRecyclerAdapter;
import com.example.arago.tapiolla.controller.video.VideoFunctions;
import com.example.arago.tapiolla.convertion.BusinessCard;
import com.example.arago.tapiolla.convertion.ConvertObject;
import com.example.arago.tapiolla.convertion.RecreateCard;
import com.example.arago.tapiolla.database.CardDynamoDB;
import com.example.arago.tapiolla.database.DatabaseInterface;
import com.example.arago.tapiolla.database.DynamoSettings;
import com.example.arago.tapiolla.database.HyperlinkDynamoDB;
import com.example.arago.tapiolla.database.ImagesDynamoDB;
import com.example.arago.tapiolla.database.VideoDyanamoDB;
import com.example.arago.tapiolla.models.Card;
import com.example.arago.tapiolla.database.TextStampDynamoDB;
import com.example.arago.tapiolla.models.Image;
import com.example.arago.tapiolla.models.VideosDO;
import com.example.arago.tapiolla.models.hyperlinks.Hyperlink;
import com.example.arago.tapiolla.models.hyperlinks.SocialMedia;
import com.example.arago.tapiolla.models.stamp.CSImageEntity;
import com.example.arago.tapiolla.models.stamp.CSTextEntity;
import com.example.arago.tapiolla.models.stamp.CardStamp;
import com.example.arago.tapiolla.models.CardsDO;
import com.example.arago.tapiolla.models.ImagesDO;
import com.example.arago.tapiolla.models.stamp.TextStampDO;
import com.example.arago.tapiolla.models.user.Video;
import com.example.arago.tapiolla.motion_views.adapter.FontsAdapter;
import com.example.arago.tapiolla.motion_views.text_ui.TextEditorDialogFragment;
import com.example.arago.tapiolla.motion_views.utils.FontProvider;
import com.example.arago.tapiolla.motion_views.viewmodel.Font;
import com.example.arago.tapiolla.motion_views.viewmodel.Layer;
import com.example.arago.tapiolla.motion_views.viewmodel.TextLayer;
import com.example.arago.tapiolla.motion_views.widget.MotionView;
import com.example.arago.tapiolla.motion_views.widget.entity.ImageEntity;
import com.example.arago.tapiolla.motion_views.widget.entity.MotionEntity;
import com.example.arago.tapiolla.motion_views.widget.entity.TextEntity;
import com.example.arago.tapiolla.s3.ImageS3;
import com.example.arago.tapiolla.s3.VideoS3;
import com.flask.colorpicker.ColorPickerView;
import com.flask.colorpicker.builder.ColorPickerClickListener;
import com.flask.colorpicker.builder.ColorPickerDialogBuilder;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfAction;
import com.itextpdf.text.pdf.PdfAnnotation;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;


import org.adw.library.widgets.discreteseekbar.DiscreteSeekBar;

import java.io.ByteArrayOutputStream;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;


import static android.widget.Toast.LENGTH_LONG;
import static com.example.arago.tapiolla.Constant.*;
import static java.security.AccessController.getContext;

public class CardMaker extends AppCompatActivity implements View.OnClickListener, MyRecyclerAdapter.ItemClickListener,
        TextEditorDialogFragment.OnTextLayerCallback,
        ImagesDynamoDB.OnSuccessLoadDynamo, ImageS3.OnSuccessS3,
        TextStampDynamoDB.OnSuccessLoadText, CardDynamoDB.OnSuccessCardsThumbnail,
        RecreateCard.OnSuccessCreateCard, FieldEntryAdapter.OnUpdateTextStamp,
        TextStampDynamoDB.OnSuccessLoadStamp, HyperlinkDynamoDB.OnSuccessLoadHyperlink
{


    public static final String TAG = "CardMaker";
    public static final String defaultText = "Tapiolla";
    public static final int GET_VIDEO_STORAGE = 102;
    public static final int GET_PHOTO_DEVICE = 103;
    public static final int GET_PHOTO_STORAGE = 104;
    public static final String OVERLAY_URL_PREFIX = "https://tapiolla-userfiles-mobilehub-396882117.s3.us-east-2.amazonaws.com/CardOverlays/";
    public static final String BACKGROUND_URL_PREFIX = "https://tapiolla-userfiles-mobilehub-396882117.s3.us-east-2.amazonaws.com/CardBackgrounds/";

    public boolean mPermissionsGranted = false;

    String [] permissions = Constant.permissions;

    InitItems initItems = new InitItems();
    ImageView template, background, text, camera, social_media, card_stamp;

    //Drawable Images
    List<Integer> mListSocialMedia, mListTemplate, mListText, mListCardStamp, mListCopyStamp;
    ArrayList<Image> mListBacksplash, mListBackground;
    ArrayList<Bitmap> mListCards,  mListPhoto;

    List<BusinessCard> mBusinessCard = new ArrayList<>(); // business card object
    RecyclerView recyclerView;
    MyRecyclerAdapter recyclerAdapter;
    ImageRecyclerAdapter imageRecyclerAdapter;
    MyRecyclerAdapter.ItemClickListener itemClickListener;
    VideoRecyclerAdapter videoRecyclerAdapter;
    /* Adapter for CardStamp */
    RecyclerView cardStampRecyclerView;
    FieldEntryAdapter cardStampRecyclerAdapter;
    boolean isCardStampActive = false;
    boolean saveCheckedItems = false;

    //Texts added to text stamp
    List<TextStampDO> mCardStamp = new ArrayList<>();
    List<TextStampDO> mCheckedCardStamp = new ArrayList<>();
    List<Bitmap> mCardStampBmp = new ArrayList<>();
    List<BusinessCard> mCardStampBusinessCard = new ArrayList<>();

    //Card Stamp Variables
    List<TextStampDO> mTextStampDo = new ArrayList<>();
    List<TextStampDO> mCsFname = new ArrayList<>();
    List<TextStampDO> mCsLname = new ArrayList<>();
    List<TextStampDO> mCsTitle = new ArrayList<>();
    List<TextStampDO> mCsAddress = new ArrayList<>();
    List<TextStampDO> mCsEmail = new ArrayList<>();
    List<TextStampDO> mCsPhone = new ArrayList<>();
    List<TextStampDO> mCsWeblink = new ArrayList<>();
    List<SocialMedia> mCheckedSocialMedia = new ArrayList<>();

    List<CardStamp> mCardStampItems = new ArrayList<>();

    //Social Media Links
    String socialMediaName = "";
    List<SocialMedia> mSocialMedia = new ArrayList<>();
    List<SocialMedia> mSmFacebook = new ArrayList<>();
    List<SocialMedia> mSmGoogle = new ArrayList<>();
    List<SocialMedia> mSmInstagram = new ArrayList<>();
    List<SocialMedia> mSmLinkedIn = new ArrayList<>();
    List<SocialMedia> mSmEmail = new ArrayList<>();
    List<SocialMedia> mSmPinterest = new ArrayList<>();
    List<SocialMedia> mSmSkype = new ArrayList<>();
    List<SocialMedia> mSmTumblr = new ArrayList<>();
    List<SocialMedia> mSmTwitter = new ArrayList<>();
    List<SocialMedia> mSmWhatsapp = new ArrayList<>();

    Set<String> mSmDuplicateType = new HashSet<>();


    FrameLayout cardStampFrameLayout; //Layout used for cardstamp
    TextView cardStampAdd; //AddNew button in card stamp layout

    boolean isCanvasEmpty = true;

    int rowNum = 1;
    int CURRENT_TAB = 0;

    //history tracker undo and redo
    ArrayList<Integer> lastMove = new ArrayList<>(); // Track all moves
    ArrayList<Integer> undoLastMove = new ArrayList<>(); // undo moves
    boolean lastMoveIsDelete = false;//undo/redo

    List<Image> backsplashList = new ArrayList<>(); // backsplash list
    List<Image> undoBacksplash = new ArrayList<>(); // item list of backsplash that's been undone/redone
    List<Image> backgroundList = new ArrayList<>(); // background list
    List<Image> undoBackground = new ArrayList<>(); // item list of backgrounds that's been undone/redone


    List<MotionEntity> motionEntityList = new ArrayList<>();// motion entity
    List<MotionEntity> undoMotionEntityList = new ArrayList<>();
    List<Integer> colorList = new ArrayList<>(); // color
    List<Integer> undoColorList = new ArrayList<>();
    List<String> typeFaceList = new ArrayList<>();// typeface
    List<String> undoTypeList = new ArrayList<>();

    MotionEntity selectedEntity;
    /*
    multiFuncBtn
    Switch recycler views for each button option.
    1. TemplateMenu - Toggle from my cards and template.
    2. BackgroundMenu - Toggle from background to backsplash
    3. Photos - Toggle from Photos to Videos
    4. Facebook - Toggle to link / Invisible
    6. Card Stamp - Stamp / Info
     */
    Button multiFuncBtn;
    /*
        Add Btn
     */
    ImageView addBtn;

    /* UndoRedo, Layer, Duplicate, delete -Side Menus*/
    ImageView undoRedo, layer, duplicate, delete, opacity;
    Button save;

    /*
        thirdFrame - Options menu (Undo / Redo / Opacity / Layers / Delete)
        seekBarFrame - Frame layout for seekbar
     */
    FrameLayout thirdFrame, seekbarFrame;
    DiscreteSeekBar opacitySeekbar;

    /* Edit Items */
    FrameLayout canvas, canvasParent; // main canvas
    ImageView backgroundImage, dummyBackground; //background
    ImageView backsplashImage; // backsplash
    MotionView motionView, cardStampMotionView; // Texts and Images
    /* Add to Background variable */
    boolean isAddToBackground = false;

    /* */
    boolean callSaveCardMenu = false;
    int currentCardPosition = 0;
    CardsDO currentCardDO;
    private FontProvider fontProvider;
    //Callback for entity.
    private final MotionView.MotionViewCallback motionViewCallback = new MotionView.MotionViewCallback() {
        @Override
        public void onEntitySelected(@Nullable MotionEntity entity) {
            if (entity instanceof TextEntity) {
//                CURRENT_TAB = C_TEXT;
//                text = findViewById(R.id.textBtn);
//                toggleButons();
//                text.setImageResource(R.drawable.highlighted_text);
//                initText();
//                initTextClickListener();

            }
        }
        @Override
        public void onEntityDoubleTap(@NonNull MotionEntity entity) {
            //startTextEntityEditing();
            startTextEntityEditing();
        }

        @Override
        public void onEntityDeselect(boolean selected) {
            if(!selected) {
                seekBarInvisible();
            }
        }
    };

    private ProgressDialog progressDialog;
    //save the current user id
    String userId;
    // This object for all the interaction with the image table in dynamodb
    ImagesDynamoDB imagesDynamoDB;
    VideoDyanamoDB videoDyanamoDB;

    //this list store all the properties of all the downloaded images from dynamodb
    List<ImagesDO> imagesList;
    // dynamo seeting
    DynamoSettings dynamoSettings;
    // card dynamo object
    CardDynamoDB cardDynamoDB;
    //use for the list of saved cards
    List<CardsDO> listCards;
    List<Card> listCardsWithThumbnail;
    List<VideosDO> listVideosDO;
    ArrayList<Video> listVideosWithThumbnail; // List video object contains video information and bitmap thumbnail of video
    //
    TextStampDynamoDB textStampDynamoDB;
    List<TextStampDO> textStampDOList;

    //
    HyperlinkDynamoDB hyperlinkDynamoDB;
    List<Hyperlink> mHyperlinks;
    ImageS3 imageS3;
    VideoS3 videoS3;
    //this variable for saving all props of the current card
    BusinessCard currentBussinessCard;

    BroadcastReceiver broadcastReceiver;
    boolean isLoadVideo = false;
    ItemClickListener videoitemClickListener;
    ItemClickListener imageItemClick;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_maker);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        //getSupportActionBar().hide();

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Loading...");

        //initialize the setting for dynamoDb
        dynamoSettings = new DynamoSettings( );

        //initialize Image - Dynamodb mapper
        imagesDynamoDB = new ImagesDynamoDB(this);
        videoDyanamoDB = new VideoDyanamoDB();
        imageS3 = new ImageS3(this, imagesDynamoDB, this);
        videoS3 = new VideoS3(getApplicationContext());

        cardDynamoDB = new CardDynamoDB(getApplicationContext(), this);
        userId = DynamoSettings.getUserId();

        currentBussinessCard = new BusinessCard();

        textStampDynamoDB = new TextStampDynamoDB(dynamoSettings, this, this);
        textStampDOList = new ArrayList<TextStampDO>();

        hyperlinkDynamoDB = new HyperlinkDynamoDB(dynamoSettings, this);
        mHyperlinks = new ArrayList<Hyperlink>();

        // load all resources
        imagesDynamoDB.getAllImages();
        // intialize lists
        imagesList = new ArrayList<ImagesDO>();
        listCards = new ArrayList<CardsDO>();
        listCardsWithThumbnail = new ArrayList<>();
        listVideosDO = new ArrayList<>();
        listVideosWithThumbnail = new ArrayList<>();

        template = findViewById(R.id.templatesBtn);
        background = findViewById(R.id.backgroundBtn);
        text = findViewById(R.id.textBtn);
        camera = findViewById(R.id.cameraBtn);
        social_media = findViewById(R.id.socialmediaBtn);
        card_stamp = findViewById(R.id.cardStampBtn);
        multiFuncBtn = findViewById(R.id.multiFuncBtn);
        multiFuncBtn.setText(R.string.multifunc_my_cards);
        addBtn = findViewById(R.id.addBtn);

        /* Bottom Options Main Menu */
        template.setOnClickListener(this);
        background.setOnClickListener(this);
        text.setOnClickListener(this);
        camera.setOnClickListener(this);
        social_media.setOnClickListener(this);
        card_stamp.setOnClickListener(this);

        undoRedo = findViewById(R.id.undoRedo);
        layer = findViewById(R.id.layer);
        duplicate = findViewById(R.id.duplicate);
        delete = findViewById(R.id.delete);

        /* Initial items for undo*/
        Bitmap emptycanvas = BitmapFactory.decodeResource(getResources(),
                R.drawable.empty_canvas);

        backgroundList.add(new Image(null, emptycanvas));
        //TODO: set the 1 overlay
        Bitmap transparentOverlay = BitmapFactory.decodeResource(getResources(),
                R.color.transparent);
        backsplashList.add(new Image(null, transparentOverlay));
        colorList.add(Color.BLACK);
        typeFaceList.add("Helvetica");

        /* Right Side Menu */
        undoRedo.setOnClickListener(this);
        layer.setOnClickListener(this);
        duplicate.setOnClickListener(this);
        delete.setOnClickListener(this);

        /* initialize items */
        mListCards = new ArrayList<>();
        mListPhoto = new ArrayList<>();
        initTemplates();
        initBackSplash();
        initBackground();
        initText();
        initSocialMedia();
        initCardStamp();

        cardStampFrameLayout = findViewById(R.id.fieldEntryCanvas);
        cardStampFrameLayout.setBackgroundResource(R.drawable.empty_canvas);
        //cardStampFrameLayout.setVisibility(View.GONE);
        cardStampAdd = findViewById(R.id.field_entry_add);
        cardStampRecyclerView = findViewById(R.id.field_entry_recycler_view);

        cardStampRecyclerAdapter = new FieldEntryAdapter(this, mCsFname,"firstName", dynamoSettings, this);
        cardStampRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        cardStampRecyclerView.setAdapter(cardStampRecyclerAdapter);

        canvas = findViewById(R.id.canvas);
        int height = (int) (getResources().getDisplayMetrics().heightPixels * .60);
        int width = (int) (height * 1.8);
        Log.d(TAG, "onCreate: CARDMAKER: " + width + height);
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(width, height);
        layoutParams.gravity = Gravity.CENTER;
        canvas.setLayoutParams(layoutParams);

        backgroundImage = findViewById(R.id.background);
        dummyBackground = findViewById(R.id.cardStampBackground);
        backsplashImage = findViewById(R.id.backsplash);//back splash

        backgroundImage.setOnClickListener(this);
        backsplashImage.setOnClickListener(this);

        save =  findViewById(R.id.save);

        backsplashImage.setImageResource(R.color.transparent);
        backgroundImage.setImageResource(R.drawable.empty_canvas);

        backsplashImage.setScaleType(ImageView.ScaleType.FIT_XY);
        backgroundImage.setScaleType(ImageView.ScaleType.FIT_XY);
        recyclerView = findViewById(R.id.options_recycler_view);
        motionView = findViewById(R.id.motionView);

        cardStampMotionView = findViewById(R.id.cardStampMotionView);
        cardStampMotionView.setMotionViewCallback(motionViewCallback);
        motionView.setMotionViewCallback(motionViewCallback);

        /* Template Listener - set initial recyler adapter */
        itemClickListener = new MyRecyclerAdapter.ItemClickListener() {
            @Override
            public void onItemClick(View view, final int position) {
                isCanvasEmpty = false;
                Log.d(TAG, "itemClickListener for Templates: clicked : Position: " + position);
                backgroundImage.setImageResource(mListTemplate.get(position));
                lastMove.add(R.string.lastMove_background); // change to lastmove editable later
                //TODO: Check this
                //backgroundList.add(mListTemplate.get(position));
                seekBarInvisible();
            }

            @Override
            public void onItemLongClick(View view, int position) {

            }
        };
        recyclerAdapter = new MyRecyclerAdapter(this, mListTemplate);
        recyclerView.setLayoutManager(new GridLayoutManager(this, rowNum));
        recyclerAdapter.setClickListener(itemClickListener);
        recyclerView.setAdapter(recyclerAdapter);
        /* ==================================================== */

        //Initial Name : My Card, Initial RecyclerView Items : Templates
        multiFuncBtn.setOnClickListener(this);
        addBtn.setOnClickListener(this);
        save.setOnClickListener(this);

        this.fontProvider = new FontProvider(getResources());

        /* Opacity Slider */
        thirdFrame = findViewById(R.id.thirdFrag);
        seekbarFrame = findViewById(R.id.seekbarLayout);
        opacity = findViewById(R.id.opacity);

        seekbarFrame.setVisibility(View.GONE);
        opacitySeekbar = findViewById(R.id.opacitySlider);

        opacitySeekbar.setMax(100);
        opacitySeekbar.setMin(0);
        opacitySeekbar.setProgress(100);

        LinearLayout linearLayout = findViewById(R.id.parent);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                seekBarInvisible();
                opacitySeekbar.setClickable(false);
            }
        });

        opacitySeekbar.setOnProgressChangeListener(new DiscreteSeekBar.OnProgressChangeListener() {
            @Override
            public void onProgressChanged(DiscreteSeekBar seekBar, int value, boolean fromUser) {

                if(motionView.getSelectedEntity() != null) {

                    if(motionView.getSelectedEntity() instanceof  ImageEntity) {
                        Log.d(TAG,"SeekBar Image value " + value);
                        ImageEntity imageEntity = (ImageEntity) motionView.getSelectedEntity();
                        imageEntity.setOpacity(value * 25 / 10);
                        imageEntity.applyOpacity();
                        motionView.invalidate();
                    } else {
                        Log.d(TAG,"SeekBar Text value " + value);
                        TextEntity textEntity = (TextEntity) motionView.getSelectedEntity();
                        textEntity.setOpacity(value * 25 / 10);
                        textEntity.updateEntity();
                        motionView.invalidate();
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(DiscreteSeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(DiscreteSeekBar seekBar) {

            }
        });

        opacity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                seekBarVisible();
                if(motionView.getSelectedEntity() != null) {
                    if(motionView.getSelectedEntity() instanceof  ImageEntity) {
                        ImageEntity imageEntity = (ImageEntity) motionView.getSelectedEntity();
                        opacitySeekbar.setProgress(imageEntity.getOpacity() / 25 * 10);

                    } else {
                        TextEntity textEntity = (TextEntity) motionView.getSelectedEntity();
                        opacitySeekbar.setProgress(textEntity.getOpacity() / 25 * 10);
                    }
                }

            }
        });

        textStampDynamoDB.getAllTextStamp();//user-details
        textStampDynamoDB.getAllCardStamp();//card stamp
        hyperlinkDynamoDB.getHyperlinks();

        broadcastReceiver = new BroadcastReceiver() {
            String videoUrl;
            String videoThumbnailUrl;
            @Override
            public void onReceive(Context context, Intent intent) {
                switch (intent.getAction()){
                    case UPLOAD_VIDEO_S3_COMPLETED :
                        //get data from the intent
                        Log.i("broadcast", String.valueOf(listVideosWithThumbnail.size()));
                        videoUrl =  intent.getStringExtra(EXTRA_URL_DATA);
                        listVideosWithThumbnail.get(listVideosWithThumbnail.size()-1).getVideosDO().setVideoUrl(videoUrl);
                        Log.i("broadcast", "videoUrl1");
                        if(videoThumbnailUrl != null && videoUrl != null){
                            Log.i("broadcast", "videoUrl");
                            // Save to DB
                            VideoFunctions.saveVideoInfoToDynamo(listVideosWithThumbnail.get(listVideosWithThumbnail.size()-1).getVideosDO(), videoDyanamoDB);

                        }
                        break;
                    case UPLOAD_VIDEO_THUMBNAIL_S3_COMPLETED :
                        //get data from the intent
                        Log.i("broadcast", String.valueOf(listVideosWithThumbnail.size()));
                        videoThumbnailUrl =  intent.getStringExtra(EXTRA_THUMBNAIL_URL_DATA);
                        //set data to the list
                        listVideosWithThumbnail.get(listVideosWithThumbnail.size()-1).getVideosDO().setVideoThumbnailUrl(videoThumbnailUrl);

                        if(videoThumbnailUrl != null && videoUrl != null) {
                            Log.i("broadcast", "videoThumbnailUrl");
                            // Save to DB
                            VideoFunctions.saveVideoInfoToDynamo(listVideosWithThumbnail.get(listVideosWithThumbnail.size()-1).getVideosDO(), videoDyanamoDB);
                        }
                        break;
                    case LOAD_VIDEO_INFO_DONE:
                        isLoadVideo = true;
                        ArrayList<VideosDO> temp =(ArrayList<VideosDO>) intent.getSerializableExtra(EXTRA_VIDEO_INFO);
                        // start load Video thumbnail
                        VideoFunctions.downloadImages(getApplicationContext(), temp, new DatabaseInterface() {
                            @Override
                            public void onLoadVideoThumbnailDone(Video video) {
                                listVideosWithThumbnail.add(video);
                                videoRecyclerAdapter.setmClickListener(videoitemClickListener);
                                videoRecyclerAdapter.notifyDataSetChanged();
                            }
                        });
                        break;
                    case LOAD_SINGLE_VIDEO_INFO_DONE:
                        break;
                    case DONE_LOAD_OVERLAYS:

                        break;
                }
            }
        };
        //create video adapter for video
        videoRecyclerAdapter = new VideoRecyclerAdapter(listVideosWithThumbnail);
        videoitemClickListener = new ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Log.d("TAG", "View: Clicked!");
                // add video to canvas
                addVideoToCanvas(listVideosWithThumbnail.get(position).getVideoThumbnailBm(),
                        listVideosWithThumbnail.get(position).getVideosDO().getVideoUrl());
            }

            @Override
            public void onItemLongClick(View view, int position) {
                // TODO ERIC: delete video
            }
        };
    }

    @Override
    public void onStart() {
        super.onStart();
//        AWSMobileClient.getInstance().initialize(CardMaker.this, new AWSStartupHandler() {
//            @Override
//            public void onComplete(AWSStartupResult awsStartupResult) {
//                IdentityManager identityManager = IdentityManager.getDefaultIdentityManager();
//                identityManager.resumeSession(CardMaker.this, new StartupAuthResultHandler() {
//                    @Override
//                    public void onComplete(StartupAuthResult authResults) {
//                        if (!authResults.isUserSignedIn()) {
//
//                            startActivity(new Intent(CardMaker.this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
//                        }
//                    }
//                });
//                IdentityManager.getDefaultIdentityManager().addSignInProvider(CognitoUserPoolsSignInProvider.class);
//                IdentityManager.getDefaultIdentityManager().addSignInProvider(FacebookSignInProvider.class);
//                IdentityManager.getDefaultIdentityManager().addSignInProvider(GoogleSignInProvider.class);
//            }
//        }).execute();
        initSavedCards();
    }


    public void seekBarVisible() {
        seekbarFrame.setClickable(true);
        seekbarFrame.animate()
                .setDuration(300)
                .alpha(1.0F)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationStart(Animator animation) {
                        seekbarFrame.setVisibility(View.VISIBLE);
                        super.onAnimationStart(animation);
                    }
                });
    }

    public void seekBarInvisible() {
        seekbarFrame.setClickable(false);
        seekbarFrame.animate()
                .setDuration(300)
                .alpha(0.0F)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        seekbarFrame.setVisibility(View.GONE);
                        super.onAnimationEnd(animation);
                    }
                });
    }

    /**
     *
     * @param message The message of the Alert Dialog (Used for save or save as
     * @param id the id used for either saving a new card or replacing the old one
     */
    public void saveAlertDialog(final String message, final int id) {
        new AlertDialog.Builder(CardMaker.this).setTitle("Save")
                .setMessage(message)
                .setPositiveButton("SAVE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(CardMaker.this,"Successfully Saved!",LENGTH_LONG).show();
                        processCard(id);
                        motionView.setVisibility(View.VISIBLE);
                        motionView.invalidate();
                        clearCanvas();
                    }
                })
                .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if(message.equalsIgnoreCase("Save Card Stamp!")) {
                            cardStampMotionView.unselectEntity();
                            cardStampMotionView.deleteEntities();
                            cardStampMotionView.invalidate();
                            cCardStampBtn();
                        }
                    }
                })
                .show();
    }

    /**
     *
     * @param id the id used for either saving a new card or replacing the old one
     */
    public void processCard(int id) {

        try {
            motionView.hideSnapHelperLines();
            motionView.unselectEntity(); // unselect any entity
            motionView.invalidate();
            cardStampMotionView.hideSnapHelperLines();
            cardStampMotionView.unselectEntity();
            cardStampMotionView.invalidate();
            canvas.buildDrawingCache();
            backsplashImage.buildDrawingCache();
            backgroundImage.buildDrawingCache();

            List<MotionEntity> motionEntities = new ArrayList<>();
            if(!isCardStampActive) {
                motionEntities = motionView.getEntities(); // get all entity objects\
            } else {
                motionEntities = cardStampMotionView.getEntities();

            }

            Bitmap bitmapThumbnail = Bitmap.createBitmap(canvas.getDrawingCache()); //thumbnail
            Bitmap bitmapBackground = Bitmap.createBitmap(backgroundImage.getDrawingCache()); //background
            Bitmap bitmapBacksplash = Bitmap.createBitmap(backsplashImage.getDrawingCache());//backsplash
            //Class Object for Editable
            BusinessCard businessCard = new BusinessCard();
            businessCard.setThumbnail(bitmapThumbnail);
            businessCard.setBackground(bitmapBackground);
            businessCard.setBacksplash(bitmapBacksplash);
            if(motionEntities != null) {
                businessCard.setMotionEntities(motionEntities);
            }
            switch(id) {
                case R.id.menu_save:
                    saveCard(businessCard, bitmapThumbnail);
                    clearCanvas();
                    break;
                case R.id.menu_save_as:
                    saveAsNewCard(businessCard, bitmapThumbnail);

                    break;

            }
            callSaveCardMenu = false;

        }catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(CardMaker.this,"ERROR: " + e.getMessage(),LENGTH_LONG).show();
        }
    }

    /**
     * Replace the currently used save card if there's any.
     * @param businessCard Business Card Object that contains all the items put in the canvas (background, entities, etc)
     * @param bitmapThumbnail the bitmap thumbnail of the card use for display
     */
    public void saveCard(BusinessCard businessCard, Bitmap bitmapThumbnail) {
        // OverWrite the current card
        if(currentBussinessCard.getCardId() != null) {
            isCanvasEmpty = true;
            //String cardId = currentBussinessCard.getCardId();
            saveCardDb(currentCardDO, bitmapThumbnail, false);
        }

    }

    /**
     * Save a businesscard as a new card.
     * @param businessCard Business Card Object that contains all the items put in the canvas (background, entities, etc)
     * @param bitmapThumbnail the bitmap thumbnail of the card use for display
     */
    public void saveAsNewCard(BusinessCard businessCard, Bitmap bitmapThumbnail) {
        Log.d(TAG, "saveCard asnew: called" );

        if(isCardStampActive) {
            mCardStampBusinessCard.add(businessCard);
            ConvertObject convertObject = new ConvertObject();
            byte[] cardStampObject = convertObject.getByteObjects(businessCard);//editable

            mCardStampBmp.add(bitmapThumbnail);
            cCardStampBtn();
            storeCardStampToDatabase(businessCard);
            uncheckTextStamps();
            uncheckHyperlink();
            cardStampMotionView.deleteEntities();
            cardStampMotionView.invalidate();

        } else {
            //SAVE AS EDITABLE
            mBusinessCard.add(businessCard); // add to business cards
            saveNewCardToDatabase(bitmapThumbnail);
            isCanvasEmpty = true;
        }

        recyclerAdapter.notifyDataSetChanged();
        //createPdf(bitmapThumbnail);

    }

    public void uncheckTextStamps() {
        for(TextStampDO textStampDO : mTextStampDo) {
            textStampDO.setSelected(false);
            storeStampToDatabase(textStampDO);
            recyclerAdapter.notifyDataSetChanged();
        }
    }

    /**
     * Save The Card Stamp to Database as Strings with JSON Document.
     * @param businessCard BusinessCard Object that contains all the items of a saved card
     */
    private void storeCardStampToDatabase(BusinessCard businessCard) {
        List<MotionEntity> motionEntities = businessCard.getMotionEntities();
        Log.d(TAG, "saveCardStampToDatabase: " + motionEntities.size());
        String cardStampId = UUID.randomUUID().toString();
        CardStamp cardStamp = new CardStamp();
        List<CSTextEntity> csTextEntityList = new ArrayList<>();
        List<CSImageEntity> csImageEntityList = new ArrayList<>();

        for (int i = 0; i < motionEntities.size(); i++) {
            if(motionEntities.get(i) instanceof TextEntity) {
                TextEntity textEntity = (TextEntity) motionEntities.get(i);
                CSTextEntity csTextEntity = createCSTextEntity(textEntity);
                csTextEntity.setClickableType(textEntity.getClickableType());
                csTextEntityList.add(csTextEntity);
            } else {
                ImageEntity imageEntity = (ImageEntity) motionEntities.get(i);
                CSImageEntity csImageEntity = createCSImageEntity(imageEntity);
                csImageEntity.setClickableType(imageEntity.getClickableType());
                csImageEntityList.add(csImageEntity);
            }
        }
        cardStamp.setUserId(userId);
        cardStamp.setCsTextEntity(csTextEntityList);
        cardStamp.setCsImageEntity(csImageEntityList);
        textStampDynamoDB.addCardStamp(cardStamp);
    }

    /**
     * Generate a Card Stamp Text Entity object that will be used as a JSON Document for the database
     * @param textEntity Any text-type entity used in the business card
     * @return the CSTextEntity object used as JSON Document for database
     */
    private CSTextEntity createCSTextEntity(TextEntity textEntity) {
        String text = textEntity.getLayer().getText();
        Font font = textEntity.getLayer().getFont();
        String scale = String.valueOf(textEntity.getLayer().getScale());
        String mXaxis = String.valueOf( textEntity.getLayer().getX());
        String mYaxis = String.valueOf(textEntity.getLayer().getY());
        String mRotation = String.valueOf(textEntity.getLayer().getRotationInDegrees());
        String width = String.valueOf(textEntity.getWidth());
        String height = String.valueOf(textEntity.getHeight());

        CSTextEntity csTextEntity = new CSTextEntity();
        csTextEntity.setX(mXaxis);
        csTextEntity.setY(mYaxis);
        csTextEntity.setRotationInDegrees(mRotation);
        csTextEntity.setScale(scale);
        csTextEntity.setText(text);
        csTextEntity.setFont(font);
        csTextEntity.setWidth(width);
        csTextEntity.setHeight(height);
        csTextEntity.setAbsoluteCenterX(String.valueOf(textEntity.absoluteCenterX()));
        csTextEntity.setAbsoluteCenterY(String.valueOf(textEntity.absoluteCenterY()));
        return csTextEntity;
    }

    /**
     * Generate a Card Stamp Image Entity object that will be used as a JSON Document for the database
     * @param imageEntity Any image-type entity used in the business card
     * @return the CSTextEntity object used as JSON Document for database
     */
    private CSImageEntity createCSImageEntity(ImageEntity imageEntity) {
        String scale = String.valueOf(imageEntity.getLayer().getScale());
        String mXaxis = String.valueOf( imageEntity.getLayer().getX());
        String mYaxis = String.valueOf(imageEntity.getLayer().getY());
        String mRotation = String.valueOf(imageEntity.getLayer().getRotationInDegrees());
        String width = String.valueOf(imageEntity.getWidth());
        String height = String.valueOf(imageEntity.getHeight());

        CSImageEntity csImageEntity = new CSImageEntity();

        if (imageEntity.getDuplicateName() != null) {
            csImageEntity.setDuplicateName(imageEntity.getDuplicateName());
        }

        csImageEntity.setX(mXaxis);
        csImageEntity.setY(mYaxis);
        csImageEntity.setHyperlink(imageEntity.getImageLink());
        csImageEntity.setClickableType(imageEntity.getClickableType());
        csImageEntity.setAbsoluteCenterX(String.valueOf(imageEntity.absoluteCenterX()));
        csImageEntity.setAbsoluteCenterY(String.valueOf(imageEntity.absoluteCenterY()));
        Log.d(TAG, "createCSImageEntity: clickableType: " + imageEntity.getClickableType());
        csImageEntity.setImageSource(imageEntity.getImageSrc());
        csImageEntity.setRotationInDegrees(mRotation);
        csImageEntity.setScale(scale);
        csImageEntity.setHeight(height);
        csImageEntity.setWidth(width);

        return csImageEntity;
    }

    /**
     * Save the card to Database
     * @param bitmapThumbnail the bitmap image of the card
     */
    private void saveNewCardToDatabase(Bitmap bitmapThumbnail) {
        // create a new uuid for card
        String cardId = UUID.randomUUID().toString();
        CardsDO newcard = new CardsDO();
        newcard.setUserId(userId);
        newcard.setCardId(cardId);
        saveCardDb(newcard, bitmapThumbnail, true);
    }

    /**
     *
     * @param newcard CardDO object use to save to database
     * @param bitmapThumbnail
     * @param saveNew
     */
    private void saveCardDb(CardsDO newcard, Bitmap bitmapThumbnail, boolean saveNew) {
        List<MotionEntity> motionEntities = motionView.getEntities();

        String cardId = newcard.getCardId();

        newcard.setCardHeight(String.valueOf(motionView.getHeight()));
        newcard.setCardWidth(String.valueOf(motionView.getWidth()));

        if(currentBussinessCard.getBackgroundUrl() !=null) {
            newcard.setBackgroundImgId(currentBussinessCard.getBackgroundUrl());
        }
        if(currentBussinessCard.getBacksplashUrl() !=null) {
            newcard.setBacksplashImgId(currentBussinessCard.getBacksplashUrl());
        }

        //
        String cardDesc = "";
        //Log.i("overwrite", String.valueOf(motionEntities.size()));
        if(motionEntities != null) {
            int size = motionEntities.size();
            List<CSTextEntity> textEntities = new ArrayList<>();
            List<CSImageEntity> imageEntities = new ArrayList<>();
            for(int i = 0; i< size; i ++) {
                // Log.d(TAG, "overwrite: " + motionEntities.get(i).toString());
                if(motionEntities.get(i) instanceof ImageEntity) {
                    ImageEntity imageEntity = (ImageEntity) motionEntities.get(i);
                    //create Dynamodb object
                    CSImageEntity csImageEntity = createCSImageEntity(imageEntity);
                    csImageEntity.setHyperlink(imageEntity.getImageLink());
                    csImageEntity.setClickableType(imageEntity.getClickableType());
                    csImageEntity.setAbsoluteCenterX(String.valueOf(imageEntity.absoluteCenterX()));
                    csImageEntity.setAbsoluteCenterY(String.valueOf(imageEntity.absoluteCenterY()));
                    Log.d(TAG, "saveCardDb: text clickableType: " + imageEntity.getClickableType());
                    imageEntities.add(csImageEntity);

                } else {
                    TextEntity textEntity = (TextEntity) motionEntities.get(i);
                    Log.d(TAG, "saveCardDb: texttext clickableType: " + textEntity.getClickableType());
                    CSTextEntity csTextEntity = createCSTextEntity(textEntity);
                    csTextEntity.setClickableType(textEntity.getClickableType());
                    csTextEntity.setAbsoluteCenterX(String.valueOf(textEntity.absoluteCenterX()));
                    csTextEntity.setAbsoluteCenterY(String.valueOf(textEntity.absoluteCenterY()));
                    cardDesc += textEntity.getLayer().getText() + " ";
                    textEntities.add(csTextEntity);
                }
            }
            if(textEntities != null) {
                newcard.setTextEntities(textEntities);
                newcard.setCardDesc(cardDesc);
            }
            if(imageEntities != null) {
                newcard.setImagesEntities(imageEntities);
            }
        }
        // if not save as new => remove the old one
        if(!saveNew) {
            int position = getTheUpdatePosition(newcard);
            listCardsWithThumbnail.set(position, new Card(newcard, bitmapThumbnail));
            mListCards.set(position, bitmapThumbnail);
        } else {
            // add new thumbnail to list
            mListCards.add(bitmapThumbnail);
            // add new card to list
            listCardsWithThumbnail.add(new Card(newcard, bitmapThumbnail));
        }
        //save the thumbnail
        imageS3.uploadImageS3(bitmapThumbnail, "thumbnails/", newcard, saveNew);

        Log.i("current card id", newcard.getCardId());
        recyclerAdapter.notifyDataSetChanged();
        //save new card to dynamo
        //cardDynamoDB.addNewCard(newcard);
        //
        currentBussinessCard = new BusinessCard();
        isCanvasEmpty = true;
    }

    /**
     * This method find the position of a card in the listCardsWithThumbnail
     * @param newcard
     * @return position of card
     */
    private int getTheUpdatePosition(CardsDO newcard) {
        int position = 0;
        int size = listCardsWithThumbnail.size();
        for(int i =0; i< size; i++) {
            if(listCardsWithThumbnail.get(i).getCardsDO().getCardId().equals(newcard.getCardId())) {
                return i;
            }
        }
        return position;
    }

    //testing pdf. saving as byte
    public void checkPermissions() {
        List<String> listPermissionGranted = new ArrayList<>();
        for (int i = 0; i < permissions.length; i++) {
            int permisionNeeded = ContextCompat.checkSelfPermission(this, permissions[i]);
            if (permisionNeeded != PackageManager.PERMISSION_GRANTED) {
                listPermissionGranted.add(permissions[i]);
            }
        }

        if (!listPermissionGranted.isEmpty()) {
            //not granted ask for permission
            requestPermission(listPermissionGranted);
            mPermissionsGranted = false;
        } else {
            mPermissionsGranted = true;
        }
    }

    public void requestPermission(final List<String> listPermissionGranted) {

        if(ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.READ_EXTERNAL_STORAGE)
                || ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.CAMERA)) {
            //Toast.makeText(this,"Permission is needed to use the camera/gallery",Toast.LENGTH_SHORT).show();
            if (!mPermissionsGranted) {
                new AlertDialog.Builder(this)
                        .setTitle("Permission")
                        .setMessage("Tapiolla needs your permission to use the camera/gallery")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Log.d(TAG,"requestPermission: called");
                                ActivityCompat.requestPermissions(CardMaker.this,
                                        listPermissionGranted.toArray(new String[listPermissionGranted.size()]),PERMISSION_ALL_CODE);

                            }
                        })
                        .setNegativeButton("CANCEL", null)
                        .create().show();
            }

        } else {
            ActivityCompat.requestPermissions(this,
                    listPermissionGranted.toArray(new String[listPermissionGranted.size()]),PERMISSION_ALL_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        int x = 0;

        if (requestCode == PERMISSION_ALL_CODE) {
            if(grantResults.length > 0) {
                for (int i = 0; i < grantResults.length; i ++) {
                    if(grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                        x++;
                    }
                }
                mPermissionsGranted = x == 0;
            } else {
                mPermissionsGranted = false;
            }
        }
        else {
            mPermissionsGranted = false;

        }
    }

    public void clearUndos() {
        undoBackground.clear();
        undoBacksplash.clear();
        backsplashList.clear();
        backgroundList.clear();
    }

    private void clearCanvas() {
        //Clear the canvas
        backsplashImage.setImageResource(R.color.transparent);
        backgroundImage.setImageResource(R.drawable.empty_canvas);
        motionView.unselectEntity();
        motionView.deleteEntities();
        canvas.destroyDrawingCache();
        backsplashImage.destroyDrawingCache();
        backgroundImage.destroyDrawingCache();
    }

    private void undo(int id) {
        List<MotionEntity> motionEntities = motionView.getEntities();
        TextEntity textEntity = null;
        if(motionEntityList.size() > 0 ) {
            if(motionEntityList.get(motionEntityList.size() - 1) instanceof TextEntity) {
                for(int i = 0; i < motionEntities.size(); i++) {
                    if(motionEntities.get(i) == motionEntityList.get(motionEntityList.size() - 1)) {
                        textEntity = ((TextEntity) motionEntities.get(i));
                        break;
                    }
                }
            }
        }

        switch (id) {
            case R.string.lastMove_background:
                if(backgroundList.size() > 0) {
                    Image lastBackgroundId = backgroundList.get(backgroundList.size() - 1);
                    backgroundList.remove(backgroundList.remove(backgroundList.size() - 1));
                    backgroundImage.setImageBitmap(backgroundList.get(backgroundList.size() - 1).getImageBitmap());
                    undoBackground.add(lastBackgroundId); //add it to 'removed' backgrounds
                    removeLastId(false);

                }
                else {
                    backgroundImage.setImageResource(R.drawable.empty_canvas);
                }

                break;
            case R.string.lastMove_backsplash:
                if(backsplashList.size() > 0) {
                    Image lastBackgroundId = backsplashList.get(backsplashList.size() - 1);
                    backsplashList.remove(backsplashList.remove(backsplashList.size() - 1));
                    backsplashImage.setImageBitmap(backsplashList.get(backsplashList.size() - 1).getImageBitmap());
                    undoBacksplash.add(lastBackgroundId); //add it to 'removed' backgrounds

                    removeLastId(false);

                }
                else {
                    backsplashImage.setImageDrawable(null);
                }
                break;

            case R.string.lastMove_increase: //decrease font
                if(motionEntityList.size() > 0) {
                    if(textEntity != null) {
                        textEntity.getLayer().getFont().decreaseSize(TextLayer.Limits.FONT_SIZE_STEP);
                        textEntity.updateEntity();
                        motionView.invalidate();


                        removeLastId(true);

                    }
                }
                break;
            case R.string.lastMove_decrease: //increase font
                if(motionEntityList.size() > 0) {
                    if(textEntity != null) {
                        textEntity.getLayer().getFont().increaseSize(TextLayer.Limits.FONT_SIZE_STEP);
                        textEntity.updateEntity();
                        motionView.invalidate();


                        removeLastId(true);
                    }
                }

                break;
            case R.string.lastMove_color: //change color back
                if(colorList.size() > 0) {
                    if(textEntity != null) {
                        Integer lastColor = colorList.get(colorList.size() - 1);
                        colorList.remove(colorList.size() - 1);
                        textEntity.getLayer().getFont().setColor(colorList.get(colorList.size() - 1));
                        textEntity.updateEntity();
                        motionView.invalidate();
                        undoColorList.add(lastColor);
                        removeLastId(true);
                    }
                }

                break;
            case R.string.lastMove_font: //change font
                if(typeFaceList.size() > 0) {
                    if(textEntity != null) {
                        String lastTypeFace = typeFaceList.get(typeFaceList.size() - 1);
                        typeFaceList.remove(typeFaceList.size() - 1);
                        textEntity.getLayer().getFont().setTypeface(typeFaceList.get(typeFaceList.size() - 1));
                        textEntity.updateEntity();
                        motionView.invalidate();

                        undoTypeList.add(lastTypeFace);
                        removeLastId(true);
                    }
                }

                break;
        }
    }

    private void removeLastId(boolean isEntity) {
        if(isEntity) {
            MotionEntity addEntity = motionEntityList.get(motionEntityList.size() - 1);
            motionEntityList.remove(motionEntityList.size() - 1);
            undoMotionEntityList.add(addEntity);
        }
        int removeLastId = lastMove.get(lastMove.size() - 1);
        lastMove.remove(lastMove.get(lastMove.size() - 1));
        undoLastMove.add(removeLastId);
    }

    private void redo(int id) {
        List<MotionEntity> motionEntities = motionView.getEntities();
        TextEntity textEntity = null;
        if(undoMotionEntityList.size() > 0 ) {
            if(undoMotionEntityList.get(undoMotionEntityList.size() - 1) instanceof TextEntity) {

                for(int i = 0; i < motionEntities.size(); i++) {
                    if(motionEntities.get(i) == undoMotionEntityList.get(undoMotionEntityList.size() - 1)) {
                        textEntity = ((TextEntity) motionEntities.get(i));
                        break;
                    }
                }
            }
        }


        switch (id) {
            case R.string.lastMove_background:
                if(undoBackground.size() > 0) {
                    Image redoBackground = undoBackground.get(undoBackground.size() - 1);
                    //canvas.setBackgroundResource(undoBackground.get(undoBackground.size() - 1));
                    backgroundImage.setImageBitmap(undoBackground.get(undoBackground.size() - 1).getImageBitmap());
                    undoBackground.remove(undoBackground.size() - 1);
                    backgroundList.add(redoBackground); //add to background list

                    addLastId(false);

                }


                break;
            case R.string.lastMove_backsplash:
                if(undoBacksplash.size() > 0) {
                    Image addBacksplash = undoBacksplash.get(undoBacksplash.size() - 1);
                    backsplashImage.setImageBitmap(undoBacksplash.get(undoBacksplash.size() - 1).getImageBitmap());
                    undoBacksplash.remove(undoBacksplash.get(undoBacksplash.size() - 1));
                    backsplashList.add(addBacksplash); //add to background list

                    addLastId(false);

                }

                break;
            case R.string.lastMove_increase: //decrease font
                if(undoMotionEntityList.size() > 0) {
                    if(textEntity != null) {
                        textEntity.getLayer().getFont().increaseSize(TextLayer.Limits.FONT_SIZE_STEP);
                        textEntity.updateEntity();
                        motionView.invalidate();

                        addLastId(true);
                    }
                }
                break;
            case R.string.lastMove_decrease: //increase font
                if(undoMotionEntityList.size() > 0) {
                    if(textEntity != null) {
                        textEntity.getLayer().getFont().decreaseSize(TextLayer.Limits.FONT_SIZE_STEP);
                        textEntity.updateEntity();
                        motionView.invalidate();

                        addLastId(true);
                    }
                }
                break;
            case R.string.lastMove_color: //change color back
                if(undoColorList.size() > 0) {
                    if(textEntity != null) {
                        Integer lastColor = undoColorList.get(undoColorList.size() - 1);

                        textEntity.getLayer().getFont().setColor(undoColorList.get(undoColorList.size() - 1));
                        textEntity.updateEntity();
                        motionView.invalidate();
                        undoColorList.remove(undoColorList.size() - 1);
                        colorList.add(lastColor);


                        addLastId(true);
                    }
                }

                break;
            case R.string.lastMove_font: //change font
                if(undoTypeList.size() > 0) {
                    if(textEntity != null) {
                        String lastTypeFace = undoTypeList.get(undoTypeList.size() - 1);
                        textEntity.getLayer().getFont().setTypeface(undoTypeList.get(undoTypeList.size() - 1));
                        textEntity.updateEntity();
                        motionView.invalidate();

                        undoTypeList.remove(undoTypeList.size() - 1);
                        typeFaceList.add(lastTypeFace);

                        addLastId(true);
                    }
                }
                break;
        }


    }

    private void addLastId(boolean isEntity) {
        if(isEntity) {
            MotionEntity addEntity = undoMotionEntityList.get(undoMotionEntityList.size() - 1);
            undoMotionEntityList.remove(undoMotionEntityList.size() - 1);
            motionEntityList.add(addEntity);
        }
        int lastMoveId = undoLastMove.get(undoLastMove.size() - 1);
        undoLastMove.remove(undoLastMove.get(undoLastMove.size() - 1));
        lastMove.add(lastMoveId);
    }

    /*  Motion View Methods  */
    private ImageEntity duplicateImageEntity(ImageEntity imageEntity) {
        if (imageEntity != null) {
            Layer layer = new Layer();
            int opacity = imageEntity.getOpacity();
            imageEntity.setOpacity(255);
            imageEntity.applyOpacity();
            //copy the selected image's layer
            layer.setScale(imageEntity.getLayer().getScale());
            layer.setX(imageEntity.getLayer().getX());
            layer.setY(imageEntity.getLayer().getY());
            layer.setFlipped(imageEntity.getLayer().isFlipped());
            layer.setRotationInDegrees(imageEntity.getLayer().getRotationInDegrees());
            Bitmap bitmap = imageEntity.getBitmap();
            Bitmap newBitmap = bitmap.copy(bitmap.getConfig(), true);
            String imgSrc = imageEntity.getImageSrc();
            imageEntity.setOpacity(opacity);
            imageEntity.applyOpacity();
            ImageEntity entity = new ImageEntity(layer, newBitmap, motionView.getWidth(), motionView.getHeight(), imgSrc);
            entity.setImageLink(imageEntity.getImageLink());
            entity.setClickableType(imageEntity.getClickableType());
            entity.setOpacity(opacity);
            entity.applyOpacity();
            Log.d(TAG, "duplicate: opacity: " + imageEntity.getOpacity());
            return entity;
        } else {
            return null;
        }
    }

    // copy  text attributes and create new layer with same properties
    private TextLayer duplicateLayer(final TextEntity textEntity) {
        Log.d(TAG,"duplicateLayer: called");
        //Create a new Text Layer
        TextLayer textLayer = new TextLayer();

        //Copy Text Properties
        Font font = new Font();
        if (textEntity != null) {
            font.setColor(textEntity.getLayer().getFont().getColor());

            font.setSize(textEntity.getLayer().getFont().getSize());
            font.setTypeface(textEntity.getLayer().getFont().getTypeface());

            textLayer.setFont(font);
            //Copy Layer's Scale, Rotation, Flipping
            textLayer.setX(textEntity.getLayer().getX());
            textLayer.setY(textEntity.getLayer().getY());
            textLayer.setScale(textEntity.getLayer().getScale());
            textLayer.setRotationInDegrees(textEntity.getLayer().getRotationInDegrees());
            textLayer.setFlipped(textEntity.getLayer().isFlipped());
            if (BuildConfig.DEBUG) {
                textLayer.setText(textEntity.getLayer().getText());
            }
        }

        return textLayer;
    }

    @Nullable
    private ImageEntity currentImageEntity() {
        Log.d(TAG,"currentImageEntity: called");
        if (motionView != null && motionView.getSelectedEntity() instanceof ImageEntity) {
            return ((ImageEntity) motionView.getSelectedEntity());
        } else {
            return null;
        }
    }

    private TextEntity duplicateTextEntity(final TextEntity textEntity) {
        Log.d(TAG, "lastMove items: " + lastMove.size());

        //final TextEntity textEntity = currentTextEntity(); // selected text
        if (textEntity != null) {
            TextLayer textLayer = duplicateLayer(textEntity);
            TextEntity newTextEntity = new TextEntity(textLayer, textEntity.getWidth(),
                    motionView.getHeight(), fontProvider);
            newTextEntity.setOpacity(textEntity.getOpacity());
            newTextEntity.updateEntity();
            newTextEntity.setClickableType(textEntity.getClickableType());
            return newTextEntity;
        } else {
            return null;
        }
    }
    //Add Social Media as Image Entity
    private void addSticker(final int stickerResId, int position, String link, String clickableType) {
        lastMove.add(R.string.lastMove_entity);
        Log.d(TAG,"addSticker: lastMove: size: " + lastMove.size());
        Layer layer = new Layer();
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), stickerResId);

        ImageEntity entity = new ImageEntity(layer, bitmap, motionView.getWidth(), motionView.getHeight(), String.valueOf(position));
        entity.setImageLink(link);
        entity.setClickableType(clickableType);
        Log.d(TAG, "Hyperlink: link: " + link);
        motionView.addEntityAndPosition(entity);

    }

    /**
     * this function Add Video as Image Entity
     * @param bm thumbnail bitmap
     * @param link image url
     */
    private void addVideoToCanvas(final Bitmap bm, String link) {
        lastMove.add(R.string.lastMove_entity);
        Log.d(TAG,"addSticker: lastMove: size: " + lastMove.size());
        Layer layer = new Layer();

        ImageEntity entity = new ImageEntity(layer, bm, motionView.getWidth(), motionView.getHeight(), link);
        entity.setImageLink(link);
        entity.setClickableType(VIDEO_TYPE);
        Log.d(TAG, "Hyperlink: link: " + link);
        motionView.addEntityAndPosition(entity);

    }
    //Click  Listener for Text's Recycler VIew Items
    public void initTextClickListener() {
        seekBarInvisible();
        itemClickListener = new MyRecyclerAdapter.ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Log.d(TAG, "initTextClickListener: Position: " + position);

                switch (position) {
                    case 0: // Edit
                        startTextEntityEditing();
                        break;
                    case 1: // Plus size
                        increaseTextEntitySize();
                        break;
                    case 2: // Minus size
                        decreaseTextEntitySize();
                        break;
                    case 3: //color
                        changeTextEntityColor();
                        break;
                    case 4: //font type
                        changeTextEntityFont();
                        break;
                    case 5: //bold
                        changeToBoldItalic("Bold_");
                        break;
                    case 6: //italicized
                        changeToBoldItalic("Italic_");
                        break;
                }
            }

            @Override
            public void onItemLongClick(View view, int position) {

            }
        };
        recyclerAdapter = new MyRecyclerAdapter(this, mListText);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 4));
        recyclerAdapter.setClickListener(itemClickListener);
        recyclerView.setAdapter(recyclerAdapter);

    }

    private void increaseTextEntitySize() {
        TextEntity textEntity = currentTextEntity();
        if (textEntity != null) {
            //
            lastMove.add(R.string.lastMove_increase);
            motionEntityList.add(textEntity);

            textEntity.getLayer().getFont().increaseSize(TextLayer.Limits.FONT_SIZE_STEP);
            textEntity.updateEntity();
            motionView.invalidate();
        }
    }

    private void decreaseTextEntitySize() {
        TextEntity textEntity = currentTextEntity();
        if (textEntity != null) {
            // undo
            lastMove.add(R.string.lastMove_decrease);
            motionEntityList.add(textEntity);

            textEntity.getLayer().getFont().decreaseSize(TextLayer.Limits.FONT_SIZE_STEP);
            textEntity.updateEntity();
            motionView.invalidate();
        }
    }

    protected void addTextSticker(String text) {
        lastMove.add(R.string.lastMove_entity);

        Log.d(TAG, "lastMove items: " + lastMove.size());
        TextLayer textLayer = createTextLayer(text);
        TextEntity textEntity = new TextEntity(textLayer, motionView.getWidth(),
                motionView.getHeight(), fontProvider);
        motionView.addEntityAndPosition(textEntity);

        // move text sticker up so that its not hidden under keyboard
        PointF center = textEntity.absoluteCenter();
        center.y = center.y * 0.5F;
        textEntity.moveCenterTo(center);

        // redraw
        motionView.invalidate();

        startTextEntityEditing();
    }

    private void changeTextEntityColor() {
        TextEntity textEntity = currentTextEntity();
        if (textEntity == null) {
            return;
        }

        final int initialColor = textEntity.getLayer().getFont().getColor();

        ColorPickerDialogBuilder
                .with(CardMaker.this)
                .setTitle("Select Color")
                .initialColor(initialColor)
                .wheelType(ColorPickerView.WHEEL_TYPE.FLOWER)
                .density(8) // magic number
                .setPositiveButton("Ok", new ColorPickerClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedColor, Integer[] allColors) {
                        TextEntity textEntity = currentTextEntity();
                        if (textEntity != null) {
                            textEntity.getLayer().getFont().setColor(selectedColor);
                            textEntity.updateEntity();
                            motionView.invalidate();

                            lastMove.add(R.string.lastMove_color);
                            colorList.add(selectedColor);
                            motionEntityList.add(textEntity);

                            //undo list
                            Log.d(TAG,"Change Color: motionEntityList size: " + motionEntityList.size());

                        }
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                })
                .build()
                .show();
    }

    private void changeTextEntityFont() {
        if(motionView.getSelectedEntity() != null) {
            final List<String> fonts = fontProvider.getFontNames();
            FontsAdapter fontsAdapter = new FontsAdapter(this, fonts, fontProvider);
            new AlertDialog.Builder(this)
                    .setTitle("Select Font")
                    .setAdapter(fontsAdapter, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int which) {
                            TextEntity textEntity = currentTextEntity();
                            if (textEntity != null) {
                                //undo
                                String typeFace = textEntity.getLayer().getFont().getTypeface();

                                lastMove.add(R.string.lastMove_font);
                                motionEntityList.add(textEntity);
                                typeFaceList.add(typeFace);
                                Log.d(TAG,"change text entity font adding: " + typeFace);

                                //change font
                                textEntity.getLayer().getFont().setTypeface(fonts.get(which));
                                textEntity.updateEntity();
                                motionView.invalidate();
                            }
                        }
                    })
                    .show();
        }
    }

    private void changeToBoldItalic(String type) {
        TextEntity textEntity = currentTextEntity();
        if(textEntity != null) {
            String font = textEntity.getLayer().getFont().getTypeface();
            try {

                if(((type.equalsIgnoreCase("Bold_")) && font.startsWith("Italic_"))
                        || ((type.equalsIgnoreCase("Italic_") && font.startsWith("Bold_")))) {
                    font = font.replaceFirst("Bold_","");
                    font = font.replaceFirst("Italic_","");
                    textEntity.getLayer().getFont().setTypeface("BoldItalic_" + font);
                }
                else if(font.startsWith("Bold_")) {
                    font = font.replaceFirst("Bold_","");
                    textEntity.getLayer().getFont().setTypeface(font);
                } else if(font.startsWith("Italic_")) {
                    font = font.replaceFirst("Italic_","");
                    textEntity.getLayer().getFont().setTypeface(font);
                } else if(font.startsWith("BoldItalic")) {
                    if(type.equalsIgnoreCase("Bold_")) {
                        font = font.replaceFirst("BoldItalic_", "Italic_");
                    } else {
                        font = font.replaceFirst("BoldItalic_", "Bold_");
                    }
                    textEntity.getLayer().getFont().setTypeface(font);
                } else {
                    textEntity.getLayer().getFont().setTypeface(type + font);

                }
                textEntity.updateEntity();
                motionView.invalidate();
                String typeface = textEntity.getLayer().getFont().getTypeface();
                lastMove.add(R.string.lastMove_font);
                typeFaceList.add(typeface);
                motionEntityList.add(textEntity);
            } catch (NullPointerException np) {
                np.printStackTrace();
            }


        }
    }

    //Start Editing Text
    private void startTextEntityEditing() {
        TextEntity textEntity = currentTextEntity();
        if (textEntity != null) {
            //text.setImageResource(R.drawable.highlighted_text);
            TextEditorDialogFragment fragment = TextEditorDialogFragment.getInstance(textEntity.getLayer().getText());
            fragment.show(getFragmentManager(), TextEditorDialogFragment.class.getName());

        }
    }

    //Selected Text
    @Nullable
    private TextEntity currentTextEntity() {
        if (motionView != null && motionView.getSelectedEntity() instanceof TextEntity) {
            return ((TextEntity) motionView.getSelectedEntity());
        } else {
            return null;
        }
    }

    private TextLayer createTextLayer(String text) {
        TextLayer textLayer = new TextLayer();
        Font font = new Font();

        font.setColor(TextLayer.Limits.INITIAL_FONT_COLOR);
        font.setSize(TextLayer.Limits.INITIAL_FONT_SIZE);
        font.setTypeface(fontProvider.getDefaultFontName());

        textLayer.setFont(font);

        if (BuildConfig.DEBUG) {
            textLayer.setText(text);
        }

        return textLayer;
    }

    public void initBackground() {
        mListBackground = new ArrayList<>();
//        for (int x = 1; x <= 54; x++) {
//            int resId = this.getResources().getIdentifier("background_" + x, "drawable", getPackageName());
//            mListBackground.add(resId);
//        }
        ArrayList<String> urls = new ArrayList<>();
        for (int x = 1; x <= 48; x++) {
            //int resId = this.getResources().getIdentifier("OL" + x, "drawable", getPackageName());
            //mListBacksplash.add(resId);
            urls.add( BACKGROUND_URL_PREFIX + "BS" + x + ".png");

        }
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = (int) (displayMetrics.widthPixels * 0.18);
        DownloadImages dl = new DownloadImages(getApplicationContext(), urls, mListBackground, width);
    }

    public void initBackSplash() {
        mListBacksplash = new ArrayList<>();
        ArrayList<String> urls = new ArrayList<>();
        for (int x = 1; x <= 8; x++) {
            //int resId = this.getResources().getIdentifier("OL" + x, "drawable", getPackageName());
            //mListBacksplash.add(resId);
            urls.add( OVERLAY_URL_PREFIX + "OL" + x + ".png");

        }
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = (int) (displayMetrics.widthPixels * 0.18);
        DownloadImages dl = new DownloadImages(getApplicationContext(), urls, mListBacksplash, width);
    }

    public void initSocialMedia() {
        mListSocialMedia = new ArrayList<>();
        mListSocialMedia = initItems.initSocialMedia();
    }

    public void initCardStamp() {
        mListCardStamp = new ArrayList<>();
        mListCardStamp = initItems.initCardStamp();
        mListCopyStamp = new ArrayList<>();
        mListCopyStamp.addAll(mListCardStamp);
    }

    //change this soon from database
    public void initTemplates() {
        mListTemplate = new ArrayList<>();
        //mListTemplate.add(R.drawable.bcard);
//        mListTemplate.add(R.drawable.testimage);
//        mListTemplate.add(R.drawable.template2);
//        mListTemplate.add(R.drawable.template3);
//        mListTemplate.add(R.drawable.template4);
//        mListTemplate.add(R.drawable.template5);
//        mListTemplate.add(R.drawable.template6);
    }

    public void initText() {
        mListText = new ArrayList<>();
        mListText = initItems.initText();
    }

    public void initSavedCards() {
        mListCards = new ArrayList<>();
        cardDynamoDB.getAllCards();
    }

    private void downloadImages(String path) {
        final Bitmap[] temp = new Bitmap[1];
        Glide.with(getApplicationContext())
                .asBitmap()
                .load(path)
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        mListPhoto.add( resource);
                        Log.i("loadimg", "successful!");
                        recyclerAdapter.notifyDataSetChanged();
                        //progressDialog.dismiss();
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {

                    }
                });
    }

    private void downloadAndAddImages(final String path, final ImagesDO newimg) {
        final Bitmap[] temp = new Bitmap[1];
        Glide.with(getApplicationContext())
                .asBitmap()
                .load(path)
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        mListPhoto.add(resource);
                        imagesList.add(newimg);

                        Log.i("loadimg", "successful!");
                        recyclerAdapter.notifyDataSetChanged();
                        addPhoto(resource, path);

                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                    }
                });
        //return temp[0];
    }
    public void toggleButons() {
        template.setImageResource(R.drawable.templatebtn);
        background.setImageResource(R.drawable.backgroundbtn);
        text.setImageResource(R.drawable.textbtn);
        camera.setImageResource(R.drawable.photosbtn);
        social_media.setImageResource(R.drawable.socialmediabtn);
        card_stamp.setImageResource(R.drawable.cardstampbtn);

    }
    /** multiFuncBtn clicked**/
    public void cMultiFuncBtn() {
        String btnName = multiFuncBtn.getText().toString().toLowerCase();
        switch (btnName) {
            //my cards
            case "my cards":
                //Change recyclerview items to my cards //select a saved card
                callSaveCardMenu = true;
                multiFuncBtn.setText(R.string.multifunc_template);
                recyclerAdapter = new MyRecyclerAdapter(CardMaker.this, mListCards,true, true);
                recyclerView.setLayoutManager(new GridLayoutManager(CardMaker.this, rowNum));
                itemClickListener = new MyRecyclerAdapter.ItemClickListener() {
                    @Override
                    public void onItemClick(View view,final int position) {
                        currentCardPosition = position;
                        if (motionView.getEntities().size() > 0) {
                            isCanvasEmpty = false;
                        }

                        if(isCanvasEmpty) {
                            RecreateCard recreateCard = new RecreateCard(getApplicationContext(), dynamoSettings, motionView, CardMaker.this, fontProvider);
                            currentCardDO = listCardsWithThumbnail.get(position).getCardsDO();
                            clearCanvas();
                            recreateCard.recreateCard(currentCardDO);
                            currentBussinessCard.setCardId(currentCardDO.getCardId());
                            //set the current card DO
                            // currentCardDO = listCardsWithThumbnail.get(position).getCardsDO();
                            isCanvasEmpty = false;
                            recyclerAdapter.notifyDataSetChanged();
                        } else {
                            new AlertDialog.Builder(CardMaker.this)
                                    .setTitle("This will delete all other entities.")
                                    .setMessage(" Would you like to Continue?")
                                    .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {

                                            RecreateCard recreateCard = new RecreateCard(getApplicationContext(), dynamoSettings, motionView, CardMaker.this, fontProvider);
                                            currentCardDO = listCardsWithThumbnail.get(position).getCardsDO();
                                            clearCanvas();
                                            recreateCard.recreateCard(currentCardDO);
                                            currentBussinessCard.setCardId(currentCardDO.getCardId());
                                            //set the current card DO
                                            recyclerAdapter.notifyDataSetChanged();
                                        }
                                    })
                                    .setNegativeButton("CANCEL",null)
                                    .show();

                        }
                    }

                    @Override
                    public void onItemLongClick(View view, int position) {
                        CardsDO currentCardDO = listCardsWithThumbnail.get(position).getCardsDO();
                        deleteCard(currentCardDO, view, position);
                    }
                };
                motionView.invalidate();//draw
                recyclerAdapter.setClickListener(itemClickListener);
                recyclerView.setAdapter(recyclerAdapter);
                break;

            case "template":
                //Change recyclerview items to templates
                callSaveCardMenu = false;
                multiFuncBtn.setText(R.string.multifunc_my_cards);
                recyclerAdapter = new MyRecyclerAdapter(CardMaker.this, mListTemplate);
                recyclerView.setLayoutManager(new GridLayoutManager(CardMaker.this, 1));
                itemClickListener = new MyRecyclerAdapter.ItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        backgroundImage.setImageResource(mListTemplate.get(position));
                        isCanvasEmpty = false;
                        lastMove.add(R.string.lastMove_background); // change to editable later
                        //TODO:Check
                        //backgroundList.add(mListTemplate.get(position));
                    }

                    @Override
                    public void onItemLongClick(View view, int position) {

                    }
                };
                recyclerAdapter.setClickListener(itemClickListener);
                recyclerView.setAdapter(recyclerAdapter);
                break;
            case "backsplash":
                //Change recyclerview items to back splash
                callSaveCardMenu = false;
                multiFuncBtn.setText(R.string.multifunc_background);
                imageRecyclerAdapter = new ImageRecyclerAdapter(CardMaker.this, mListBacksplash);

                recyclerView.setLayoutManager(new GridLayoutManager(CardMaker.this, 1));
                imageItemClick = new ItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                       // Bitmap bitmap = BitmapFactory.decodeResource(getResources(), mListBacksplash.get(position));
                        isCanvasEmpty = false;
                        backsplashImage.setImageBitmap(mListBacksplash.get(position).getImageBitmap());
                        lastMove.add(R.string.lastMove_backsplash);
                        //TODO:
                        backsplashList.add(mListBacksplash.get(position));
                        //set blacsplash img src to the business object
                        currentBussinessCard.setBacksplashUrl(mListBacksplash.get(position).getImageUrl());
                    }

                    @Override
                    public void onItemLongClick(View view, int position) {

                    }
                };
                imageRecyclerAdapter.setClickListener(imageItemClick);
                recyclerView.setAdapter(imageRecyclerAdapter);
                break;
            case "background":
                //Change recyclerview items to background
                callSaveCardMenu = false;
                multiFuncBtn.setText(R.string.multifunc_backsplash);
                imageRecyclerAdapter = new ImageRecyclerAdapter(CardMaker.this, mListBackground);
                recyclerView.setLayoutManager(new GridLayoutManager(CardMaker.this, 1));
                imageItemClick = new ItemClickListener() {//draw backsplash into the editor
                    @Override
                    public void onItemClick(View view, int position) {
                        isCanvasEmpty = false;
                        backgroundImage.setImageBitmap(mListBackground.get(position).getImageBitmap());
                        lastMove.add(R.string.lastMove_background);
                        backgroundList.add(mListBackground.get(position));
                        Log.d(TAG, "lastMove items: " + lastMove.size());
                        //set blackground img src to the business object
                        currentBussinessCard.setBackgroundUrl(String.valueOf(position));
                    }

                    @Override
                    public void onItemLongClick(View view, int position) {

                    }
                };

                imageRecyclerAdapter.setClickListener(imageItemClick);
                recyclerView.setAdapter(imageRecyclerAdapter);
                break;
            case "photos":
                multiFuncBtn.setText(R.string.multifunc_videos);
                callSaveCardMenu = false;
                recyclerView.setAdapter(recyclerAdapter);

                break;
            case "videos":
                multiFuncBtn.setText(R.string.multifunc_photos);

                if(!isLoadVideo) {
                    // Load the video information
                    videoDyanamoDB.getAllVideos(getApplicationContext());
                }
                recyclerView.setAdapter(videoRecyclerAdapter);
                callSaveCardMenu = false;
                break;
            case "my stamps":

                if(cardStampMotionView.getEntities().size() > 0 && isCardStampActive) {
                    saveStampDialog(-1);
                } else {
                    cCardStampBtn();
                    dummyBackground.setVisibility(View.GONE);
                    backgroundImage.setVisibility(View.VISIBLE);
                }
                recyclerAdapter.setClickListener(itemClickListener);
                recyclerView.setAdapter(recyclerAdapter);
                break;
            case "create stamp":
                initInfo();
                multiFuncBtn.setText(R.string.multifunc_my_stamps);
                dummyBackground.setVisibility(View.VISIBLE);
                backgroundImage.setVisibility(View.GONE);
                recyclerAdapter.setClickListener(itemClickListener);
                recyclerView.setAdapter(recyclerAdapter);
                break;
            default:
                addBtn.setVisibility(View.INVISIBLE);
                cSocialMediaBtn();
                recyclerAdapter.setClickListener(itemClickListener);
                recyclerView.setAdapter(recyclerAdapter);
        }

    }

    public void getCheckedItems() {
        mCheckedCardStamp.clear();
        mCheckedSocialMedia.clear();
        isCardStampActive = true;
        saveCheckedItems = false;
        mCardStamp = new ArrayList<>();
        mCardStamp.addAll(mCsFname);
        mCardStamp.addAll(mCsLname);
        mCardStamp.addAll(mCsAddress);
        mCardStamp.addAll(mCsEmail);
        mCardStamp.addAll(mCsPhone);
        mCardStamp.addAll(mCsTitle);
        mCardStamp.addAll(mCsWeblink);

        canvas.setVisibility(View.VISIBLE);
        multiFuncBtn.setVisibility(View.VISIBLE);
        cardStampFrameLayout.setVisibility(View.GONE);
        cardStampFrameLayout.setElevation(0);
        cardStampMotionView.setVisibility(View.VISIBLE);
        cardStampMotionView.setElevation(999);
        motionView.setVisibility(View.GONE);

        //get checked text
        for (int i = 0; i < mCardStamp.size(); i++) {
            if(mCardStamp.get(i).isSelected()) {
                mCheckedCardStamp.add(mCardStamp.get(i));
            }
        }

        //get checked social media
        for (int i = 0; i < mSocialMedia.size(); i++) {
            if (mSocialMedia.get(i).isSelected()) {
                mCheckedSocialMedia.add(mSocialMedia.get(i));
            }
        }

        if (mCheckedSocialMedia.size() > 0 ) {
            generateImageSticker(mCheckedSocialMedia);
        }

        if (mCheckedCardStamp.size() > 0) {
            for(int i = 0; i < mCheckedCardStamp.size(); i++ ) {
                generateTextSticker(mCheckedCardStamp.get(i).getCsName(), mCheckedCardStamp.get(i).getCsType());
                Log.d(TAG, "getCheckedItems: csType: " + mCheckedCardStamp.get(i).getCsType());
            }

        } else {
            cardStampMotionView.unselectEntity();
            cardStampMotionView.invalidate();
        }


        recyclerView.setVisibility(View.INVISIBLE);


//        itemClickListener = new MyRecyclerAdapter.ItemClickListener() {
//            @Override
//            public void onItemClick(View view,final int position) {
//                new AlertDialog.Builder(CardMaker.this)
//                        .setTitle("Add Stamp to Canvas")
//                        .setMessage(" Would you like to Continue?")
//                        .setPositiveButton("YES", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialogInterface, int i) {
//                                cardStampMotionView.setVisibility(View.INVISIBLE);
//                                motionView.setVisibility(View.VISIBLE);
//                                thirdFrame.setVisibility(View.VISIBLE);
//                                dummyBackground.setVisibility(View.GONE);
//                                backgroundImage.setVisibility(View.VISIBLE);
//                                isCardStampActive = false;
//                                toggleButons();
//                                cBackgroundBtn();
//
//                                    if (mCardStampBusinessCard.size() > 0) {
//                                    try {
//                                        List<MotionEntity> motionEntities = mCardStampBusinessCard.get(position).getMotionEntities();//retrieve entities
//                                        List<MotionEntity> duplicateEntities = new ArrayList<>();
//
//                                        for (int y = 0; y < motionEntities.size(); y++) {
//                                            if(motionEntities.get(y) instanceof TextEntity) {
//                                                TextEntity textEntity = duplicateTextEntity((TextEntity) motionEntities.get(y));
//                                                textEntity.setClickableType(((TextEntity) motionEntities.get(y)).getClickableType());
//                                                Log.d(TAG, "onClick: add stamp text clickableType: " + ((TextEntity) motionEntities.get(y)).getClickableType());
//                                                duplicateEntities.add(textEntity);
//                                            }
//                                            else {
//                                                ImageEntity imageEntity = duplicateImageEntity((ImageEntity) motionEntities.get(y));
//                                                imageEntity.setImageLink( ((ImageEntity) motionEntities.get(y)).getImageLink());
//                                                imageEntity.setClickableType(((ImageEntity) motionEntities.get(y)).getClickableType());
//                                                Log.d(TAG, "onClick: add stamp image clickableType: " + ((ImageEntity) motionEntities.get(y)).getClickableType());
//                                                duplicateEntities.add(imageEntity);
//                                            }
//                                        }
//                                        for (int x = 0; x < duplicateEntities.size(); x++) {
//                                            motionView.addEntity(duplicateEntities.get(x));
//                                        }
//                                        motionView.invalidate();//draw
//                                        clearUndos();
//                                    }catch (NullPointerException ne) {
//                                        ne.printStackTrace();
//                                    }
//                                }
//
//                            }
//                        })
//                        .setNegativeButton("NO",null)
//                        .show();
//            }
//
//            @Override
//            public void onItemLongClick(View view, int position) {
//
//            }
//        };


        recyclerAdapter = new MyRecyclerAdapter(CardMaker.this, mCardStampBmp,true);
        recyclerAdapter.setClickListener(itemClickListener);
        recyclerView.setLayoutManager(new GridLayoutManager(CardMaker.this, 1));
        recyclerView.setAdapter(recyclerAdapter);
        recyclerView.setVisibility(View.VISIBLE);



    }

    public void generateTextSticker(String text, String csType) {

        Log.d(TAG, "lastMove items: " + lastMove.size());
        TextLayer textLayer = createTextLayer(text);
        TextEntity textEntity = new TextEntity(textLayer, motionView.getWidth(),
                motionView.getHeight(), fontProvider);
        textEntity.setClickableType(csType);

        Log.d(TAG, "generateTextSticker: text clickableType: " + csType);

        cardStampMotionView.addEntityAndPosition(textEntity);

        // move text sticker up so that its not hidden under keyboard
        PointF center = textEntity.absoluteCenter();
        center.y = center.y * 0.5F;
        textEntity.moveCenterTo(center);

        // redraw
        cardStampMotionView.invalidate();
    }

    public void generateImageSticker(List<SocialMedia> socialMedias) {
        int stickerResId = 0;
        int pos = 0;

        mSmDuplicateType.clear();
        if (socialMedias.size() > 0) {
            for (int i =0; i < socialMedias.size(); i++ ) {
                String smType = socialMedias.get(i).getSmType();
                for (int j = i + 1; j < socialMedias.size(); j++ ) {
                    if (smType.equalsIgnoreCase(socialMedias.get(j).getSmType())) {
                        mSmDuplicateType.add(smType);
                    }
                }
            }
        }

        for (int i = 0; i < socialMedias.size(); i++) {
            switch (socialMedias.get(i).getSmType()) {
                case FACEBOOK:
                    pos = 0;
                    break;
                case GOOGLE:
                    pos = 1;
                    break;
                case INSTAGRAM:
                    pos = 2;
                    break;
                case LINKEDIN:
                    pos = 3;
                    break;
                case EMAIL:
                    pos = 4;
                    break;
                case PINTEREST:
                    pos = 5;
                    break;
                case SKYPE:
                    pos = 6;
                    break;
                case TUMBLR:
                    pos = 7;
                    break;
                case TWITTER:
                    pos = 8;
                    break;
                case WHATSAPP:
                    pos = 9;
                    break;
            }
            stickerResId = mListSocialMedia.get(pos);

            if (mSmDuplicateType.contains(socialMedias.get(i).getSmType())) {
                //duplicate social media
                duplicateSocialIcon(new Layer(), socialMedias.get(i).getSmName(), socialMedias.get(i).getSmLink(), pos);
            } else {
                Layer layer = new Layer();
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), stickerResId);
                ImageEntity entity = new ImageEntity(layer, bitmap, motionView.getWidth(), motionView.getHeight());
                entity.setImageLink(socialMedias.get(i).getSmLink());
                entity.setClickableType(socialMedias.get(i).getSmType());
                entity.setImageSrc(String.valueOf(pos));
                cardStampMotionView.addEntityAndPosition(entity);

                cardStampMotionView.invalidate();
            }
        }
    }

    public void duplicateSocialIcon(Layer layer, String name, String link, int position) {

        View inflatedFrame = getLayoutInflater().inflate(R.layout.socialmedia, null);

        TextView txtSmName = inflatedFrame.findViewById(R.id.social_title);
        txtSmName.setText(name);

        ImageView imgSmIcon = inflatedFrame.findViewById(R.id.social_icon);
        imgSmIcon.setImageResource(mListSocialMedia.get(position));
        FrameLayout frameLayout = (FrameLayout) inflatedFrame.findViewById(R.id.sm_layout) ;
        frameLayout.setDrawingCacheEnabled(true);
        frameLayout.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        frameLayout.layout(0, 0, frameLayout.getMeasuredWidth(), frameLayout.getMeasuredHeight());
        frameLayout.buildDrawingCache(true);
        final Bitmap bm = frameLayout.getDrawingCache();

        ImageEntity entity = new ImageEntity(layer, bm, motionView.getWidth(), motionView.getHeight());
        entity.setImageLink(link);
        entity.setDuplicateName(name);
        entity.setImageSrc(String.valueOf(position));
        cardStampMotionView.addEntityAndPosition(entity);

        cardStampMotionView.invalidate();
    }

    public void cAddBtn(View view) {
        /*
                    Add Button Listener
                    1. @Template: Create an Empty Canvas + Alert Dialog
                    2. @Background/Backsplash: Upload Image from device
                    3. @Text: Add new Text Entity
                    4. @Photos/Videos: Add Photos and Videos from device
                    5. @Social Media: Add Links to social Media
                    6. @Card Stamp: Create new card stamp
                */
        List<MotionEntity> entities = motionView.getEntities();

        switch (CURRENT_TAB) {

            case C_TEMPLATE:
                if(motionView.getEntities().size() > 0) {
                    isCanvasEmpty = false;
                }
                if (isCanvasEmpty) {
                    clearCanvas();
                    clearUndos();
                } else {
                    new AlertDialog.Builder(CardMaker.this).setTitle("Save Canvas")
                            .setMessage("Are you sure you want to clear the canvas?")
                            .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    //canvas.setBackgroundResource(R.drawable.empty_canvas);
                                    isCanvasEmpty = true;
                                    clearCanvas();
                                    clearUndos();
                                }
                            })
                            .setNegativeButton("NO", null).setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                }
                template.setImageResource(R.drawable.highlighted_template);

                break;
            case C_BACKGROUND:
                background.setImageResource(R.drawable.highlighted_background);
                if(mPermissionsGranted) {
                    takePhoto(view);
                    isAddToBackground = true;
                } else {
                    checkPermissions();
                }
                break;
            case C_TEXT:
                text.setImageResource(R.drawable.highlighted_text);
                addTextSticker(defaultText);
                break;
            case C_CAMERA:
                camera.setImageResource(R.drawable.highlighted_camera);
                if (mPermissionsGranted) {
                    //Eric --add upload
                    isAddToBackground = false;
                    String btnName = multiFuncBtn.getText().toString().toLowerCase();


                    if(btnName.equals("photos") ) {
                        getVideo();
                    } else  {
                        takePhoto(view);
                    }

                }
                else {
                    checkPermissions();
                }

                break;
            case C_SOCIAL_MEDIA:
                social_media.setImageResource(R.drawable.highlighted_social_media);

                LinearLayout linearLayout = new LinearLayout(this);
                linearLayout.setOrientation(LinearLayout.VERTICAL);
                linearLayout.setPadding(10, 0, 10, 0);
                final EditText editName = new EditText(this);
                editName.setHint("Enter Name");
                editName.setFocusable(true);
                final EditText editLink = new EditText(this);
                editLink.setHint("Enter Link");

                linearLayout.addView(editName);
                linearLayout.addView(editLink);

                final AlertDialog alertDialog = new AlertDialog.Builder(CardMaker.this)
                        .setTitle("Fill up Details")
                        .setView(linearLayout)
                        .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                SocialMedia socialMedia = new SocialMedia();
                                socialMedia.setSmType(socialMediaName);
                                socialMedia.setSmLink(editLink.getText().toString());
                                socialMedia.setSmName(editName.getText().toString());
                                socialMedia.setSelected(false);

                                Log.d(TAG, "Facebook: " + socialMediaName);
                                switch (socialMediaName) {
                                    case FACEBOOK:
                                        mSmFacebook.add(socialMedia);
                                        break;
                                    case GOOGLE:
                                        mSmGoogle.add(socialMedia);
                                        break;
                                    case INSTAGRAM:
                                        mSmInstagram.add(socialMedia);
                                        break;
                                    case LINKEDIN:
                                        mSmLinkedIn.add(socialMedia);
                                        break;
                                    case EMAIL:
                                        mSmEmail.add(socialMedia);
                                        break;
                                    case PINTEREST:
                                        mSmPinterest.add(socialMedia);
                                        break;
                                    case SKYPE:
                                        mSmSkype.add(socialMedia);
                                        break;
                                    case TUMBLR:
                                        mSmTumblr.add(socialMedia);
                                        break;
                                    case TWITTER:
                                        mSmTwitter.add(socialMedia);
                                        break;
                                    case WHATSAPP:
                                        mSmWhatsapp.add(socialMedia);
                                        break;
                                }
                                recyclerAdapter.notifyDataSetChanged();
                                mSocialMedia.add(socialMedia);
                                Log.d(TAG,"Social Media: " + mSocialMedia.size());
                                Hyperlink hyperlink = new Hyperlink();
                                hyperlink.setUserId(userId);
                                hyperlink.setSocialMedia(mSocialMedia);
                                storeHyperlinkToDatabase(hyperlink);
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .create();

                TextWatcher textWatcher = new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                    }

                    @Override
                    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                    }

                    @Override
                    public void afterTextChanged(Editable editable) {

                        if (editName.getText().toString().trim().length() == 0
                        || editLink.getText().toString().trim().length() == 0) {
                            alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                        } else {
                            alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                        }
                    }
                };

                editName.addTextChangedListener(textWatcher);
                editLink.addTextChangedListener(textWatcher);
                alertDialog.show();
                alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);


                break;
            case C_CARD_STAMP:
                card_stamp.setImageResource(R.drawable.highlighted_card_stamp);
                new AlertDialog.Builder(this)
                        .setTitle("Continue?")
                        .setMessage("This will uncheck all card stamp items")
                        .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                multiFuncBtn.setText("Stamp");
                                dummyBackground.setVisibility(View.VISIBLE);
                                backgroundImage.setVisibility(View.GONE);
                                cardStampRecyclerAdapter.uncheckAll();

                                cardStampMotionView.deleteEntities();
                                cardStampMotionView.invalidate();
                                initInfo();
                                uncheckHyperlink();
                                uncheckTextStamps();
                            }
                        })
                        .setNegativeButton("NO", null)
                        .show();
                break;
        }
    }

    public void uncheckHyperlink() {
        for (int i = 0; i < mSocialMedia.size(); i++) {
            mSocialMedia.get(i).setSelected(false);
        }

        Hyperlink hyperlink = new Hyperlink();
        hyperlink.setUserId(userId);
        hyperlink.setSocialMedia(mSocialMedia);
        hyperlinkDynamoDB.saveHyperlink(hyperlink);
    }

    public void storeHyperlinkToDatabase(Hyperlink hyperlink) {
        hyperlinkDynamoDB.saveHyperlink(hyperlink);
    }

    public void hideCardStampLayout() {
        cardStampFrameLayout.setVisibility(View.GONE);
        cardStampFrameLayout.setElevation(0);
        cardStampMotionView.setElevation(0);
        cardStampMotionView.setVisibility(View.INVISIBLE);
    }

    public void cTemplateBtn() {
        CURRENT_TAB = C_TEMPLATE;
        multiFuncBtn.setVisibility(View.VISIBLE);
        hideCardStampLayout();
        multiFuncBtn.setText(R.string.multifunc_my_cards);
        template.setImageResource(R.drawable.highlighted_template);
        rowNum = 1;
        recyclerAdapter = new MyRecyclerAdapter(this, mListTemplate);
        recyclerView.setLayoutManager(new GridLayoutManager(this, rowNum));
        //selecting a template will clear your canvas
        itemClickListener = new MyRecyclerAdapter.ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                //canvas.setBackgroundResource(mListTemplate.get(position));
                backgroundImage.setImageResource(mListTemplate.get(position));
                lastMove.add(R.string.lastMove_background);
                //TODO: Check
                //backgroundList.add(mListTemplate.get(position));
                currentBussinessCard.setBackgroundUrl(String.valueOf(position));
            }

            @Override
            public void onItemLongClick(View view, int position) {

            }
        };
        recyclerAdapter.setClickListener(itemClickListener);
        recyclerView.setAdapter(recyclerAdapter);
    }

    public void cBackgroundBtn() {
        CURRENT_TAB = C_BACKGROUND;
        multiFuncBtn.setVisibility(View.VISIBLE);
        hideCardStampLayout();
        multiFuncBtn.setText(R.string.multifunc_backsplash);
        rowNum = 1;
        background.setImageResource(R.drawable.highlighted_background);
        imageRecyclerAdapter = new ImageRecyclerAdapter(this, mListBackground);
        recyclerView.setLayoutManager(new GridLayoutManager(this, rowNum));
        imageItemClick = new ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Log.d(TAG, "itemClickListener: clicked : Position: " + position);
                //canvas.setBackgroundResource(mListBackground.get(position));
                backgroundImage.setImageBitmap(mListBackground.get(position).getImageBitmap());
                lastMove.add(R.string.lastMove_background);
                backgroundList.add(mListBackground.get(position));
                Log.d(TAG, "lastMove items: " + lastMove.size());
                //set blackground img src to the business object
                currentBussinessCard.setBackgroundUrl(String.valueOf(position));
                isCanvasEmpty = false;
            }

            @Override
            public void onItemLongClick(View view, int position) {

            }
        };
        imageRecyclerAdapter.setClickListener(imageItemClick);
        recyclerView.setAdapter(imageRecyclerAdapter);
    }

    public void cTextBtn() {
        CURRENT_TAB = C_TEXT;
        multiFuncBtn.setVisibility(View.INVISIBLE);
        hideCardStampLayout();
        text.setImageResource(R.drawable.highlighted_text);
        rowNum = 4;
        initTextClickListener();
    }

    public void cCameraBtn() {
        CURRENT_TAB = C_CAMERA;
        multiFuncBtn.setVisibility(View.VISIBLE);
        hideCardStampLayout();
        multiFuncBtn.setText("Videos");
        camera.setImageResource(R.drawable.highlighted_camera);

        recyclerAdapter = new MyRecyclerAdapter(this, mListPhoto,true);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        itemClickListener = new MyRecyclerAdapter.ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Log.d(TAG, "itemClickListener: clicked : Position: " + position);
                addPhoto(mListPhoto.get(position), imagesList.get(position).getImageUrl());
                Log.d(TAG, "lastMove items: " + lastMove.size());
            }

            @Override
            public void onItemLongClick(View view, int position) {
                deleteImage(view,
                        imagesList.get(position).getImageId(),
                        imagesList.get(position).getImageUrl(), position);
                // imagesList.remove(position);
                // mListPhoto.remove(position);
                // recyclerAdapter.notifyDataSetChanged();
            }
        };

        recyclerAdapter.setClickListener(itemClickListener);
        recyclerView.setAdapter(recyclerAdapter);
        Log.i("videosize", String.valueOf(listVideosWithThumbnail.size()));
        videoRecyclerAdapter = new VideoRecyclerAdapter(listVideosWithThumbnail);
        //recyclerView.setAdapter(videoRecyclerAdapter);
    }

    public void cSocialMediaBtn() {
        addBtn.setVisibility(View.INVISIBLE);
        CURRENT_TAB = C_SOCIAL_MEDIA;
        multiFuncBtn.setVisibility(View.INVISIBLE);
        hideCardStampLayout();
        social_media.setImageResource(R.drawable.highlighted_social_media);
        rowNum = 2;
        initSocialMedia();
        itemClickListener = new MyRecyclerAdapter.ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                addBtn.setVisibility(View.VISIBLE);
                switch (position) {
                    case 0:
                        socialMediaName = FACEBOOK;
                        recyclerAdapter = new MyRecyclerAdapter(CardMaker.this, mSmFacebook, HYPERLINK_LAYOUT);
                        break;
                    case 1:
                        socialMediaName = GOOGLE;
                        recyclerAdapter = new MyRecyclerAdapter(CardMaker.this, mSmGoogle, HYPERLINK_LAYOUT);
                        break;
                    case 2:
                        socialMediaName = INSTAGRAM;
                        recyclerAdapter = new MyRecyclerAdapter(CardMaker.this, mSmInstagram, HYPERLINK_LAYOUT);
                        break;
                    case 3:
                        socialMediaName = LINKEDIN;
                        recyclerAdapter = new MyRecyclerAdapter(CardMaker.this, mSmLinkedIn, HYPERLINK_LAYOUT);
                        break;
                    case 4:
                        socialMediaName = EMAIL;
                        recyclerAdapter = new MyRecyclerAdapter(CardMaker.this, mSmEmail, HYPERLINK_LAYOUT);
                        break;
                    case 5:
                        socialMediaName = PINTEREST;
                        recyclerAdapter = new MyRecyclerAdapter(CardMaker.this, mSmPinterest, HYPERLINK_LAYOUT);
                        break;
                    case 6:
                        socialMediaName = SKYPE;
                        recyclerAdapter = new MyRecyclerAdapter(CardMaker.this, mSmSkype, HYPERLINK_LAYOUT);
                        break;
                    case 7:
                        socialMediaName = TUMBLR;
                        recyclerAdapter = new MyRecyclerAdapter(CardMaker.this, mSmTumblr, HYPERLINK_LAYOUT);
                        break;
                    case 8:
                        socialMediaName = TWITTER;
                        recyclerAdapter = new MyRecyclerAdapter(CardMaker.this, mSmTwitter, HYPERLINK_LAYOUT);
                        break;
                    case 9:
                        socialMediaName = WHATSAPP;
                        recyclerAdapter = new MyRecyclerAdapter(CardMaker.this, mSmWhatsapp, HYPERLINK_LAYOUT);
                        break;

                }
                initHyperlinkClickListener();
                recyclerView.setLayoutManager(new GridLayoutManager(CardMaker.this, 1));
                recyclerView.setAdapter(recyclerAdapter);
                multiFuncBtn.setVisibility(View.VISIBLE);
                multiFuncBtn.setText("< " + socialMediaName);
            }

            @Override
            public void onItemLongClick(View view, int position) {

            }

        };

        recyclerAdapter = new MyRecyclerAdapter(this, mListSocialMedia);
        recyclerAdapter.setClickListener(itemClickListener);
        recyclerView.setLayoutManager(new GridLayoutManager(this, rowNum));
        recyclerView.setAdapter(recyclerAdapter);
    }

    public void toggleCardStamp() {
        for (int i = 0; i < mListCopyStamp.size(); i++) {
            recyclerAdapter.toggle(i, mListCopyStamp.get(i));
        }

    }

    public void initHyperlinkClickListener() {
        itemClickListener = new MyRecyclerAdapter.ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                switch (socialMediaName) {
                    case FACEBOOK:
                        addSticker(mListSocialMedia.get(0), 0, mSmFacebook.get(position).getSmLink(), FACEBOOK);
                        Toast.makeText(CardMaker.this, "Link: " + mSmFacebook.get(position).getSmLink() ,Toast.LENGTH_LONG).show();
                        break;
                    case GOOGLE:
                        addSticker(mListSocialMedia.get(1), 1, mSmGoogle.get(position).getSmLink(), GOOGLE);
                        Toast.makeText(CardMaker.this, "Link: " + mSmGoogle.get(position).getSmLink() ,Toast.LENGTH_LONG).show();
                        break;
                    case INSTAGRAM:
                        addSticker(mListSocialMedia.get(2), 2, mSmInstagram.get(position).getSmLink(), INSTAGRAM);
                        Toast.makeText(CardMaker.this, "Link: " + mSmInstagram.get(position).getSmLink() ,Toast.LENGTH_LONG).show();
                        break;
                    case LINKEDIN:
                        addSticker(mListSocialMedia.get(3), 3, mSmLinkedIn.get(position).getSmLink(), LINKEDIN);
                        Toast.makeText(CardMaker.this, "Link: " + mSmLinkedIn.get(position).getSmLink() ,Toast.LENGTH_LONG).show();
                        break;
                    case EMAIL:
                        addSticker(mListSocialMedia.get(4), 4, mSmEmail.get(position).getSmLink(), EMAIL);
                        Toast.makeText(CardMaker.this, "Link: " + mSmEmail.get(position).getSmLink() ,Toast.LENGTH_LONG).show();
                        break;
                    case PINTEREST:
                        addSticker(mListSocialMedia.get(5), 5, mSmPinterest.get(position).getSmLink(), PINTEREST);
                        Toast.makeText(CardMaker.this, "Link: " + mSmPinterest.get(position).getSmLink() ,Toast.LENGTH_LONG).show();
                        break;
                    case SKYPE:
                        addSticker(mListSocialMedia.get(6), 6, mSmSkype.get(position).getSmLink(), SKYPE);
                        Toast.makeText(CardMaker.this, "Link: " + mSmSkype.get(position).getSmLink() ,Toast.LENGTH_LONG).show();
                        break;
                    case TUMBLR:
                        addSticker(mListSocialMedia.get(7), 7, mSmTumblr.get(position).getSmLink(), TUMBLR);
                        Toast.makeText(CardMaker.this, "Link: " + mSmTumblr.get(position).getSmLink() ,Toast.LENGTH_LONG).show();
                        break;
                    case TWITTER:
                        addSticker(mListSocialMedia.get(8), 8, mSmTwitter.get(position).getSmLink(), TWITTER);
                        Toast.makeText(CardMaker.this, "Link: " + mSmTwitter.get(position).getSmLink() ,Toast.LENGTH_LONG).show();
                        break;
                    case WHATSAPP:
                        addSticker(mListSocialMedia.get(9), 9, mSmWhatsapp.get(position).getSmLink(), WHATSAPP);
                        Toast.makeText(CardMaker.this, "Link: " + mSmWhatsapp.get(position).getSmLink() ,Toast.LENGTH_LONG).show();
                        break;
                }
            }

            @Override
            public void onItemLongClick(View view, int position) {
                deleteHyperlink(view, position);
            }
        };
        recyclerAdapter.setClickListener(itemClickListener);

    }

    public void deleteHyperlink(View view, final int position) {
        final PopupMenu delete = new PopupMenu(CardMaker.this, view);
        delete.getMenuInflater().inflate(R.menu.delete, delete.getMenu());

        delete.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                SocialMedia removeSocialMedia = new SocialMedia();
                switch (menuItem.getItemId()) {
                    case R.id.menu_delete:
                        switch (socialMediaName) {
                            case FACEBOOK:
                                mSmFacebook.remove(position);
                                removeSocialMedia = mSmFacebook.get(position);
                                break;
                            case GOOGLE:
                                mSmGoogle.remove(position);
                                removeSocialMedia = mSmGoogle.get(position);
                                break;
                            case INSTAGRAM:
                                mSmInstagram.remove(position);
                                removeSocialMedia = mSmInstagram.get(position);
                                break;
                            case LINKEDIN:
                                mSmLinkedIn.remove(position);
                                removeSocialMedia = mSmLinkedIn.get(position);
                                break;
                            case EMAIL:
                                mSmEmail.remove(position);
                                removeSocialMedia = mSmEmail.get(position);
                                break;
                            case PINTEREST:
                                mSmPinterest.remove(position);
                                removeSocialMedia = mSmPinterest.get(position);
                                break;
                            case SKYPE:
                                mSmSkype.remove(position);
                                removeSocialMedia = mSmSkype.get(position);
                                break;
                            case TUMBLR:
                                mSmTumblr.remove(position);
                                removeSocialMedia = mSmTumblr.get(position);
                                break;
                            case TWITTER:
                                mSmTwitter.remove(position);
                                removeSocialMedia = mSmTwitter.get(position);
                                break;
                            case WHATSAPP:
                                mSmWhatsapp.remove(position);
                                removeSocialMedia = mSmTwitter.get(position);
                                break;
                        }
                        Hyperlink hyperlink = new Hyperlink();

                        mSocialMedia.remove(removeSocialMedia);
                        hyperlink.setSocialMedia(mSocialMedia);
                        hyperlink.setUserId(userId);
                        hyperlinkDynamoDB.saveHyperlink(hyperlink);

                        recyclerAdapter.notifyDataSetChanged();
                        break;
                }
                return false;
            }
        });
        delete.show();
    }

    public void cCardStampBtn() {
        saveCheckedItems = false;//save checked items and add it to canvas
        isCardStampActive = false;
        CURRENT_TAB = C_CARD_STAMP;
        dummyBackground.setVisibility(View.GONE);
        backgroundImage.setVisibility(View.VISIBLE);
        card_stamp.setImageResource(R.drawable.highlighted_card_stamp);
        multiFuncBtn.setVisibility(View.VISIBLE);
        canvas.setVisibility(View.VISIBLE);
        thirdFrame.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.VISIBLE);

        hideCardStampLayout();

        multiFuncBtn.setText(R.string.multifunc_create_stamp);

        itemClickListener = new MyRecyclerAdapter.ItemClickListener() {
            @Override
            public void onItemClick(View view,final int position) {
                new AlertDialog.Builder(CardMaker.this)
                        .setTitle("Add Stamp to Canvas")
                        .setMessage(" Would you like to Continue?")
                        .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                cardStampMotionView.setVisibility(View.INVISIBLE);
                                motionView.setVisibility(View.VISIBLE);
                                thirdFrame.setVisibility(View.VISIBLE);
                                dummyBackground.setVisibility(View.GONE);
                                backgroundImage.setVisibility(View.VISIBLE);
                                isCardStampActive = false;
                                clearUndos();

                                if (mCardStampBusinessCard.size() > 0) {
                                    try {
                                        List<MotionEntity> motionEntities = mCardStampBusinessCard.get(position).getMotionEntities();//retrieve entities
                                        List<MotionEntity> duplicateEntities = new ArrayList<>();

                                        for (int y = 0; y < motionEntities.size(); y++) {
                                            isCanvasEmpty = false;
                                            if(motionEntities.get(y) instanceof TextEntity) {
                                                TextEntity textEntity = duplicateTextEntity((TextEntity) motionEntities.get(y));
                                                textEntity.setClickableType(((TextEntity) motionEntities.get(y)).getClickableType());
                                                Log.d(TAG, "onClick: add stamp2 text clickableType: " + ((TextEntity) motionEntities.get(y)).getClickableType());
                                                duplicateEntities.add(textEntity);
                                            }
                                            else {
                                                ImageEntity imageEntity = duplicateImageEntity((ImageEntity) motionEntities.get(y));
                                                imageEntity.setImageLink( ((ImageEntity) motionEntities.get(y)).getImageLink());
                                                imageEntity.setClickableType(((ImageEntity) motionEntities.get(y)).getClickableType());
                                                Log.d(TAG, "onClick: add stamp2 image clickableType: " + ((ImageEntity) motionEntities.get(y)).getClickableType());
                                                duplicateEntities.add(imageEntity);
                                            }
                                        }
                                        for (int x = 0; x < duplicateEntities.size(); x++) {
                                            motionView.addEntity(duplicateEntities.get(x));
                                        }
                                        motionView.invalidate();//draw
                                        clearUndos();
                                    }catch (NullPointerException ne) {
                                        ne.printStackTrace();
                                    }
                                }

                            }
                        })
                        .setNegativeButton("NO",null)
                        .show();
            }

            @Override
            public void onItemLongClick(View view, int position) {
                deleteCardStamp(view, position);
            }
        };


        recyclerAdapter = new MyRecyclerAdapter(CardMaker.this, mCardStampBmp,true);
        recyclerAdapter.setClickListener(itemClickListener);
        recyclerView.setLayoutManager(new GridLayoutManager(CardMaker.this, 1));
        recyclerView.setAdapter(recyclerAdapter);
        recyclerView.setVisibility(View.VISIBLE);


    }

    private void deleteCardStamp(View view, final int position) {
        final PopupMenu delete = new PopupMenu(CardMaker.this, view);
        delete.getMenuInflater().inflate(R.menu.delete, delete.getMenu());

        delete.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.menu_delete:
                        CardStamp cardStamp = mCardStampItems.get(position);
                        mCardStampBmp.remove(position);
                        textStampDynamoDB.deleteCardStamp(cardStamp);

                        recyclerAdapter.notifyDataSetChanged();
                        break;
                }
                return false;
            }
        });
        delete.show();
    }

    public void initInfo() {
        saveCheckedItems = true;
        initCardStamp();
        isCardStampActive = true;
        cardStampMotionView.setElevation(0);
        cardStampMotionView.setVisibility(View.INVISIBLE);
        backgroundImage.setVisibility(View.INVISIBLE);
        thirdFrame.setVisibility(View.GONE);
        //when click on save while in cardstamp and savecheckeditems is true
        cardStampFrameLayout.setVisibility(View.VISIBLE);
        cardStampFrameLayout.setElevation(999);
        recyclerAdapter = new MyRecyclerAdapter(this, mListCardStamp);
        recyclerAdapter.setLayoutResource(R.layout.template_2);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        cardStampRecyclerAdapter = new FieldEntryAdapter(this, mCsFname, "firstName", dynamoSettings, this);
        cardStampRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        cardStampRecyclerView.setAdapter(cardStampRecyclerAdapter);

        recyclerAdapter.toggle(0, R.drawable.cs_on_fname);
        addCardStampClickListener(0);
        itemClickListener = new MyRecyclerAdapter.ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                toggleCardStamp();

                addCardStampClickListener(position);
                if (position == 7) {
                    cardStampAdd.setVisibility(View.INVISIBLE);
                } else {
                    cardStampAdd.setVisibility(View.VISIBLE);
                }
                switch (position) {
                    case 0:
                        recyclerAdapter.toggle(position, R.drawable.cs_on_fname);
                        cardStampRecyclerAdapter = new FieldEntryAdapter(CardMaker.this, mCsFname, FIRST_NAME, dynamoSettings, CardMaker.this);
                        break;
                    case 1:
                        recyclerAdapter.toggle(position, R.drawable.cs_on_lname);
                        cardStampRecyclerAdapter = new FieldEntryAdapter(CardMaker.this, mCsLname,  LAST_NAME, dynamoSettings, CardMaker.this);
                        break;
                    case 2:
                        recyclerAdapter.toggle(position, R.drawable.cs_on_title);
                        cardStampRecyclerAdapter = new FieldEntryAdapter(CardMaker.this, mCsTitle,  TITLE, dynamoSettings, CardMaker.this);
                        break;
                    case 3:
                        recyclerAdapter.toggle(position, R.drawable.cs_on_address);
                        cardStampRecyclerAdapter = new FieldEntryAdapter(CardMaker.this, mCsAddress,  ADDRESS, dynamoSettings, CardMaker.this);
                        break;
                    case 4:
                        recyclerAdapter.toggle(position, R.drawable.cs_on_email);
                        cardStampRecyclerAdapter = new FieldEntryAdapter(CardMaker.this, mCsEmail,  EMAIL, dynamoSettings, CardMaker.this);
                        break;
                    case 5:
                        recyclerAdapter.toggle(position, R.drawable.cs_on_phone);
                        cardStampRecyclerAdapter = new FieldEntryAdapter(CardMaker.this, mCsPhone,  PHONE, dynamoSettings, CardMaker.this);
                        break;
                    case 6:
                        recyclerAdapter.toggle(position, R.drawable.cs_on_weblink);
                        cardStampRecyclerAdapter = new FieldEntryAdapter(CardMaker.this, mCsWeblink, WEBLINK, dynamoSettings, CardMaker.this);
                        break;
                    case 7:
                        recyclerAdapter.toggle(position, R.drawable.cs_on_socialmedia);
                        cardStampRecyclerAdapter = new FieldEntryAdapter(CardMaker.this, mSocialMedia, SOCIAL_MEDIA, dynamoSettings, CardMaker.this, true);
                        break;
                }
                cardStampRecyclerView.setLayoutManager(new LinearLayoutManager(CardMaker.this));
                cardStampRecyclerView.setAdapter(cardStampRecyclerAdapter);

            }

            @Override
            public void onItemLongClick(View view, int position) {

            }
        };
        recyclerAdapter.setClickListener(itemClickListener);
        recyclerView.setAdapter(recyclerAdapter);

    }

    public void addCardStampClickListener(final int position) {
        cardStampAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final EditText value = new EditText(CardMaker.this);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                        50,
                        LinearLayout.LayoutParams.MATCH_PARENT);
                value.setLayoutParams(layoutParams);

                switch (position) {
                    case 4: value.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
                        break;
                    case 5: value.setInputType(InputType.TYPE_CLASS_PHONE);
                        break;
                }

                final AlertDialog alertDialog = new AlertDialog.Builder(CardMaker.this)
                        .setTitle("Enter Details")
                        .setView(value)
                        .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                String val = value.getText().toString();
                                TextStampDO textStampDO = new TextStampDO();
                                textStampDO.setUserId(userId);
                                textStampDO.setCsName(val);
                                textStampDO.setSelected(false);
                                switch (position) {
                                    case 0:
                                        textStampDO.setCsType(FIRST_NAME);
                                        mCsFname.add(textStampDO);
                                        break;
                                    case 1:
                                        textStampDO.setCsType(LAST_NAME);
                                        mCsLname.add(textStampDO);
                                        break;
                                    case 2:
                                        textStampDO.setCsType(TITLE);
                                        mCsTitle.add(textStampDO);
                                        break;
                                    case 3:
                                        textStampDO.setCsType(ADDRESS);
                                        mCsAddress.add(textStampDO);
                                        break;
                                    case 4:
                                        textStampDO.setCsType(EMAIL);
                                        mCsEmail.add(textStampDO);
                                        break;
                                    case 5:
                                        textStampDO.setCsType(PHONE);
                                        mCsPhone.add(textStampDO);
                                        break;
                                    case 6:
                                        textStampDO.setCsType(WEBLINK);
                                        mCsWeblink.add(textStampDO);
                                        break;
                                }
                                storeStampToDatabase(textStampDO);
                                cardStampRecyclerAdapter.notifyDataSetChanged();
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .create();
                value.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                    }

                    @Override
                    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                    }

                    @Override
                    public void afterTextChanged(Editable editable) {
                        if (value.getText().toString().trim().length() == 0) {
                            alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                        } else {

                            alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                        }
                    }
                });
                alertDialog.show();
                alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            }
        });

    }

    public void storeStampToDatabase(TextStampDO textStampDO) {
        textStampDynamoDB.addTextStamp(textStampDO);
    }

    public void cSaveBtn() {
        if (motionView.getEntities().size() > 0) {
            isCanvasEmpty = false;
        }
        motionView.hideSnapHelperLines();
        if(callSaveCardMenu || (currentBussinessCard.getCardId() != null)) {
            final PopupMenu savePopupMenu = new PopupMenu(CardMaker.this, findViewById(R.id.save));
            savePopupMenu.getMenuInflater().inflate(R.menu.save, savePopupMenu.getMenu());

            savePopupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                    switch (menuItem.getItemId()) {
                        case R.id.menu_save :
                            saveAlertDialog("Are you sure you want to save this card?", R.id.menu_save);
                            //replace
                            break;
                        case R.id.menu_save_as :
                            saveAlertDialog("Are you sure you want to save this as a new card?", R.id.menu_save_as);
                            //save as new
                            break;
                    }
                    return false;


                }
            });
            savePopupMenu.show();

        } else {
            if(!isCardStampActive) {
                if (!isCanvasEmpty) {
                    saveAlertDialog("Are you sure you want to save this as a new card?", R.id.menu_save_as);
                }
            } else if(saveCheckedItems){
                getCheckedItems();
            } else {
                saveAlertDialog("Save Card Stamp!" ,R.id.menu_save_as);
            }

        }
    }

    public void cUndoRedoBtn() {
        final PopupMenu mUndoRedo = new PopupMenu(CardMaker.this, findViewById(R.id.undoRedo));
        mUndoRedo.getMenuInflater().inflate(R.menu.undo_redo, mUndoRedo.getMenu());

        mUndoRedo.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.menu_undo:

                        if(lastMove.size() > 0) {
                            switch(lastMove.get(lastMove.size() - 1)) {
                                case R.string.lastMove_background: // undo background
                                    undo(R.string.lastMove_background);
                                    break;
                                case R.string.lastMove_backsplash: // undo backsplash
                                    undo(R.string.lastMove_backsplash);
                                    break;
                                case R.string.lastMove_entity: // undo entity
                                    Integer last = lastMove.get(lastMove.size() - 1);
                                    lastMove.remove(lastMove.size() - 1);
                                    undoLastMove.add(last);

                                    motionView.undo();
                                    break;
                                case R.string.lastMove_increase:
                                    undo(R.string.lastMove_increase);
                                    break;
                                case R.string.lastMove_decrease:
                                    undo(R.string.lastMove_decrease);
                                    break;
                                case R.string.lastMove_color:
                                    undo(R.string.lastMove_color);
                                    break;
                                case R.string.lastMove_font:
                                    undo(R.string.lastMove_font);
                                    break;
                                default:
                            }
                        }

                        break;

                    case R.id.menu_redo:
                        if(undoLastMove.size() > 0) {
                            switch(undoLastMove.get(undoLastMove.size() - 1)) {
                                case R.string.lastMove_background: // undo background
                                    redo(R.string.lastMove_background);
                                    break;
                                case R.string.lastMove_backsplash: // undo backsplash
                                    redo(R.string.lastMove_backsplash);
                                    break;
                                case R.string.lastMove_entity: // undo entity
                                    Integer last = undoLastMove.get(undoLastMove.size() - 1);
                                    undoLastMove.remove(undoLastMove.size() - 1);
                                    lastMove.add(last);
                                    motionView.redo();
                                    break;
                                case R.string.lastMove_increase:
                                    redo(R.string.lastMove_increase);
                                    break;
                                case R.string.lastMove_decrease:
                                    redo(R.string.lastMove_decrease);
                                    break;
                                case R.string.lastMove_color:
                                    redo(R.string.lastMove_color);
                                    break;
                                case R.string.lastMove_font:
                                    redo(R.string.lastMove_font);
                                    break;
                                default:
                            }
                        }
                        break;
                }
                return false;
            }
        });
        mUndoRedo.show();
    }

    public void cDuplicateBtn() {
        MotionEntity entity = motionView.getSelectedEntity();
        if(entity != null) {
            lastMove.add(R.string.lastMove_entity);
            if (entity instanceof TextEntity) {
                TextEntity textEntity = currentTextEntity();
                motionView.duplicateEntity(duplicateTextEntity(textEntity));
            } else {
                ImageEntity imageEntity = currentImageEntity();
                motionView.duplicateEntity(duplicateImageEntity(imageEntity));

            }
        }
    }

    public void cDeleteBtn() {
        MotionEntity selectedEntity = null;
        if(motionView.getSelectedEntity() != null) {
            selectedEntity = motionView.getSelectedEntity();
            lastMove.add(R.string.lastMove_entity);
            motionView.deleteSelectedEntity();
            motionView.invalidate();
            lastMoveIsDelete = true;
        }
    }

    public void cLayerBtn() {
        final PopupMenu mLayer = new PopupMenu(CardMaker.this, findViewById(R.id.layer));
        mLayer.getMenuInflater().inflate(R.menu.layer, mLayer.getMenu());

        mLayer.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.menu_bring_to_back:
                        motionView.moveSelectedBack();
                        break;
                    case R.id.menu_send_to_front:
                        motionView.moveSelectedFront();
                        break;
                }
                return false;
            }
        });
        mLayer.show();
    }

    public void deleteImage(View view, final String imageId, final String url, final int position) {
        final PopupMenu delete = new PopupMenu(CardMaker.this, view);
        delete.getMenuInflater().inflate(R.menu.delete, delete.getMenu());

        delete.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.menu_delete:

//                        Log.i("deletes3", folderPath);
                        Log.i("deletes3", String.valueOf(position));
                        imageS3.deleteImageS3(url, null);
                        //delete item from recycler
                        mListPhoto.remove(position);
                        imagesList.remove(position);
                        deleteImageFromDynamo(imageId);
                        recyclerAdapter.notifyDataSetChanged();
                        break;
                }
                return false;
            }
        });
        delete.show();
    }

    private void deleteCard(CardsDO card, View view,final int position) {
        final String cardId = card.getCardId();
        final PopupMenu delete = new PopupMenu(CardMaker.this, view);
        delete.getMenuInflater().inflate(R.menu.delete, delete.getMenu());

        delete.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.menu_delete:
                        deleteCardFromDynamo(cardId);
                        listCardsWithThumbnail.remove(position);
                        mListCards.remove(position);
                        recyclerAdapter.notifyDataSetChanged();
                        //imageS3.deleteImageS3(folderPath);
                        break;
                }
                return false;
            }
        });
        delete.show();
    }

    public void saveStampDialog(final int id) {
        new AlertDialog.Builder(this)
                .setTitle("Continue?")
                .setMessage("Save your card stamp!")
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        processCard(R.id.menu_save_as);
                        cCardStampBtn();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (id == -1) {
                            cCardStampBtn();
                            cardStampMotionView.unselectEntity();
                            cardStampMotionView.deleteEntities();
                            cardStampMotionView.invalidate();
                            return;
                        }
                        isCardStampActive = false;
                        canvas.setVisibility(View.VISIBLE);
                        thirdFrame.setVisibility(View.VISIBLE);
                        motionView.setVisibility(View.VISIBLE);
                        dummyBackground.setVisibility(View.GONE);
                        backgroundImage.setVisibility(View.VISIBLE);
                        cardStampMotionView.unselectEntity();
                        cardStampMotionView.deleteEntities();
                        cardStampMotionView.invalidate();
                        switch (id) {
                            case R.id.templatesBtn:
                                toggleButons();//unhighlight all option buttons
                                cTemplateBtn();
                                isCardStampActive = false;
                                break;
                            case R.id.backgroundBtn:
                                toggleButons();//unhighlight all option buttons
                                cBackgroundBtn();
                                isCardStampActive = false;
                                break;
                            case R.id.textBtn:
                                toggleButons();//unhighlight all option buttons
                                cTextBtn();
                                isCardStampActive = false;
                                break;
                            case R.id.cameraBtn:
                                toggleButons();//unhighlight all option buttons
                                cCameraBtn();
                                isCardStampActive = false;
                                break;
                            case R.id.socialmediaBtn:
                                toggleButons();//unhighlight all option buttons
                                cSocialMediaBtn();
                                isCardStampActive = false;
                                break;
                        }
                        dialogInterface.dismiss();
                    }
                })
                .show();


    }

    //Toggles are all in her
    @SuppressLint("ResourceType")
    @Override
    public void onClick(View view) {
        Log.d(TAG,"parent: override Clicked");
        callSaveCardMenu = false;

        if (view.getId() == R.id.templatesBtn || view.getId() == R.id.backgroundBtn || view.getId() == R.id.cameraBtn ||
                view.getId() == R.id.textBtn || view.getId() == R.id.socialmediaBtn) {
            saveCheckedItems = false;

            if(cardStampMotionView.getEntities().size() > 0 && isCardStampActive) {
                saveStampDialog(view.getId());
            } else {
                canvas.setVisibility(View.VISIBLE);
                thirdFrame.setVisibility(View.VISIBLE);
                motionView.setVisibility(View.VISIBLE);
                dummyBackground.setVisibility(View.GONE);
                backgroundImage.setVisibility(View.VISIBLE);
                toggleButons();//unhighlight all option buttons

                switch (view.getId()) {
                    case R.id.templatesBtn:
                        cTemplateBtn();
                        isCardStampActive = false;
                        addBtn.setVisibility(View.VISIBLE);
                        break;
                    case R.id.backgroundBtn:
                        cBackgroundBtn();
                        isCardStampActive = false;
                        addBtn.setVisibility(View.VISIBLE);
                        break;
                    case R.id.textBtn:
                        cTextBtn();
                        isCardStampActive = false;
                        addBtn.setVisibility(View.VISIBLE);
                        break;
                    case R.id.cameraBtn:
                        cCameraBtn();
                        isCardStampActive = false;
                        addBtn.setVisibility(View.VISIBLE);
                        break;
                    case R.id.socialmediaBtn:
                        cSocialMediaBtn();
                        isCardStampActive = false;
                        break;
                }
            }

        }

        if(view.getId() == R.id.save) {
            cSaveBtn();
        } else if(view.getId() == R.id.addBtn) { /* ADD BUTTON */
            cAddBtn(view);
        } else if(view.getId() == R.id.multiFuncBtn) {
            cMultiFuncBtn();
        } else if (view.getId() == R.id.layer) {
            cLayerBtn();
        } else if (view.getId() == R.id.undoRedo) {
            cUndoRedoBtn();
        } else if (view.getId() == R.id.duplicate) {
            cDuplicateBtn();
        } else if (view.getId() == R.id.delete) {
            cDeleteBtn();
        } else if (view.getId() == R.id.cardStampBtn) {
            toggleButons();//unhighlight all option buttons
            cCardStampBtn();
            addBtn.setVisibility(View.VISIBLE);
        }
        seekBarInvisible();



    }

    @Override
    public void onItemClick(View view, int position) {

    }

    @Override
    public void onItemLongClick(View view, int position) {

    }

    @Override
    public void textChanged(@NonNull String text) {
        Log.d(TAG, "textChanged: called");
        TextEntity textEntity = currentTextEntity();
        if (textEntity != null) {
            TextLayer textLayer = textEntity.getLayer();
            if (!text.equals(textLayer.getText())) {
                textLayer.setText(text);
                textEntity.updateEntity();
                motionView.invalidate();
            }
        }
    }

    // Eric Added
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Video
        if ((requestCode == GET_VIDEO_STORAGE) &&  (resultCode == RESULT_OK)) {

            Uri uri = data.getData();
            // upload video to s3
            videoS3.uploadVideoS3(CardMaker.this, uri);

            // add the video thumbnail to the card
            Bitmap bitmap2 = VideoFunctions.putOverlay(getApplicationContext(), uri);
            //save image to s3
            imageS3.uploadVideoThumbnailS3(bitmap2);

            Video newVideo = VideoFunctions.createNewVideoObject(bitmap2, userId);
            listVideosWithThumbnail.add(newVideo);
            videoRecyclerAdapter.notifyDataSetChanged();
            //addPhoto(bitmap2);
            //mListPhoto.add(bitmap2);
            //recyclerAdapter.notifyDataSetChanged();

        }

        //Image
        //request code = choose from gallery
        if ((requestCode == GET_PHOTO_STORAGE) &&  (resultCode == RESULT_OK)) {

            Uri uri = data.getData();
            // uploadSelectedImage(data);

            imageS3.uploadImageS3(uri, "images/", null, true);
            try {
                Bitmap imageBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), uri);
                if(isAddToBackground) {
                    setBackgroundPhoto(imageBitmap);
                    //recyclerAdapter.updateData(imageBitmap);
                } else {

                    Log.d(TAG,"ADD BITMAP FROM GALLERY");
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        if (requestCode == GET_PHOTO_DEVICE && resultCode == RESULT_OK) {

            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");

            //uploadImageS3(uri);
            imageS3.uploadImageS3(imageBitmap, "images/", null, true);
            if(isAddToBackground) {
                setBackgroundPhoto(imageBitmap);
                //recyclerAdapter.updateData(imageBitmap);
            } else {

            }

        }
    }


    private void deleteImageFromDynamo(String imageId) {
        final ImagesDO deleteItem = new ImagesDO();

        deleteItem.setUserId(userId);
        deleteItem.setImageId(imageId);
        imagesDynamoDB.delete(deleteItem);

    }
    private void deleteCardFromDynamo(String cardId) {
        final CardsDO deleteItem = new CardsDO();

        deleteItem.setUserId(userId);
        deleteItem.setCardId(cardId);
        CardDynamoDB cardDynamoDB = new CardDynamoDB();
        cardDynamoDB.deleteCard(deleteItem);

    }


    /**
     *this function show alert dialog and direct user to the take photo or choose from gallery
     * @param v
     */
    private void takePhoto(View v) {
        String[] options = {"Choose From Gallery", "Take Photo"};
        android.app.AlertDialog.Builder build = new android.app.AlertDialog.Builder(v.getContext());
        build.setTitle("Choose Image");
        build.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                switch (which) {
                    //choose from gallery
                    case 0:
                        Intent galleryIntent = new Intent();
                        galleryIntent.setType("image/*");
                        galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                        startActivityForResult(Intent.createChooser(galleryIntent, "Select Image"), GET_PHOTO_STORAGE);

                        break;

                    //take a photo using camera
                    case 1:
                        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                            startActivityForResult(takePictureIntent, GET_PHOTO_DEVICE);
                        }
//                        saveCapturedPhotoToFile();
                        break;
                }
            }
        });

        build.show();
    }

    /**
     * This Function show the chose get Video Dialog from device or internal storage
     */
    private void getVideo() {
        String[] options = {"Choose From Gallery"};
        android.app.AlertDialog.Builder build = new android.app.AlertDialog.Builder(this);
        build.setTitle("Choose Video");
        build.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                switch (which) {
                    //choose from gallery
                    case 0:
                        Intent galleryIntent = new Intent();
                        galleryIntent.setType("video/*");
                        galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                        startActivityForResult(Intent.createChooser(galleryIntent, "Select Video"), GET_VIDEO_STORAGE);

                        break;

                }
            }
        });

        build.show();
    }

    /**
     * this function add photo to the card
     * @param photo
     * @param imgSrc
     */
    private void addPhoto(final Bitmap photo, String imgSrc) {
        lastMove.add(R.string.lastMove_entity);
        Layer layer = new Layer();
        ImageEntity entity = new ImageEntity(layer, photo, motionView.getWidth(), motionView.getHeight(), imgSrc);

        motionView.addEntityAndPosition(entity);
    }
    private void setBackgroundPhoto(Bitmap photo) {
        //canvas.setBackgroundDrawable(new BitmapDrawable(getResources(), photo));
        backgroundImage.setImageBitmap(photo);
    }

    @Override
    public void onSuccessLoadDynamo(List<ImagesDO> result) {

        if(result != null) {

            for (final ImagesDO im : result) {
                imagesList.add(im);
                runOnUiThread (new Thread(new Runnable() {
                    public void run() {
                        downloadImages(im.getImageUrl());
                    }
                }));

            }
        }
    }

    @Override
    public void onSuccessUploadS3(String url) {

        ImagesDO newimg = new ImagesDO();
        newimg.setImageUrl(url);
        newimg.setUserId(userId);
        downloadAndAddImages(url, newimg);
    }

    @Override
    public void onSuccessLoadCardsThumbnail(List<Card> cardList) {
        if (cardList != null) {
            for (Card card : cardList) {
                mListCards.add(card.getCardBitmap());
                listCardsWithThumbnail.add(card);
                // Log.i("listcardsize", String.valueOf(listCardsWithThumbnail.size()));
            }

        }
        recyclerAdapter.notifyDataSetChanged();
    }
    @Override
    public void onSuccessLoadText(List<TextStampDO> textStampDOS) {
        if(textStampDOS != null) {
            for(TextStampDO textStampDO : textStampDOS) {
                mTextStampDo.add(textStampDO);
                Log.d(TAG, "Name" + textStampDO.getCsName() + ", SIze: " + textStampDOS.size());
                switch (textStampDO.getCsType()) {
                    case FIRST_NAME :
                        mCsFname.add(textStampDO);
                        break;
                    case LAST_NAME :
                        mCsLname.add(textStampDO);
                        break;
                    case TITLE :
                        mCsTitle.add(textStampDO);
                        break;
                    case PHONE :
                        mCsPhone.add(textStampDO);
                        break;
                    case EMAIL :
                        mCsEmail.add(textStampDO);
                        break;
                    case ADDRESS :
                        mCsAddress.add(textStampDO);
                        break;
                    case WEBLINK :
                        mCsWeblink.add(textStampDO);
                        break;
                }
                cardStampRecyclerAdapter.notifyDataSetChanged();
            }
        }
    }

    @Override
    public void onSuccessLoadStamp(final List<CardStamp> cardStamps) {
        if(cardStamps.size() > 0 ) {
            for (int i = cardStamps.size() - 1; i >= 0; i--) {
                mCardStampItems.add(cardStamps.get(i));
                for (int j = 0; j < cardStamps.get(i).getCsTextEntity().size(); j++) {
                    TextLayer textLayer = dupLayer(cardStamps.get(i).getCsTextEntity().get(j));
                    int width = cardStampMotionView.getWidth();
                    int height = cardStampMotionView.getHeight();
                    Log.d(TAG, "onSuccessLoadStamp: width: " + width + " height: " + height);
                    TextEntity textEntity = new TextEntity(textLayer, width, height, fontProvider);
                    textEntity.setClickableType(cardStamps.get(i).getCsTextEntity().get(j).getClickableType());
                    cardStampMotionView.addEntity(textEntity);
                }
                for (int k  = 0; k < cardStamps.get(i).getCsImageEntity().size(); k++ ){
                    CSImageEntity csImageEntity = cardStamps.get(i).getCsImageEntity().get(k);
                    int imageId = Integer.parseInt(csImageEntity.getImageSource());
                    float rotation = Float.parseFloat(csImageEntity.getRotationInDegrees());
                    float xAxis = Float.parseFloat(csImageEntity.getX());
                    float yAxis = Float.parseFloat(csImageEntity.getY());
                    float scale = Float.parseFloat(csImageEntity.getScale());


                    Layer layer = new Layer();
                    layer.setY(yAxis);
                    layer.setX(xAxis);
                    layer.setScale(scale);
                    layer.setRotationInDegrees(rotation);


                    if (csImageEntity.getDuplicateName() != null) {
                        duplicateSocialIcon(layer, csImageEntity.getDuplicateName(),
                                csImageEntity.getHyperlink(), Integer.parseInt(csImageEntity.getImageSource()));
                    } else {

                        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), mListSocialMedia.get(imageId));
                        ImageEntity entity = new ImageEntity(layer, bitmap, motionView.getWidth(), motionView.getHeight(), String.valueOf(imageId));
                        entity.setImageLink(csImageEntity.getHyperlink());
                        entity.setClickableType(csImageEntity.getClickableType());
                        entity.setOpacity(255);
                        entity.applyOpacity();
                        entity.setImageSrc(csImageEntity.getImageSource());

                        cardStampMotionView.addEntity(entity);
                    }

                }

                if(cardStampMotionView.getEntities() != null ) {
                    BusinessCard businessCard = new BusinessCard();
                    businessCard.setThumbnail(cardStampMotionView.getThumbnailImage());
                    businessCard.setBackground(BitmapFactory.decodeResource(getResources(), R.drawable.empty_canvas));
                    businessCard.setBacksplash(BitmapFactory.decodeResource(getResources(), R.color.transparent));
                    businessCard.setMotionEntities(cardStampMotionView.getEntities());
                    mCardStampBusinessCard.add(businessCard);
                    mCardStampBmp.add(cardStampMotionView.getThumbnailImage());

                    cardStampMotionView.unselectEntity();
                    cardStampMotionView.deleteEntities();
                    cardStampMotionView.invalidate();
                }
            }


        }
    }

    private TextLayer dupLayer(CSTextEntity csTextEntity) {
        Log.d(TAG,"duplicateLayer: called");
        //Create a new Text Layer
        TextLayer textLayer = new TextLayer();

        //Copy Text Properties
        Font font = new Font();
        if (csTextEntity != null) {
            font.setColor(csTextEntity.getFont().getColor());

            font.setSize(csTextEntity.getFont().getSize());
            font.setTypeface(csTextEntity.getFont().getTypeface());

            textLayer.setFont(font);
            //Copy Layer's Scale, Rotation, Flipping
            textLayer.setX(Float.parseFloat(csTextEntity.getX()));
            textLayer.setY(Float.parseFloat(csTextEntity.getY()));
            textLayer.setScale(Float.parseFloat(csTextEntity.getScale()));
            textLayer.setRotationInDegrees(Float.parseFloat(csTextEntity.getRotationInDegrees()));
            textLayer.setFlipped(false);
            textLayer.setText(csTextEntity.getText());

        }
        return textLayer;

    }

    @Override
    public void onSuccessCreateCard(BusinessCard businessCards) {
        Log.i("successLoad","successLoad onSuccessCreateCard"  );
        try {
            Log.d(TAG, "mBusinessCard: size: " + mBusinessCard.size());
            //set background
            motionView.unselectEntity();
            motionView.deleteEntities();
            motionView.invalidate();
            if(businessCards.getBackgroundUrl() !=null ) {
                Image ol = GetIndex.getTheImageDataFromUrl(businessCards.getBackgroundUrl(), mListBackground);
                if(ol != null)
                    backgroundImage.setImageBitmap(ol.getImageBitmap());
                currentBussinessCard.setBackgroundUrl(businessCards.getBackgroundUrl());
            }

            if(businessCards.getBacksplashUrl() !=null ) {
                Image ol = GetIndex.getTheImageDataFromUrl(businessCards.getBacksplashUrl(), mListBacksplash);
                if(ol != null)
                    backsplashImage.setImageBitmap(ol.getImageBitmap());
                currentBussinessCard.setBacksplashUrl(businessCards.getBacksplashUrl());
            }
            currentBussinessCard.setMotionEntities(businessCards.getMotionEntities());
            //create duplicate
            List<MotionEntity> motionEntities = businessCards.getMotionEntities();//retrieve entities

            List<MotionEntity> duplicateEntities = new ArrayList<>();

            for (int y = 0; y < motionEntities.size(); y++) {
                if(motionEntities.get(y) instanceof TextEntity) {
                    //((TextEntity) motionView.getSelectedEntity());
                    TextEntity textEntity = duplicateTextEntity((TextEntity) motionEntities.get(y));
                    duplicateEntities.add(textEntity);
                    Log.d(TAG,"myCards: Duplicate: text entity");
                }
                else {
                    ImageEntity imageEntity = (ImageEntity) motionEntities.get(y);
                    duplicateEntities.add(imageEntity);

                    Log.d(TAG,"myCards: Duplicate: image entity");
                }
            }

            for (int x = 0; x < duplicateEntities.size(); x++) {
                motionView.addEntity(duplicateEntities.get(x));
                Log.i("overwrite", String.valueOf(motionView.getEntities().size()));
            }

            clearUndos();
        }catch (NullPointerException ne) {
            ne.printStackTrace();
        }

    }

    @Override
    public void onDeleteTextSuccess(TextStampDO textStampDO) {
        Log.d(TAG, "DELETE DELETE DELETE DELETE!" + textStampDO.isSelected());
        textStampDynamoDB.delete(textStampDO);
    }

    @Override
    public void onUpdateTextSuccess(TextStampDO textStampDO) {
        textStampDynamoDB.addTextStamp(textStampDO);
    }



    @Override
    public void onUpdateSocialMedia(SocialMedia socialMedia, int pos) {
        if (mSocialMedia != null) {
            mSocialMedia.remove(pos);
            mSocialMedia.add(pos, socialMedia);
            Hyperlink hyperlink = new Hyperlink();
            hyperlink.setUserId(userId);
            hyperlink.setSocialMedia(mSocialMedia);
            hyperlinkDynamoDB.saveHyperlink(hyperlink);
        }
    }

    @Override
    public void OnSuccessLoadHyperlink(List<Hyperlink> hyperlinkList) {
        if (hyperlinkList.size() > 0) {
            Hyperlink hyperlink = hyperlinkList.get(0);
            List<SocialMedia> socialMedia = hyperlink.getSocialMedia();
            for (int i = 0; i < socialMedia.size(); i++ ) {
                mSocialMedia.add(socialMedia.get(i));
                switch (socialMedia.get(i).getSmType()) {
                    case FACEBOOK:
                        mSmFacebook.add(socialMedia.get(i));
                        break;
                    case GOOGLE:
                        mSmGoogle.add(socialMedia.get(i));
                        break;
                    case INSTAGRAM:
                        mSmInstagram.add(socialMedia.get(i));
                        break;
                    case LINKEDIN:
                        mSmLinkedIn.add(socialMedia.get(i));
                        break;
                    case EMAIL:
                        mSmEmail.add(socialMedia.get(i));
                        break;
                    case PINTEREST:
                        mSmPinterest.add(socialMedia.get(i));
                        break;
                    case SKYPE:
                        mSmSkype.add(socialMedia.get(i));
                        break;
                    case TUMBLR:
                        mSmTumblr.add(socialMedia.get(i));
                        break;
                    case TWITTER:
                        mSmTwitter.add(socialMedia.get(i));
                        break;
                    case WHATSAPP:
                        mSmWhatsapp.add(socialMedia.get(i));
                        break;
                }
                recyclerAdapter.notifyDataSetChanged();
            }
        }
        uncheckHyperlink();

    }

    @Override
    protected void onPause() {
        // Unregister since the activity is paused.
        super.onPause();
        unregisterReceiver(broadcastReceiver);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // An IntentFilter can match against actions, categories, and data
        IntentFilter filter = new IntentFilter();
        filter.addAction(UPLOAD_VIDEO_S3_COMPLETED);
        filter.addAction(UPLOAD_VIDEO_THUMBNAIL_S3_COMPLETED);
        filter.addAction(LOAD_VIDEO_INFO_DONE);
        filter.addAction(LOAD_SINGLE_VIDEO_INFO_DONE);
        filter.addAction(DONE_LOAD_OVERLAYS);


        registerReceiver(broadcastReceiver,filter);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(CardMaker.this, MenuScreen.class);
        startActivity(i);
        finish();
    }
}