package com.example.arago.tapiolla.nfc;

import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.NfcEvent;

public class NfcManager implements NfcAdapter.CreateNdefMessageCallback,
        NfcAdapter.OnNdefPushCompleteCallback {
    public static final String MIME = "application/vnd.com.example.arago.tapiolla.nfc";
    private NfcSend send;

    public NfcManager(NfcSend send) {
        this.send = send;
    }
    @Override
    public NdefMessage createNdefMessage(NfcEvent event) {
        String text = ("Beam me up, Android!\n\n" +
                "Beam Time: " + System.currentTimeMillis());
        NdefMessage msg = new NdefMessage(
                new NdefRecord[] {
                        NdefRecord.createMime(
                                MIME,
                                text.getBytes())
                });
        return msg;
    }

    @Override
    public void onNdefPushComplete(NfcEvent event) {
        send.signalResult();
    }

    /*
     * Callback to be implemented by a Sender activity
     * */
    public interface NfcSend {

        String getOutcomingMessage();

        void signalResult();
    }
}
