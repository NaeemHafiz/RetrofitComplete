package com.example.arago.tapiolla.controller;

import com.example.arago.tapiolla.authentication.AWSLoginModel;

public class Authenticate {

    /**
     *
     * @param awsLoginModel
     * @param email
     * @param name
     * @param phone
     * @param password
     */
    public static void registerAction(AWSLoginModel awsLoginModel, String email, String name, String phone, String password ) {

        // do register and handles on interface
        awsLoginModel.registerUser(email,name, phone, password);
    }
}
