package com.example.arago.tapiolla.convertion;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.database.CardDynamoDB;
import com.example.arago.tapiolla.database.DynamoSettings;
import com.example.arago.tapiolla.models.CardsDO;
import com.example.arago.tapiolla.models.entities.ImageEntitiesDO;
import com.example.arago.tapiolla.models.entities.TextEntitiesDO;
import com.example.arago.tapiolla.models.stamp.CSImageEntity;
import com.example.arago.tapiolla.models.stamp.CSTextEntity;
import com.example.arago.tapiolla.motion_views.utils.FontProvider;
import com.example.arago.tapiolla.motion_views.viewmodel.Layer;
import com.example.arago.tapiolla.motion_views.viewmodel.TextLayer;
import com.example.arago.tapiolla.motion_views.widget.MotionView;
import com.example.arago.tapiolla.motion_views.widget.entity.ImageEntity;
import com.example.arago.tapiolla.motion_views.widget.entity.MotionEntity;
import com.example.arago.tapiolla.motion_views.widget.entity.TextEntity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RecreateCard{
    Context context;
    CardDynamoDB cardDynamoDB;
    List<MotionEntity> motionEntities;
    MotionView motionView;
    private ArrayList<Boolean> completed;
    private int loadedNumber;
    private OnSuccessCreateCard onSuccessCreateCard;
    BusinessCard businessCard;
    FontProvider fontProvider;

    public CardDynamoDB getCardDynamoDB() {
        return cardDynamoDB;
    }

    public RecreateCard(Context context, DynamoSettings dynamoSettings, MotionView motionView, OnSuccessCreateCard successCreateCardCallback, FontProvider fontProvider) {
        this.context = context;
        cardDynamoDB = new CardDynamoDB();
        this.motionView = motionView;
        motionEntities = new ArrayList<>();
        completed = new ArrayList<>();
        loadedNumber = 0;
        this.onSuccessCreateCard = successCreateCardCallback;
        //initial business card
        businessCard = new BusinessCard();
        this.fontProvider = fontProvider;
    }

    public void recreateCard(CardsDO card) {
       // cardDynamoDB.getAllCardEntities(card);
        Log.i("cardid", card.getCardId());
        businessCard.setBackgroundUrl(card.getBackgroundImgId());
        businessCard.setBacksplashUrl(card.getBacksplashImgId());
        loadAllResources(card.getImagesEntities(), card.getTextEntities());
    }
    private void getImageBitmapFromPath(int i, int size, CSImageEntity ie) {
        final String path = ie.getImageSource();
        final Bitmap[] bm = new Bitmap[1];
        loadedNumber++;
        String[] temp = { "0", "1", "2", "3", "4", "5", "6","7", "8", "9" };

        if (Arrays.asList(temp).contains(path)) {
            switch (path) {
                case "0":  bm[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.social_media_facebook); break;
                case "1":  bm[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.social_media_google); break;
                case "2":  bm[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.social_media_instagram); break;
                case "3":  bm[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.social_media_linkedin); break;
                case "4":  bm[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.social_media_mail); break;
                case "5":  bm[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.social_media_pinterest); break;
                case "6":  bm[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.social_media_skype); break;
                case "7":  bm[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.social_media_tumblr); break;
                case "8":  bm[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.social_media_twitter); break;
                case "9":  bm[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.social_media_whatsapp); break;
                default: bm[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.social_media_facebook); break;
            }
            Layer layer = new Layer();
            layer.setRotationInDegrees(Float.parseFloat(ie.getRotationInDegrees()));
            layer.setScale(Float.parseFloat(ie.getScale()));
            layer.setX(Float.parseFloat(ie.getX()));
            layer.setY(Float.parseFloat(ie.getY()));

            ImageEntity entity = new ImageEntity(layer, bm[0], motionView.getWidth(), motionView.getHeight(), ie.getImageSource());
            entity.setImageLink(ie.getHyperlink());
            motionEntities.add(entity);
            Log.i("entity","enty" + String.valueOf(motionEntities.size()));
            // set this one to completed
            completed.set(i, true);
            // check if complete send data to callback

            if((loadedNumber == size ) && checkCompleted()) {
                businessCard.setMotionEntities(motionEntities);
                onSuccessCreateCard.onSuccessCreateCard(businessCard);
            }
        } else {
           // downloadImages(ie, motionEntities);
            downloadImage(i,size,ie);
        }


    }
    private boolean checkCompleted() {

        for (boolean com : completed) {
            if(!com) return false;
        }
        return true;
    }
    private void downloadImage(final int i, final int size, final CSImageEntity ie) {
        final Bitmap[] temp = new Bitmap[1];
        Glide.with(context)
                .asBitmap()
                .load(ie.getImageSource())
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        Layer layer = new Layer();
                        layer.setRotationInDegrees(Float.parseFloat(ie.getRotationInDegrees()));
                        layer.setScale(Float.parseFloat(ie.getScale()));
                        layer.setX(Float.parseFloat(ie.getX()));
                        layer.setY(Float.parseFloat(ie.getY()));

                        ImageEntity entity = new ImageEntity(layer, resource, motionView.getWidth(), motionView.getHeight(), ie.getImageSource());
                        entity.setImageLink(ie.getHyperlink());
                        motionEntities.add(entity);
                        // set this one to completed
                        completed.set(i, true);
                        // check if complete send data to callback
                        if((loadedNumber == size ) && checkCompleted()) {
                            businessCard.setMotionEntities(motionEntities);
                            onSuccessCreateCard.onSuccessCreateCard(businessCard);
                        }
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                    }
                });
    }

    private void loadAllResources(List<CSImageEntity> imageEntityList, List<CSTextEntity> textEntitiesDOList) {
        if(textEntitiesDOList != null) {
            int size = textEntitiesDOList.size();

            for (int i = 0; i< size; i++) {
                CSTextEntity te = textEntitiesDOList.get(i);
                TextLayer layer = new TextLayer();
                layer.setRotationInDegrees(Float.parseFloat(te.getRotationInDegrees()));
                layer.setScale(Float.parseFloat(te.getScale()));
                layer.setX(Float.parseFloat(te.getX()));
                layer.setY(Float.parseFloat(te.getY()));
                layer.setFont(te.getFont());
                layer.setText(te.getText());

                TextEntity entity = new TextEntity(layer, motionView.getWidth(), motionView.getHeight(),fontProvider);
                entity.setClickableType(te.getClickableType());
                motionEntities.add(entity);
            }
            Log.i("successLoad","successLoad motionEntities" + String.valueOf(motionEntities.size()) );
//            businessCard.setMotionEntities(motionEntities);
//            onSuccessCreateCard.onSuccessCreateCard(businessCard);
//            Log.i("successLoad","successLoad businessCard"  );
        }
        if (imageEntityList != null && imageEntityList.size() != 0) {
            int size = imageEntityList.size();
            for (int i = 0; i< size; i++) {
                //crete a list to check all tasks are completed
                completed.add(false);
                getImageBitmapFromPath(i,size,imageEntityList.get(i));

            }
        } else {
            businessCard.setMotionEntities(motionEntities);
            onSuccessCreateCard.onSuccessCreateCard(businessCard);
            Log.i("successLoad","successLoad businessCard"  );
        }
    }


    public interface OnSuccessCreateCard {
        void onSuccessCreateCard(BusinessCard businessCards);
    }
}
