package com.example.arago.tapiolla.authentication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobile.auth.core.DefaultSignInResultHandler;
import com.amazonaws.mobile.auth.core.IdentityManager;
import com.amazonaws.mobile.auth.core.IdentityProvider;
import com.amazonaws.mobile.auth.google.GoogleSignInProvider;
import com.amazonaws.mobile.auth.userpools.CognitoUserPoolsSignInProvider;
import com.amazonaws.mobile.config.AWSConfiguration;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoDevice;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUser;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUserAttributes;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUserCodeDeliveryDetails;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUserDetails;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUserPool;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUserSession;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.continuations.AuthenticationContinuation;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.continuations.AuthenticationDetails;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.continuations.ChallengeContinuation;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.continuations.ForgotPasswordContinuation;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.continuations.MultiFactorAuthenticationContinuation;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.handlers.AuthenticationHandler;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.handlers.ForgotPasswordHandler;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.handlers.GenericHandler;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.handlers.GetDetailsHandler;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.handlers.SignUpHandler;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.handlers.VerificationHandler;
import com.amazonaws.regions.Regions;
import com.example.arago.tapiolla.ui.MenuScreen;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AWSLoginModel {

        // constants
        private final String ATTR_EMAIL = "email";
        private static final String SHARED_PREFERENCE = "SavedValues";
        private static final String PREFERENCE_USER_EMAIL = "awsUserEmail";
        public static final int PROCESS_SIGN_IN = 1;
        public static final int PROCESS_REGISTER = 2;
        public static final int PROCESS_CONFIRM_REGISTRATION = 3;
        public static final int PROCESS_SEND_CODE =4;
        public static final int PROCESS_FORGOT_PASSWORD =5;
        public static final int PROCESS_FORGOT_PASSWORD_SENT_CODE =6;
         public static final int PROCESS_CHANGE_PASSWORD =7;
        // interface handler
        private AWSLoginHandler mCallback;
        private AWSVerificationHandler mVeriCallback;
        // control variables
        private String userEmail, userPassword;
        private Context mContext;
        private CognitoUserPool mCognitoUserPool;
        private CognitoUser mCognitoUser;
        private CognitoCachingCredentialsProvider credentialsProvider;
        IdentityManager identityManager;

        private final AuthenticationHandler authenticationHandler = new AuthenticationHandler() {
            @Override
            public void onSuccess(CognitoUserSession userSession, CognitoDevice newDevice) {
                // Get details of the logged user (in this case, only the e-mail)
                mCognitoUser.getDetailsInBackground(new GetDetailsHandler() {
                    @Override
                    public void onSuccess(CognitoUserDetails cognitoUserDetails) {
                        // Save in SharedPreferences
                        SharedPreferences.Editor editor = mContext.getSharedPreferences(SHARED_PREFERENCE, Context.MODE_PRIVATE).edit();
                        String email = cognitoUserDetails.getAttributes().getAttributes().get(ATTR_EMAIL);
                        editor.putString(PREFERENCE_USER_EMAIL, email);
                        editor.apply();
                    }

                    @Override
                    public void onFailure(Exception exception) {
                        exception.printStackTrace();
                    }
                });

                // Save in SharedPreferences
                SharedPreferences.Editor editor = mContext.getSharedPreferences(SHARED_PREFERENCE, Context.MODE_PRIVATE).edit();
                editor.putString(PREFERENCE_USER_EMAIL, userEmail);
                editor.apply();
                mCallback.onSuccess(PROCESS_SIGN_IN);
            }

            @Override
            public void getAuthenticationDetails(AuthenticationContinuation authenticationContinuation, String userId) {
                final AuthenticationDetails authenticationDetails = new AuthenticationDetails(userEmail, userPassword, null);
                authenticationContinuation.setAuthenticationDetails(authenticationDetails);
                authenticationContinuation.continueTask();

                userPassword = "";
            }

            @Override
            public void getMFACode(MultiFactorAuthenticationContinuation continuation) {
                // Not implemented for this Model
            }

            @Override
            public void authenticationChallenge(ChallengeContinuation continuation) {
                // Not implemented for this Model
            }

            @Override
            public void onFailure(Exception exception) {
                mCallback.onFailure(PROCESS_SIGN_IN, exception);
            }
        };
    /** resend password handler */
    private  final VerificationHandler resendCodeHandler = new VerificationHandler() {
        @Override
        public void onSuccess(CognitoUserCodeDeliveryDetails verificationCodeDeliveryMedium) {
            mVeriCallback.onSendCodeSuccess();
        }

        @Override
        public void onFailure(Exception exception) {
            mVeriCallback.onFailure(PROCESS_SEND_CODE,exception);
        }
    };
    private ForgotPasswordContinuation resultContinuation;

    /** forgot password handler */

    final ForgotPasswordHandler forgotPasswordHandler = new ForgotPasswordHandler() {
        @Override
        public void onSuccess() {
            mCallback.onSuccess(PROCESS_CHANGE_PASSWORD);
        }

        @Override
        public void getResetCode(ForgotPasswordContinuation continuation) {
            mCallback.onSuccess(PROCESS_FORGOT_PASSWORD_SENT_CODE);
            resultContinuation = continuation;
        }

        @Override
        public void onFailure(Exception exception) {
            mCallback.onFailure(PROCESS_FORGOT_PASSWORD,exception);
        }
    };
    /** change password handler */
    final GenericHandler handler = new GenericHandler() {
        @Override
        public void onSuccess() {
            Toast.makeText(mContext, "Successfully changed password!", Toast.LENGTH_SHORT).show();
            Log.i("success change password","success change password");
        }

        @Override
        public void onFailure(Exception exception) {
            Toast.makeText(mContext, "Failed change password!", Toast.LENGTH_SHORT).show();
            Log.i("success change password","failed change password");
        }
    };
        /**
         * Constructs the model for login functions in AWS Mobile Hub.
         *
         * @param context  REQUIRED: Android application context.
         * @param callback REQUIRED: Callback handler for login operations.
         */
        public AWSLoginModel(Context context, AWSLoginHandler callback) {
            initialize(context);
            mCallback = callback;
        }

    /**
     * Constructs the model for login functions in AWS Mobile Hub.
     * @param context current context
     */
    public AWSLoginModel(Context context) {
        initialize(context);
    }

    /**
     * Constructs the model for login functions in AWS Mobile Hub.
     * @param context current context
     * @param callback aws verification callback
     */
    public AWSLoginModel(Context context, AWSVerificationHandler callback) {

        initialize(context);

        mVeriCallback = callback;
    }

    /**
     * Initialize all fields for constructor
     * @param context current context
     */
    private void initialize(Context context) {
        mContext = context;
        identityManager = new IdentityManager(context, new AWSConfiguration(context));

        IdentityManager.setDefaultIdentityManager(identityManager);
        IdentityManager.getDefaultIdentityManager().addSignInProvider(CognitoUserPoolsSignInProvider.class);
        //IdentityManager.getDefaultIdentityManager().addSignInProvider(FacebookSignInProvider.class);
        //IdentityManager.getDefaultIdentityManager().addSignInProvider(GoogleSignInProvider.class);
        try {
            JSONObject myJSON = identityManager.getConfiguration().optJsonObject("CognitoUserPool");
            final String COGNITO_POOL_ID = myJSON.getString("PoolId");
            final String COGNITO_CLIENT_ID = myJSON.getString("AppClientId");
            final String COGNITO_CLIENT_SECRET = myJSON.getString("AppClientSecret");
            final String REGION = myJSON.getString("Region");
            mCognitoUserPool = new CognitoUserPool(context, COGNITO_POOL_ID, COGNITO_CLIENT_ID, COGNITO_CLIENT_SECRET, Regions.fromName(REGION));

            credentialsProvider = new CognitoCachingCredentialsProvider(
                    mContext,
                    COGNITO_POOL_ID, // Identity pool ID
                    Regions.US_WEST_2 // Region
            );
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    /**
     * Registers new user to the AWS Cognito User Pool.
     * <p>
     * This will trigger {@link AWSLoginHandler} interface defined when the constructor was called.
     *
     * @param email    REQUIRED: E-mail to be registered. Must be unique in the User Pool.
     * @param password REQUIRED: Password of this new account.
     * @param name    REQUIRED: Full name of new user.
     * @param phone   REQUIRED: Phone of this new account.
     */
    public void registerUser(final String email, String name, String phone, String password) {
        CognitoUserAttributes userAttributes = new CognitoUserAttributes();
        userAttributes.addAttribute("given_name", name);
        userAttributes.addAttribute("phone_number", phone);
        userAttributes.addAttribute("email", email);

        final SignUpHandler signUpHandler = new SignUpHandler() {
            @Override
            public void onSuccess(CognitoUser user, boolean signUpConfirmationState, CognitoUserCodeDeliveryDetails cognitoUserCodeDeliveryDetails) {
                mCognitoUser = user;
                mCallback.onRegisterSuccess(!signUpConfirmationState, email);
            }

            @Override
            public void onFailure(Exception exception) {
                mCallback.onFailure(PROCESS_REGISTER, exception);
            }
        };

        mCognitoUserPool.signUpInBackground(email, password, userAttributes, null, signUpHandler);
    }

    /**
     * Confirms registration of the new user in AWS Cognito User Pool.
     * <p>
     * This will trigger {@link AWSLoginHandler} interface defined when the constructor was called.
     *
     * @param confirmationCode REQUIRED: Code sent from AWS to the user.
     */
    public void confirmRegistration(String confirmationCode, String userEmail) {
        final GenericHandler confirmationHandler = new GenericHandler() {
            @Override
            public void onSuccess() {
                mVeriCallback.onRegisterConfirmed();
            }

            @Override
            public void onFailure(Exception exception) {
                mVeriCallback.onFailure(PROCESS_CONFIRM_REGISTRATION, exception);
            }
        };
        this.userEmail = userEmail;
        mCognitoUser = mCognitoUserPool.getUser(userEmail);

        mCognitoUser.confirmSignUpInBackground(confirmationCode, false, confirmationHandler);
        //mCognitoUserPool.getCurrentUser().confirmSignUpInBackground(confirmationCode, false, confirmationHandler);
    }

    /**
     * Sign in process. If succeeded, this will save the user name and e-mail in SharedPreference of
     * this context.
     * <p>
     * This will trigger {@link AWSLoginHandler} interface defined when the constructor was called.
     *
     * @param email REQUIRED:  e-mail.
     * @param userPassword    REQUIRED: Password.
     */
    public void signInUser(String email, String userPassword) {
        this.userEmail = email;
        this.userPassword = userPassword;

        mCognitoUser = mCognitoUserPool.getUser(userEmail);
        mCognitoUser.getSessionInBackground(authenticationHandler);
    }
    /**
     * Resend code.
     * this context.
     * <p>
     * This will trigger {@link AWSLoginHandler} interface defined when the constructor was called.
     *
     * @param userNameOrEmail REQUIRED: Username or e-mail.
     *
     */
    public void resendVerificationCode(String userNameOrEmail) {
        this.userEmail = userNameOrEmail;
        mCognitoUser = mCognitoUserPool.getUser(userEmail);
        mCognitoUser.resendConfirmationCodeInBackground(resendCodeHandler);
    }

    /**
     * Forgot Password.
     * this context.
     * <p>
     * This will trigger {@link AWSLoginHandler} interface defined when the constructor was called.
     *
     * @param email REQUIRED: e-mail.
     *
     */
    public void forgotPassword(String email) {
        this.userEmail = email;
        mCognitoUser = mCognitoUserPool.getUser(userEmail);
        mCognitoUser.forgotPasswordInBackground(forgotPasswordHandler);
    }

    public void changeAccountPassword(String email, String oldPassword, String newPassword) {
        this.userEmail = email;
        mCognitoUser = mCognitoUserPool.getUser(userEmail);
        mCognitoUser.changePasswordInBackground(oldPassword, newPassword, handler );
    }
    /**
     * This method change password with the verification code
     * @param userPassword
     * @param confirmCode
     */
    public void changePassword(String userPassword, String confirmCode) {
        resultContinuation.setPassword(userPassword);
        resultContinuation.setVerificationCode(confirmCode);
        resultContinuation.continueTask();
    }
    /**
     * Gets the user e-mail saved in SharedPreferences.
     *
     * @param context REQUIRED: Android application context.
     * @return user e-mail saved in SharedPreferences.
     */
    public static String getSavedUserEmail(Context context) {
        SharedPreferences savedValues = context.getSharedPreferences(SHARED_PREFERENCE, Context.MODE_PRIVATE);
        return savedValues.getString(PREFERENCE_USER_EMAIL, "");
    }
    public void federateWithGoogle(GoogleSignInAccount account){
        if(account.getIdToken() != null) {
            final String idToken = account.getIdToken();
           // credentialsProvider = IdentityManager.getDefaultIdentityManager().getUnderlyingProvider();
            Map<String, String> logins = new HashMap<String, String>();
            logins.put("accounts.google.com", idToken);
           // credentialsProvider.clear();
            credentialsProvider.setLogins(logins);
            Log.i("token", idToken);
//            new Thread(new Runnable() {
//                @Override
//                public void run() {
//
//                    // Signed in successfully, show authenticated UI.
//                }
//            });
        }
    }

    public void federateWithFacebook() {

    }

    public void doSignIn() {
        identityManager.setUpToAuthenticate(
                mContext, new DefaultSignInResultHandler() {

                    @Override
                    public void onSuccess(Activity activity, IdentityProvider identityProvider) {
                        if (identityProvider != null) {

                            // Sign-in succeeded
                            // The identity provider name is available here using:
                            //     identityProvider.getDisplayName()

                        }

                        // On Success of SignIn go to your startup activity
                        mContext.startActivity(new Intent(mContext, MenuScreen.class)
                                .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    }

                    @Override
                    public boolean onCancel(Activity activity) {

                        // Return false to prevent the user from dismissing
                        // the sign in screen by pressing back button.
                        // Return true to allow this.

                        return false;
                    }
                });
//        AWSMobileClient.getInstance().initialize(this, new AWSStartupHandler() {
//            @Override
//            public void onComplete(final AWSStartupResult awsStartupResult) {
//                AuthUIConfiguration config =
//                        new AuthUIConfiguration.Builder()
//                                //.userPools(true)  // true? show the Email and Password UI
//                                .signInButton(FacebookButton.class) // Show Facebook button
//                                .signInButton(GoogleButton.class) // Show Google button
//                                //.logoResId(R.drawable.mylogo) // Change the logo
//                                //.backgroundColor(Color.BLUE) // Change the backgroundColor
//                                .isBackgroundColorFullScreen(true) // Full screen backgroundColor the backgroundColor full screenff
//                                //.fontFamily("sans-serif-light") // Apply sans-serif-light as the global font
//                                .canCancel(true)
//                                .build();
//                SignInUI signinUI = (SignInUI) AWSMobileClient.getInstance().getClient(mContext, SignInUI.class);
//                signinUI.login(mContext, MenuScreen.class).authUIConfiguration(config).execute();
//            }
//        }).execute();
//        AuthUIConfiguration config =
//                new AuthUIConfiguration.Builder()
//                        .signInButton(FacebookButton.class)
//                        .signInButton(GoogleButton.class)
//                        // .userPools(true)
//                        .build();
//
//        //Context context = SplashActivity.this;
//        SignInActivity.startSignInActivity(mContext, config);

    }
}
