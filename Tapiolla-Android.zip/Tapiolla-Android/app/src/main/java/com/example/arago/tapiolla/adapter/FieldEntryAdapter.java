package com.example.arago.tapiolla.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.database.DynamoSettings;
import com.example.arago.tapiolla.database.TextStampDynamoDB;
import com.example.arago.tapiolla.models.hyperlinks.Hyperlink;
import com.example.arago.tapiolla.models.hyperlinks.SocialMedia;
import com.example.arago.tapiolla.models.stamp.CardStamp;
import com.example.arago.tapiolla.models.stamp.TextStampDO;

import java.util.List;

import static com.example.arago.tapiolla.Constant.EMAIL;
import static com.example.arago.tapiolla.Constant.FACEBOOK;
import static com.example.arago.tapiolla.Constant.GOOGLE;
import static com.example.arago.tapiolla.Constant.INSTAGRAM;
import static com.example.arago.tapiolla.Constant.LINKEDIN;
import static com.example.arago.tapiolla.Constant.PINTEREST;
import static com.example.arago.tapiolla.Constant.SKYPE;
import static com.example.arago.tapiolla.Constant.TUMBLR;
import static com.example.arago.tapiolla.Constant.TWITTER;
import static com.example.arago.tapiolla.Constant.WHATSAPP;

public class FieldEntryAdapter extends RecyclerView.Adapter<FieldEntryAdapter.ViewHolder> {

    private LayoutInflater mLayoutInflater;
    private List<Integer> itemList;
    private List<TextStampDO> stringList;
    private List<SocialMedia> socialMediaList;
    private String type;
    private SparseBooleanArray itemState = new SparseBooleanArray();
    private DynamoSettings dynamoSettings;
    private TextStampDynamoDB textStampDynamoDB;
    private OnUpdateTextStamp onUpdateTextStamp;
    private Boolean isSocialMedia = false;

   public interface OnUpdateTextStamp {
       void onDeleteTextSuccess(TextStampDO textStampDO);
       void onUpdateTextSuccess(TextStampDO textStampDO);
       void onUpdateSocialMedia(SocialMedia socialMedia, int pos);
   }

    public FieldEntryAdapter(Context context, List<TextStampDO> stringList, String type,
                             DynamoSettings dynamoSettings, OnUpdateTextStamp callback) {
        mLayoutInflater = LayoutInflater.from(context);
        this.stringList = stringList;
        this.type = type;
        this.dynamoSettings = dynamoSettings;
        onUpdateTextStamp = callback;
        isSocialMedia = false;
    }

    public FieldEntryAdapter(Context context, List<SocialMedia> socialMediaList, String type, DynamoSettings dynamoSettings,
                             OnUpdateTextStamp callback, Boolean isSocialMedia) {
       mLayoutInflater = LayoutInflater.from(context);
       this.socialMediaList = socialMediaList;
       this.type = type;
       this.dynamoSettings = dynamoSettings;
       this.isSocialMedia = true;
       onUpdateTextStamp = callback;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = mLayoutInflater.inflate(R.layout.field_entry_layout, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

        if (isSocialMedia) {
            viewHolder.smIcon.setVisibility(View.VISIBLE);
            viewHolder.fieldDelete.setVisibility(View.INVISIBLE);
            final SocialMedia socialMedia = socialMediaList.get(i);
            switch (socialMedia.getSmType()) {
                case FACEBOOK:
                    viewHolder.smIcon.setImageResource(R.drawable.social_media_facebook);
                    break;
                case GOOGLE:viewHolder.smIcon.setImageResource(R.drawable.social_media_google);
                    break;
                case INSTAGRAM:
                    viewHolder.smIcon.setImageResource(R.drawable.social_media_instagram);
                    break;
                case LINKEDIN:
                    viewHolder.smIcon.setImageResource(R.drawable.social_media_linkedin);
                    break;
                case EMAIL:
                    viewHolder.smIcon.setImageResource(R.drawable.social_media_mail);
                    break;
                case PINTEREST:
                    viewHolder.smIcon.setImageResource(R.drawable.social_media_pinterest);
                    break;
                case SKYPE:
                    viewHolder.smIcon.setImageResource(R.drawable.social_media_skype);
                    break;
                case TUMBLR:
                    viewHolder.smIcon.setImageResource(R.drawable.social_media_tumblr);
                    break;
                case TWITTER:
                    viewHolder.smIcon.setImageResource(R.drawable.social_media_twitter);
                    break;
                case WHATSAPP:
                    viewHolder.smIcon.setImageResource(R.drawable.social_media_whatsapp);
                    break;
            }


            final int pos = i;
            viewHolder.fieldText.setText(socialMedia.getSmName());
            itemState.put(pos, socialMedia.isSelected());
            viewHolder.fieldCheckBox.setOnCheckedChangeListener(null);
            viewHolder.fieldCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    socialMedia.setSelected(b);
                    itemState.put(pos, socialMedia.isSelected());
                    onUpdateTextStamp.onUpdateSocialMedia(socialMedia, pos);
                }
            });
            viewHolder.bindSocialMedia(i);
//            viewHolder.fieldDelete.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    stringList.remove(pos);
//                    itemState.delete(pos);
//                    notifyDataSetChanged();
//                    onUpdateTextStamp.onUpdateSocialMedia(socialMedia);
//                }
//            });

        } else {
            viewHolder.smIcon.setVisibility(View.INVISIBLE);
            viewHolder.fieldDelete.setVisibility(View.VISIBLE);
            final TextStampDO cardStamp = stringList.get(i);
            final int pos = i;
            viewHolder.fieldText.setText(cardStamp.getCsName());
            cardStamp.setCsType(type);
            itemState.put(pos, cardStamp.isSelected());
            //viewHolder.fieldCheckBox.setChecked(cardStamp.isSelected());
            viewHolder.fieldCheckBox.setOnCheckedChangeListener(null);
            viewHolder.fieldCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    cardStamp.setSelected(b);
                    itemState.put(pos, cardStamp.isSelected());
                    onUpdateTextStamp.onUpdateTextSuccess(cardStamp);
                }
            });
            viewHolder.bind(i);
            viewHolder.fieldDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    stringList.remove(pos);
                    itemState.delete(pos);
                    notifyDataSetChanged();
                    onUpdateTextStamp.onDeleteTextSuccess(cardStamp);
                }
            });
        }

    }



    public void uncheckAll(){
       if (stringList != null) {
           for(int i = 0; i < stringList.size(); i++) {
               TextStampDO textStampDO = stringList.get(i);
               textStampDO.setSelected(false);
               onUpdateTextStamp.onUpdateTextSuccess(textStampDO);
           }
           itemState.clear();
           notifyDataSetChanged();
       }

       if (socialMediaList != null ) {
           for (int i = 0; i < socialMediaList.size(); i++) {
               socialMediaList.get(i).setSelected(false);
           }
            notifyDataSetChanged();
       }
    }

    @Override
    public int getItemCount() {
       if (isSocialMedia) {
           Log.d("TEST", "TESTTESTTEST: " + socialMediaList.size());
           return socialMediaList.size();
       }
        return stringList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView fieldText;
        CheckBox fieldCheckBox;
        ImageView fieldDelete, smIcon;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            fieldText = itemView.findViewById(R.id.field_entry_text);
            fieldCheckBox = itemView.findViewById(R.id.field_entry_checkbox);
            fieldDelete = itemView.findViewById(R.id.field_entry_delete);
            smIcon = itemView.findViewById(R.id.sm_icon);

        }

        @Override
        public void onClick(View view) {
//            int position = getAdapterPosition();
//            if (!itemState.get(position, false)) {
//                fieldCheckBox.setChecked(true);
//                stringList.get(position).setSelected(true);
//                itemState.put(position, true);
//            } else {
//                fieldCheckBox.setChecked(false);
//                stringList.get(position).setSelected(false);
//                itemState.put(position, false);
//            }
        }

        void bind(int position) {
            if (!itemState.get(position, false)) {
                fieldCheckBox.setChecked(false);
                stringList.get(position).setSelected(false);
            } else {
                fieldCheckBox.setChecked(true);
                stringList.get(position).setSelected(true);
            }
        }

        void bindSocialMedia(int position) {
            if (!itemState.get(position, false)) {
                fieldCheckBox.setChecked(false);
                socialMediaList.get(position).setSelected(false);
            } else {
                fieldCheckBox.setChecked(true);
                socialMediaList.get(position).setSelected(false);
            }
        }
    }
}
