package com.example.arago.tapiolla.models;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;
import com.example.arago.tapiolla.models.user.Address;
import com.example.arago.tapiolla.models.user.UserSettings;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

@DynamoDBTable(tableName = "tapiolla-mobilehub-396882117-User")

public class UserDO implements Serializable {
    private String _userId;
    private String _fullName;
    private String _userEmail;
    private Address _address;
    private String _phoneNumber;
    private UserSettings _userSettings;


    @DynamoDBHashKey(attributeName = "userId")
    @DynamoDBAttribute(attributeName = "userId")
    public String getUserId() {
        return _userId;
    }
    public void setUserId(final String _userId) {
        this._userId = _userId;
    }

    @DynamoDBAttribute(attributeName = "fullName")
    public String getFullName() {
        return _fullName;
    }
    public void setFullName(String _fullName) {
        this._fullName = _fullName;
    }

    @DynamoDBAttribute(attributeName = "email")
    public String getUserEmail() {
        return _userEmail;
    }
    public void setUserEmail(String _userEmail) {
        this._userEmail = _userEmail;
    }

    @DynamoDBAttribute(attributeName = "phoneNumber")
    public String getPhoneNumber() {
        return _phoneNumber;
    }
    public void setPhoneNumber(String _phoneNumber) {
        this._phoneNumber = _phoneNumber;
    }

    @DynamoDBAttribute(attributeName = "address")
    public Address getAddress() {
        return _address;
    }
    public void setAddress(Address _address) {
        this._address = _address;
    }

    @DynamoDBAttribute(attributeName = "userSettings")
    public UserSettings getUserSettings() {
        return _userSettings;
    }
    public void setUserSettings(UserSettings _userSettings) {
        this._userSettings = _userSettings;
    }
}
