package com.example.arago.tapiolla.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.arago.tapiolla.R;

import java.util.ArrayList;


public class CardNameRecyclerAdapter extends RecyclerView.Adapter<CardNameRecyclerAdapter.ViewHolder>{
    private ArrayList<String> nameList = new ArrayList<>();
    ItemClickListener itemClickListener;
    private int selectedPosition = 0;
    Context context;
    public CardNameRecyclerAdapter(Context context, ArrayList<String> nameList){
        this.nameList = nameList;
        this.context = context;
    }

    public void setData(ArrayList<String> nameList) {
        this.nameList = nameList;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_name_item,parent,false);
        final ViewHolder holder = new ViewHolder(view);
        return holder;

    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        if(nameList != null) {
            holder.name.setText(nameList.get(position));
            holder.item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    selectedPosition = position;
                    notifyDataSetChanged();
                    itemClickListener.onItemClick(view, position);
                }
            });
            if(selectedPosition == position){
                holder.item.setBackground(ContextCompat.getDrawable(context, R.drawable.round_conner_selected));
                holder.name.setTextColor(Color.parseColor("#ffffff"));
            } else {
                holder.item.setBackground(ContextCompat.getDrawable(context, R.drawable.round_conner_color_stroke));
                holder.name.setTextColor(Color.parseColor("#000000"));
            }
        }

    }

    @Override
    public int getItemCount() {
        if(nameList != null)
            return nameList.size();
        else
            return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView name;
        ConstraintLayout item;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.textName);
            item = itemView.findViewById(R.id.item_constraint_layout);
        }

    }

    public void setClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }


}