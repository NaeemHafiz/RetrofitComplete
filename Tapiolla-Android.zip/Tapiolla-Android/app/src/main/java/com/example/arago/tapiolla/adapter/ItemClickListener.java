package com.example.arago.tapiolla.adapter;

import android.view.View;

/**
 * This interface is for item click in the adapter
 */
public interface ItemClickListener {
    void onItemClick(View view, int position);
    void onItemLongClick(View view, int position);
}
