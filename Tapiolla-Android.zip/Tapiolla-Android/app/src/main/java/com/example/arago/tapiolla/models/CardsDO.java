package com.example.arago.tapiolla.models;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;
import com.example.arago.tapiolla.models.entities.ImageEntitiesDO;
import com.example.arago.tapiolla.models.stamp.CSImageEntity;
import com.example.arago.tapiolla.models.stamp.CSTextEntity;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

@DynamoDBTable(tableName = "tapiolla-mobilehub-396882117-cards")

public class CardsDO implements Serializable {
    private String _userId;
    private String _cardId;
    private String _backgroundImgId;
    private String _backsplashImgId;
    private String _thumbnailImgId;
    private String _cardDesc;
    private List<CSImageEntity> _imagesEntities;
    private List<CSTextEntity> _textEntities;
    private String cardHeight;
    private String cardWidth;

    @DynamoDBHashKey(attributeName = "userId")
    @DynamoDBAttribute(attributeName = "userId")
    public String getUserId() {
        return _userId;
    }

    public void setUserId(final String _userId) {
        this._userId = _userId;
    }
    @DynamoDBRangeKey(attributeName = "cardId")
    @DynamoDBAttribute(attributeName = "cardId")
    public String getCardId() {
        return _cardId;
    }

    public void setCardId(final String _cardId) {
        this._cardId = _cardId;
    }
    @DynamoDBAttribute(attributeName = "backgroundImgId")
    public String getBackgroundImgId() {
        return _backgroundImgId;
    }

    public void setBackgroundImgId(final String _backgroundImgId) {
        this._backgroundImgId = _backgroundImgId;
    }
    @DynamoDBAttribute(attributeName = "backsplashImgId")
    public String getBacksplashImgId() {
        return _backsplashImgId;
    }

    public void setBacksplashImgId(final String _backsplashImgId) {
        this._backsplashImgId = _backsplashImgId;
    }
    @DynamoDBAttribute(attributeName = "thumbnailImgId")
    public String getThumbnailImgId() {
        return _thumbnailImgId;
    }

    public void setThumbnailImgId(final String _thumbnailImgId) {
        this._thumbnailImgId = _thumbnailImgId;
    }
    @DynamoDBAttribute(attributeName = "cardDesc")
    public String getCardDesc() {
        return _cardDesc;
    }

    public void setCardDesc(final String _cardDesc) {
        this._cardDesc = _cardDesc;
    }
    @DynamoDBAttribute(attributeName = "imagesEntities")
    public List<CSImageEntity> getImagesEntities() {
        return _imagesEntities;
    }

    public void setImagesEntities(final List<CSImageEntity> _imagesEntities) {
        this._imagesEntities = _imagesEntities;
    }
    @DynamoDBAttribute(attributeName = "textEntities")
    public List<CSTextEntity> getTextEntities() {
        return _textEntities;
    }
    public void setTextEntities(List<CSTextEntity> _CStextEntity) {
        this._textEntities = _CStextEntity;
    }

    @DynamoDBAttribute(attributeName = "cardWidth")
    public String getCardWidth() {
        return cardWidth;
    }
    public void setCardWidth(String cardwidth) {
        this.cardWidth = cardwidth;
    }

    @DynamoDBAttribute(attributeName = "cardHeight")
    public String getCardHeight() {
        return cardHeight;
    }
    public void setCardHeight(String cardHeight) {
        this.cardHeight = cardHeight;
    }




}
