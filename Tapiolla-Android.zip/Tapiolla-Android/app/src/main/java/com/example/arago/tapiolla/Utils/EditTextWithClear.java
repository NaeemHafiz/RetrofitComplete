package com.example.arago.tapiolla.Utils;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v7.widget.AppCompatEditText;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.example.arago.tapiolla.R;

public class EditTextWithClear extends AppCompatEditText {

    Drawable mClearButtonImage;

    public EditTextWithClear(Context context) {
        super(context);
        init();
    }

    public EditTextWithClear(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public EditTextWithClear(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public void init() {
        mClearButtonImage = ResourcesCompat.getDrawable(getResources(),R.drawable.ic_close_opa, null);
        setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if(getCompoundDrawablesRelative()[2] != null) {
                    float clearButtonStart;
                    float clearButtonEnd;
                    boolean isClearButtonClicked = false;

                    if(getLayoutDirection() == LAYOUT_DIRECTION_RTL) {
                        clearButtonEnd = mClearButtonImage.getIntrinsicWidth() + getPaddingStart();
                        if(event.getX() < clearButtonEnd){
                            isClearButtonClicked = true;
                        }
                    } else {
                        clearButtonStart = getWidth() - mClearButtonImage.getIntrinsicWidth() - getPaddingEnd();
                        if(event.getX() > clearButtonStart){
                            isClearButtonClicked = true;
                        }
                    }

                    //check if button is clicked
                    if(isClearButtonClicked){
                        // check for action down
                        if(event.getAction() == MotionEvent.ACTION_DOWN) {
                            mClearButtonImage = ResourcesCompat.getDrawable(getResources(),R.drawable.ic_close, null);
                            showClearButton();
                        }

                        // check for action up
                        if(event.getAction() == MotionEvent.ACTION_UP) {
                            mClearButtonImage = ResourcesCompat.getDrawable(getResources(),R.drawable.ic_close_opa, null);
                            getText().clear();
                            hideClearButton();
                            return true;
                        }

                    } else {
                        return false;
                    }
                }

                return false;
            }
        });

        // listen to text change behavior
        addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                showClearButton();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void showClearButton() {
        setCompoundDrawablesRelativeWithIntrinsicBounds(null,null, mClearButtonImage, null);
    }
    private void hideClearButton() {
        setCompoundDrawablesRelativeWithIntrinsicBounds(null,null, null, null);
    }
}
