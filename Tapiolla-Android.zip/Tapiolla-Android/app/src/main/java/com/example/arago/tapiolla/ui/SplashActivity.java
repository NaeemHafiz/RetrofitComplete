package com.example.arago.tapiolla.ui;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import com.amazonaws.mobile.auth.core.IdentityManager;
import com.amazonaws.mobile.auth.core.StartupAuthResult;
import com.amazonaws.mobile.auth.core.StartupAuthResultHandler;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.AWSStartupHandler;
import com.amazonaws.mobile.client.AWSStartupResult;
import com.example.arago.tapiolla.R;

public class SplashActivity extends AppCompatActivity {
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

//        AWSMobileClient.getInstance().initialize(this, new AWSStartupHandler() {
//            @Override
//            public void onComplete(AWSStartupResult awsStartupResult) {
//                AuthUIConfiguration config =
//
//                        new AuthUIConfiguration.Builder()
//                                .userPools(true)  // true? show the Email and Password UI
//                                .signInButton(FacebookButton.class) // Show Facebook button
//                                .signInButton(GoogleButton.class) // Show Google button
//                                .logoResId(R.drawable.tapiollabutton) // Change the logo
//                               // .backgroundColor(Color.BLACK) // Change the backgroundColor
//                                .isBackgroundColorFullScreen(true) // Full screen backgroundColor the backgroundColor full screenff
//                                //.fontFamily("sans-serif-light") // Apply sans-serif-light as the global font
//                                .canCancel(true)
//                                .build();
//                SignInUI signinUI = (SignInUI) AWSMobileClient.getInstance().getClient(SplashActivity.this, SignInUI.class);
//                signinUI.login(SplashActivity.this, MenuScreen.class).authUIConfiguration(config).execute();
//            }
//        }).execute();

    }
    @Override
    public void onStart() {
        super.onStart();
        AWSMobileClient.getInstance().initialize(SplashActivity.this, new AWSStartupHandler() {
            @Override
            public void onComplete(AWSStartupResult awsStartupResult) {
                IdentityManager identityManager = IdentityManager.getDefaultIdentityManager();
                identityManager.resumeSession(SplashActivity.this, new StartupAuthResultHandler() {
                    @Override
                    public void onComplete(StartupAuthResult authResults) {
                        progressDialog.dismiss();
                        if (!authResults.isUserSignedIn()) {

                            startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                        } else {
                            startActivity(new Intent(SplashActivity.this, MenuScreen.class));
                        }
                        finish();
                    }
                });
            }
        }).execute();

    }

}
