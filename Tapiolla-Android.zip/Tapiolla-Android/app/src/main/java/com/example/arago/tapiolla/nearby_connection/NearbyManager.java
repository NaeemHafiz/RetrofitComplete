package com.example.arago.tapiolla.nearby_connection;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.Menu;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.database.DynamoSettings;
import com.example.arago.tapiolla.database.ShareCardDynamoDB;
import com.example.arago.tapiolla.models.Card;
import com.example.arago.tapiolla.models.CardsDO;
import com.example.arago.tapiolla.models.SharedCardsDO;
import com.example.arago.tapiolla.ui.MenuScreen;
import com.google.android.gms.nearby.Nearby;
import com.google.android.gms.nearby.connection.AdvertisingOptions;
import com.google.android.gms.nearby.connection.ConnectionInfo;
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback;
import com.google.android.gms.nearby.connection.ConnectionResolution;
import com.google.android.gms.nearby.connection.ConnectionsClient;
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes;
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo;
import com.google.android.gms.nearby.connection.DiscoveryOptions;
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback;
import com.google.android.gms.nearby.connection.Payload;
import com.google.android.gms.nearby.connection.PayloadCallback;
import com.google.android.gms.nearby.connection.PayloadTransferUpdate;
import com.google.android.gms.nearby.connection.Strategy;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import java.util.UUID;

public class NearbyManager {

    private final String TAG = "NearbyManager";
    private final Strategy STRATEGY = Strategy.P2P_POINT_TO_POINT;
    private String username;
    private final String SERVICE_ID;
    private String contentToSend;
    private String cardDetails;
    private DynamoSettings dynamoSettings;
    private MenuScreen menuScreen;

    Context context;



    public NearbyManager(Context context, MenuScreen menuScreen) {
        this.context = context;
        SERVICE_ID = context.getPackageName();
        this.menuScreen = menuScreen;
        username = null;
    }

    public NearbyManager(String username, String contentToSend, Context context) {
        SERVICE_ID = context.getPackageName();
        this.context = context;
        this.username = username;
        this.contentToSend = contentToSend;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String user) {
        username = user;
    }

    /**
     * @param ConnectionLifecycleCallback parameter is the callback
     *                                    that will be invoked when discoverers request
     *                                    to connect to the advertiser
     * @param EndpointDiscoveryCallback parameter is the callback
     *                                      that will be invoked when nearby
     *                                      advertisers are discovered or lost
     */
    private final EndpointDiscoveryCallback endpointDiscoveryCallback =
            new EndpointDiscoveryCallback() {
                @Override
                public void onEndpointFound(final String endpointId, DiscoveredEndpointInfo info) {
                    // An endpoint was found. We request a connection to it.
                    Nearby.getConnectionsClient(context)
                            .requestConnection(username, endpointId, connectionLifeCycleCB)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    // We successfully requested a connection. Now both sides
                                    // must accept before the connection is established.
                                    Log.d(TAG, "EndPointCalled");
                                    Toast.makeText(context, "Endpoint", Toast.LENGTH_LONG).show();

                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    // Nearby Connections failed to request the connection.
                                    Log.d(TAG, "onFailure: " + e.getMessage());
                                    Nearby.getConnectionsClient(context).rejectConnection(endpointId);
                                    menuScreen.stopCardAnimation(R.anim.send_card_reverse);
                                    stopDiscovery();
                                    startAdvertising();
                                    Toast.makeText(context, "A bluetooth error has occured! Please ask the other user to tap share button", Toast.LENGTH_LONG).show();
                                }
                            });
                }

                @Override
                public void onEndpointLost(String endpointId) {
                    // A previously discovered endpoint has gone away.
                }
            };

    public void setCardDetails(String cardDetails) {
        this.cardDetails = cardDetails;
    }

    public String getCardDetails() {
        return this.cardDetails;
    }

    public void setDynamoSettings(DynamoSettings dynamoSettings) {
        this.dynamoSettings = dynamoSettings;
    }

    public DynamoSettings getDynamoSettings() {
        return dynamoSettings;
    }

    private ConnectionLifecycleCallback connectionLifeCycleCB =
            new ConnectionLifecycleCallback() {
                @Override
                public void onConnectionInitiated(final String endpointId, ConnectionInfo info) {
                    Log.d(TAG, "onConnectionInitiated: " + info.toString());
                    new AlertDialog.Builder(menuScreen,  R.style.Theme_AppCompat_Light_Dialog)
                            .setTitle("Accept connection to " + info.getEndpointName())
                            .setMessage("Confirm the code matches on both devices: " + info.getAuthenticationToken())
                            .setPositiveButton("Accept", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    // The user confirmed, so we can accept the connection.
                                    Toast.makeText(context, "Connection Established", Toast.LENGTH_SHORT).show();
                                    Log.d(TAG, "onClick: Connection Established");
                                    stopDiscovery();
                                    startAdvertising();
                                    Nearby.getConnectionsClient(context)
                                            .acceptConnection(endpointId, payloadCallback);

                                }
                            })
                            .setNegativeButton(
                                    "CANCEL", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            // The user canceled, so we should reject the connection.
                                            Log.d(TAG, "onClick: Rejected");
                                            Toast.makeText(context, "REJECTED", Toast.LENGTH_LONG).show();
                                            Nearby.getConnectionsClient(context).rejectConnection(endpointId);

                                        }
                                    })
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                   Log.d(TAG, "ConnectionLifeCycleCallBack called");
                }

                @Override
                public void onConnectionResult(String endPoint,
                                               ConnectionResolution result) {
                    Log.i(TAG, "Connection result. Endpont ["+endPoint+"]");
                    Log.d(TAG, "onConnectionResult: result: " + result.toString());
                    Nearby.getConnectionsClient(context).stopDiscovery();
                    switch (result.getStatus().getStatusCode()) {
                        case ConnectionsStatusCodes.STATUS_OK:
                            // We're connected! Can now start sending and receiving data.
                            Log.d(TAG, "onConnectionResult: Status: OK");
                                stopDiscovery();
                                startAdvertising();
                                menuScreen.stopCardAnimation(R.anim.send_card_end);
                                if (cardDetails == null) {
                                    cardDetails = new MenuScreen().getCardDetails();
                                }
                                byte[] bytes = cardDetails.getBytes();
                                Payload bytesPayload = Payload.fromBytes(bytes);
                                Nearby.getConnectionsClient(context).sendPayload(endPoint, bytesPayload);


                            break;
                        case ConnectionsStatusCodes.STATUS_CONNECTION_REJECTED:
                            // The connection was rejected by one or both sides.
                            Log.d(TAG, "onConnectionResult: Status: Rejected");
                            Toast.makeText(context, result.toString(), Toast.LENGTH_LONG).show();
                            startAdvertising();
                            stopDiscovery();
                            break;
                        case ConnectionsStatusCodes.STATUS_ERROR:
                            // The connection broke before it was able to be accepted.
                            Log.d(TAG, "onConnectionResult: Status: Error");
                            Toast.makeText(context, result.toString(), Toast.LENGTH_LONG).show();
                            stopDiscovery();
                            startAdvertising();
                            break;
                        default:
                            // Unknown status code
                            Toast.makeText(context, result.toString(), Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onDisconnected(String s) {
                    Log.i(TAG, "Disconnected from Endpoint ["+s+"]");
                    // We've been disconnected from this endpoint. No more data can be
                    // sent or received.
                    startAdvertising();
                }
            };


    private PayloadCallback payloadCallback = new PayloadCallback() {
        @Override
        public void onPayloadReceived(String s, Payload payload) {
           try {
               Log.i(TAG, "payloadCallback received");
               byte[] b = payload.asBytes();
               String content = new String(b);
               String[] cardProp = content.split("@");
               String senderId = cardProp[0];
               String cardId = cardProp[1];
               String cardUrl = cardProp[2];
               Toast.makeText(context, "Message: " + content, Toast.LENGTH_LONG).show();

               String sharedId = UUID.randomUUID().toString();

               //Sender to Receiver
               SharedCardsDO senderToReceiver = new SharedCardsDO();
               senderToReceiver.setSenderId(senderId);
               senderToReceiver.setCardId(cardId);
               senderToReceiver.setUserId(DynamoSettings.getUserId());
               senderToReceiver.setSharedId(sharedId);

               String sharedId2 = UUID.randomUUID().toString();
               //Receiver to Sender
               String receiverId = senderId;

               SharedCardsDO receiverToSender = new SharedCardsDO();
               receiverToSender.setSenderId(DynamoSettings.getUserId());
               receiverToSender.setCardId(new MenuScreen().getCurrentCardId());
               receiverToSender.setUserId(receiverId);
               receiverToSender.setSharedId(sharedId2);

               new ShareCardDynamoDB().saveSharedCard(senderToReceiver);

               new ShareCardDynamoDB().saveSharedCard2(receiverToSender);
               stopDiscovery();
               startAdvertising();
           } catch (Exception e) {
               Log.d(TAG, "onPayloadReceived: error: " + e.getMessage());
           }


        }
        @Override
        public void onPayloadTransferUpdate(String s,
                                            PayloadTransferUpdate payloadTransferUpdate) {


            switch (payloadTransferUpdate.getStatus()) {
                case PayloadTransferUpdate.Status.FAILURE :
                    Log.d(TAG,"onPayloadTransferupdate: Status: Failure");

                    Nearby.getConnectionsClient(context).disconnectFromEndpoint(s);
                    break;
                case PayloadTransferUpdate.Status.SUCCESS:
                    Log.d(TAG,"onPayloadTransferupdate: Status: Success: ");

                    Nearby.getConnectionsClient(context).disconnectFromEndpoint(s);
                    startAdvertising();
                    break;
                case PayloadTransferUpdate.Status.IN_PROGRESS:
                    Log.d(TAG,"onPayloadTransferupdate: Status: In Progress");
                    break;
                case PayloadTransferUpdate.Status.CANCELED:
                    Log.d(TAG,"onPayloadTransferupdate: Status: Canceled");
                    break;

            }

        }
    };



    public void startAdvertising() {
        AdvertisingOptions advertisingOptions =
                new AdvertisingOptions.Builder().setStrategy(STRATEGY).build();
        Nearby.getConnectionsClient(context)
                .startAdvertising(
                        username, SERVICE_ID, connectionLifeCycleCB, advertisingOptions)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "we're advertising");
                        Toast.makeText(context, "We're visible to other users", Toast.LENGTH_LONG).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d(TAG, "onFailure: advertising error: " + e.getMessage());
                        Nearby.getConnectionsClient(context).stopAdvertising();
                        startAdvertising();
                    }
                });
    }

    public void startDiscovery() {
        DiscoveryOptions discoveryOptions =
                new DiscoveryOptions.Builder().setStrategy(STRATEGY).build();
        Nearby.getConnectionsClient(context)
                .startDiscovery(SERVICE_ID, endpointDiscoveryCallback, discoveryOptions)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        // We're discovering!
                        Log.d(TAG, "we're discovering");
                        Toast.makeText(context, "We're discovering", Toast.LENGTH_LONG).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // We're unable to start discovering.
                        Toast.makeText(context, "Discovery Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        Nearby.getConnectionsClient(context).stopDiscovery();
                    }
                });
    }

    public void stopDiscovery() {
        Nearby.getConnectionsClient(context).stopDiscovery();
    }

    public void stopAdvertising() {
        Nearby.getConnectionsClient(context).stopAdvertising();
    }

    /**
     * this method download image from url
     * @param url
     */
    private void downloadImages(String url) {
        final Bitmap[] temp = new Bitmap[1];
        Glide.with(context)
                .asBitmap()
                .load(url)
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {

                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                    }
                });
    }
    /**
     *  This interface notify data has successfully loaded
     */
    public interface PayloadReceive {
        void onSuccessReceiveData(String data);
    }



}
