package com.example.arago.tapiolla.controller;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.LabeledIntent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.os.StrictMode;
import android.support.v7.app.AlertDialog;
import android.text.Html;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;

import android.view.MenuItem;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.amazonaws.mobile.auth.core.IdentityManager;
import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.authentication.AWSLoginHandler;
import com.example.arago.tapiolla.authentication.AWSLoginModel;

import com.example.arago.tapiolla.database.CategoryDynamoDB;
import com.example.arago.tapiolla.database.ShareCardDynamoDB;
import com.example.arago.tapiolla.models.CardsDO;
import com.example.arago.tapiolla.models.CategoriesDO;
import com.example.arago.tapiolla.models.Category;
import com.example.arago.tapiolla.models.SharedCardsDO;
import com.example.arago.tapiolla.models.stamp.CSImageEntity;
import com.example.arago.tapiolla.models.stamp.CSTextEntity;

import com.example.arago.tapiolla.database.UserSettingsDB;
import com.example.arago.tapiolla.models.UserDO;
import com.example.arago.tapiolla.models.user.Address;
import com.example.arago.tapiolla.ui.SettingsActivity;
import com.example.arago.tapiolla.ui.SplashActivity;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static android.widget.Toast.LENGTH_LONG;
import static com.example.arago.tapiolla.Constant.*;


public class PopUP {
    final static String TAG = "PopUP";
    Context context;

    public PopUP(Context context) {
        this.context = context;
    }

    /**
     * this function open the change password pop up
     */
    public static void openChangePasswordPopup(final Dialog dialog, final Context context, final AWSLoginModel awsLoginModel, final String userEmail) {
        dialog.setContentView(R.layout.forgot_password_popup);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        ImageView closeBtn = dialog.findViewById(R.id.btnClose);
        EditText emailReceiveCode = dialog.findViewById(R.id.txtEmail);
        TextView changePassinfo = dialog.findViewById(R.id.txtChangePassinfo);
        Button btnSendCode = dialog.findViewById(R.id.btnSendCode);
        Button changePassword = dialog.findViewById(R.id.btnChangePassword);
        final EditText password = dialog.findViewById(R.id.txtPassword);
        final EditText confirmCode = dialog.findViewById(R.id.comfirmCode);
        final EditText confirmPassword = dialog.findViewById(R.id.txtConfirmPassword);

        emailReceiveCode.setVisibility(View.GONE);
        changePassinfo.setVisibility(View.GONE);
        btnSendCode.setVisibility(View.GONE);
        confirmCode.setHint("Old Password");
        Drawable img = context.getResources().getDrawable( R.drawable.ic_lock );
        img.setBounds( 0, 0, 60, 60 );
        confirmCode.setCompoundDrawables(img, null, null, null);
        confirmCode.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        changePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pw = password.getText().toString();
                String pw1 = confirmPassword.getText().toString();
                String oldPw = confirmCode.getText().toString();
                if(TextUtils.isEmpty(oldPw)){
                    Toast.makeText(context,"Please fill up old password",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(pw)){
                    Toast.makeText(context,"Please fill up password",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(pw1)){
                    Toast.makeText(context,"Please fill up confirm password",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(!pw.equals(pw1)){
                    Toast.makeText(context,"Password doesn't match. Try Again",Toast.LENGTH_SHORT).show();
                    return;
                }

                awsLoginModel.changeAccountPassword(userEmail, oldPw, pw);
                // progressDialog.setMessage("Please wait...");
                // progressDialog.show();
                //close dialog
                dialog.dismiss();
            }
        });

        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    /**
     *
     * @param dialog
     * @param context
     * @param progressDialog
     */
    public static void openForgotPasswordPopup(final Dialog dialog, final Context context, final ProgressDialog progressDialog) {
        dialog.setContentView(R.layout.forgot_password_popup);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        ImageView closeBtn = dialog.findViewById(R.id.btnClose);
        final EditText emailReceiveCode = dialog.findViewById(R.id.txtEmail);
        final TextView changePassinfo = dialog.findViewById(R.id.txtChangePassinfo);
        final Button btnSendCode = dialog.findViewById(R.id.btnSendCode);
        Button changePassword = dialog.findViewById(R.id.btnChangePassword);
        final EditText password = dialog.findViewById(R.id.txtPassword);
        final EditText confirmCode = dialog.findViewById(R.id.comfirmCode);
        final EditText confirmPassword = dialog.findViewById(R.id.txtConfirmPassword);

        final AWSLoginModel awsLoginModel = new AWSLoginModel(context, new AWSLoginHandler() {
            @Override
            public void onRegisterSuccess(boolean mustConfirmToComplete, String email) {

            }

            @Override
            public void onSuccess(int process) {
                progressDialog.dismiss();
                switch (process) {

                    case AWSLoginModel.PROCESS_FORGOT_PASSWORD_SENT_CODE:

                        emailReceiveCode.setVisibility(View.GONE);
                        changePassinfo.setVisibility(View.GONE);
                        btnSendCode.setVisibility(View.GONE);
                        break;
                    case AWSLoginModel.PROCESS_CHANGE_PASSWORD:

                        break;
                }
            }

            @Override
            public void onFailure(int process, Exception exception) {

            }
        });
        btnSendCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailString = emailReceiveCode.getText().toString().trim();

                if (TextUtils.isEmpty(emailString)) {
                    Toast.makeText(context, "Please fill up email", Toast.LENGTH_SHORT).show();
                    return;
                }
                // call the forgot password function in the model
                awsLoginModel.forgotPassword(emailString);
                progressDialog.setMessage("Seding Code ...");
                progressDialog.show();
            }
        });
        changePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pw = password.getText().toString();
                String pw1 = confirmPassword.getText().toString();
                String cfCode = confirmCode.getText().toString();
                if(TextUtils.isEmpty(cfCode)){
                    Toast.makeText(context,"Please fill up Verificationcode",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(pw)){
                    Toast.makeText(context,"Please fill up password",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(pw1)){
                    Toast.makeText(context,"Please fill up confirm password",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(!pw.equals(pw1)){
                    Toast.makeText(context,"Password doesn't match. Try Again",Toast.LENGTH_SHORT).show();
                    return;
                }
                awsLoginModel.changePassword(pw,cfCode);
                progressDialog.setMessage("Please wait...");
                progressDialog.show();
                //close dialog
                dialog.dismiss();
            }
        });

        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    /**
     *
     * @param dialog
     * @param context
     * @param progressDialog
     * @param awsLoginModel
     */
    public static void openRegisterPopup(final Dialog dialog, final Context context, final ProgressDialog progressDialog, final AWSLoginModel awsLoginModel) {

        dialog.setContentView(R.layout.register_popup);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        ImageView closeBtn = dialog.findViewById(R.id.btnClose);
        final EditText email = dialog.findViewById(R.id.txtEmail);
        final EditText fullName = dialog.findViewById(R.id.txtFullName);
        final EditText phone = dialog.findViewById(R.id.txtphone);
        final EditText txtpassword = dialog.findViewById(R.id.txtPassword);
        final EditText confirmPassword = dialog.findViewById(R.id.txtConfirmPassword);
        final Button btnSignUp = dialog.findViewById(R.id.btnSignup);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userName = fullName.getText().toString().trim();
                String emailString = email.getText().toString().trim();
                String phoneString = phone.getText().toString().trim();
                String pw = txtpassword.getText().toString().trim();
                String pw1 = confirmPassword.getText().toString().trim();
                if(TextUtils.isEmpty(emailString)){
                    Toast.makeText(context,"Please fill up email",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(userName)){
                    Toast.makeText(context,"Please fill up name",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(phoneString)){
                    Toast.makeText(context,"Please fill up phone",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(pw)){
                    Toast.makeText(context,"Please fill up password",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(pw1)){
                    Toast.makeText(context,"Please fill up confirm password",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(!pw.equals(pw1)){
                    Toast.makeText(context,"Password doesn't match. Try Again",Toast.LENGTH_SHORT).show();
                    return;
                }
                progressDialog.setMessage("Please wait...");
                progressDialog.show();
                //save to database
                Authenticate.registerAction(awsLoginModel, emailString, userName, phoneString,  pw);
            }
        });

        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }


    @SuppressLint("ClickableViewAccessibility")
    public void openRolodexPopup(Dialog dialog, Bitmap bitmap, final CardsDO cardsDO) {
        Log.d(TAG, "openRolodexPopup: called");
        dialog.setContentView(R.layout.rolodex_popup);
        dialog.getWindow().setBackgroundDrawableResource(R.color.transparent);

        final int width = (int) (Integer.parseInt(cardsDO.getCardWidth()));
        final int height = (int) (Integer.parseInt(cardsDO.getCardHeight()));
        Log.d(TAG, "openRolodexPopup: onTouch: cardWidth: " + width + " cardHeight: " + height);

        //765, 425
        dialog.getWindow().setLayout(width, height);


        final ImageView rolodexCard = dialog.findViewById(R.id.rolodex_card);

        rolodexCard.setImageBitmap(bitmap);

        rolodexCard.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    ClickableHelper clickableHelper = new ClickableHelper(context);
                    Log.d(TAG, "onTouch: X: " + motionEvent.getX() + " Y: " + motionEvent.getY());

                    int centerY = rolodexCard.getHeight() / 2;
                    int centerX = rolodexCard.getWidth() / 2;
                    List<CSImageEntity> csImageEntities = cardsDO.getImagesEntities();
                    List<CSTextEntity> csTextEntities = cardsDO.getTextEntities();

                    for (int i = 0; i < csImageEntities.size(); i++) {
                        CSImageEntity currentCSImageEntity = csImageEntities.get(i);
                        float currentX = Float.parseFloat(currentCSImageEntity.getAbsoluteCenterX());
                        float currentY = Float.parseFloat(currentCSImageEntity.getAbsoluteCenterY());

                        float xTouchPos = motionEvent.getX() - 75;
                        float yTouchPos = motionEvent.getY() - 75;

                        int range = 75;

                        Log.d(TAG, "onTouch: CurrentX: " + currentX + " currentY: " + currentY);

                        if(currentX >= xTouchPos - range && currentX <= xTouchPos + range
                                && currentY >= yTouchPos - range && currentY <= yTouchPos +  range) {
                            Log.d(TAG, "onTouch: In Range:" + currentCSImageEntity.getClickableType());
                            if (!currentCSImageEntity.getHyperlink().isEmpty()) {
                                switch (currentCSImageEntity.getClickableType()) {
                                    case WHATSAPP: //open dial
                                        clickableHelper.makeCall(currentCSImageEntity.getHyperlink());
                                        break;
                                    case EMAIL: //mailto
                                    case GOOGLE:
                                        clickableHelper.openEmail(currentCSImageEntity.getHyperlink());
                                        break;
                                    case VIDEO_TYPE:
                                        clickableHelper.playVideo(currentCSImageEntity.getHyperlink());
                                        break;
                                    default://open url
                                        clickableHelper.openUrl(currentCSImageEntity.getHyperlink());
                                }
                            }
                        }
                    }

                    for (int i = 0; i < csTextEntities.size(); i++) {
                        CSTextEntity currentCSTextEntity = csTextEntities.get(i);
                        float currentX = Float.parseFloat(currentCSTextEntity.getAbsoluteCenterX());
                        float currentY = Float.parseFloat(currentCSTextEntity.getAbsoluteCenterY());

                        float xTouchPos = motionEvent.getX();
                        float yTouchPos = motionEvent.getY();
                        int range = 75;

                        if(currentX >= xTouchPos - 100 && currentX <= xTouchPos + 100
                                && currentY >= yTouchPos - 50 && currentY <= yTouchPos +  50) {

                            if (currentCSTextEntity.getClickableType() != null) {
                                switch (currentCSTextEntity.getClickableType()) {
                                    case PHONE: //open dial
                                        clickableHelper.makeCall(currentCSTextEntity.getText());
                                        break;
                                    case EMAIL: //mailto
                                        clickableHelper.openEmail(currentCSTextEntity.getText());
                                        break;
                                    case ADDRESS:
                                        clickableHelper.openGps(currentCSTextEntity.getText());
                                        break;
                                }
                            }

                        }
                    }


                }

                return false;
            }
        });
        dialog.setCanceledOnTouchOutside(true);
        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {

            }
        });
        dialog.show();
    }


    /**
     *
     * @param context
     * @param view
     */
    public static void openMenuPopup (final Context context, View view) {
        final PopupMenu popMenu = new PopupMenu(context, view);
        popMenu.getMenuInflater().inflate(R.menu.mainmenu, popMenu.getMenu());

        popMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                int id = menuItem.getItemId();
                switch (id) {
                    case R.id.menu_setting:
                        context.startActivity(new Intent(context, SettingsActivity.class));
                        break;
//                    case R.id.menu_card_maker:
//                        context.startActivity(new Intent(context, CardMaker.class));
//                        break;
//                    case R.id.menu_main:
//
//                        break;
//                    case R.id.rolodex:
//                        context.startActivity(new Intent(context, Rolodex.class));
//                        break;
                    case R.id.menu_logout:
                        IdentityManager.getDefaultIdentityManager().signOut();
                        context.startActivity(new Intent(context, SplashActivity.class));
                        ((Activity) context).finish();
                        break;

                }
                return false;
            }
        });
        popMenu.show();
    }

    /**
     * This function open edit profile pop up
     * @param dialog
     * @param context
     * @param userSettingsDB usersetting Dyanmo
     * @param useInfo user infomation
     */
    public static void openEditProfilePopup(final Dialog dialog, final Context context, final UserSettingsDB userSettingsDB, final UserDO useInfo) {

        dialog.setContentView(R.layout.edit_profile_popup);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        ImageView closeBtn = dialog.findViewById(R.id.btnClose);
        final EditText email = dialog.findViewById(R.id.txtEmail);
        final EditText fullName = dialog.findViewById(R.id.txtFullName);
        final EditText phone = dialog.findViewById(R.id.txtphone);
        final EditText add1 = dialog.findViewById(R.id.txtAddress1);
        final EditText add2 = dialog.findViewById(R.id.txtAddress2);
        final EditText city = dialog.findViewById(R.id.txtCity);
        final EditText state = dialog.findViewById(R.id.txtState);
        final EditText zipcode = dialog.findViewById(R.id.txtZipcode);
        final Button btnSave = dialog.findViewById(R.id.btnSave);
        //Set Text for all fields
        if(useInfo.getUserEmail() != null &&
                useInfo.getPhoneNumber() != null &&
                useInfo.getFullName() != null  ) {
            email.setText(useInfo.getUserEmail());
            phone.setText(useInfo.getPhoneNumber());
            fullName.setText(useInfo.getFullName());
        }
        if(useInfo.getAddress() != null) {
            add1.setText(useInfo.getAddress().getAddress1());
            if (useInfo.getAddress().getAddress2() != null)
                add2.setText(useInfo.getAddress().getAddress2());
            city.setText(useInfo.getAddress().getCity());
            state.setText(useInfo.getAddress().getState());
            zipcode.setText(useInfo.getAddress().getZipcode());
        }
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userName = fullName.getText().toString().trim();
                String emailString = email.getText().toString().trim();
                String phoneString = phone.getText().toString().trim();
                String add1String = add1.getText().toString().trim();
                String add2String = add2.getText().toString().trim();
                String cityString = city.getText().toString().trim();
                String stateString = state.getText().toString().trim();
                String zipcodeString = zipcode.getText().toString().trim();
                if(TextUtils.isEmpty(emailString)){
                    Toast.makeText(context,"Please fill up email",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(userName)){
                    Toast.makeText(context,"Please fill up name",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(phoneString)){
                    Toast.makeText(context,"Please fill up phone",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(add1String)){
                    Toast.makeText(context,"Please fill up Address 1",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(cityString)){
                    Toast.makeText(context,"Please fill up City",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(stateString)){
                    Toast.makeText(context,"Please fill up State",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(zipcodeString)){
                    Toast.makeText(context,"Please fill up Zipcode",Toast.LENGTH_SHORT).show();
                    return;
                }

                Address address = new Address();
                address.setAddress1(add1String);
                if(!TextUtils.isEmpty(add2String)){
                    address.setAddress2(add2String);
                }
                address.setCity(cityString);
                address.setState(stateString);
                address.setZipcode(zipcodeString);
                address.setCountry("Canada");

                useInfo.setFullName(userName);
                useInfo.setUserEmail(emailString);
                useInfo.setPhoneNumber(phoneString);
                useInfo.setAddress(address);
                //save to database
                userSettingsDB.saveUserInfo(useInfo);
                dialog.dismiss();
            }
        });

        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    /**
     *
     * @param dialog
     * @param context
     */
    public static void openPaymentPopup(final Dialog dialog, final Context context) {

        dialog.setContentView(R.layout.payment_popup);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        ImageView closeBtn = dialog.findViewById(R.id.btnClose);
        final EditText txtNameOnCard = dialog.findViewById(R.id.txtNameOnCard);
        final EditText txtCardNumber = dialog.findViewById(R.id.txtCardNumber);
        final EditText txtExp = dialog.findViewById(R.id.txtAddress1);
        final EditText txtCVV = dialog.findViewById(R.id.txtAddress2);

        final Button btnSave = dialog.findViewById(R.id.btnSave);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String stringNameOnCard = txtNameOnCard.getText().toString().trim();
                String stringCardNumber = txtCardNumber.getText().toString().trim();
                String stringExp = txtExp.getText().toString().trim();
                String stringCVV = txtCVV.getText().toString().trim();

                if(TextUtils.isEmpty(stringNameOnCard)){
                    Toast.makeText(context,"Please fill up Name on card!",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(stringCardNumber)){
                    Toast.makeText(context,"Please fill up card number!",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(stringExp)){
                    Toast.makeText(context,"Please fill up expire date",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(stringCVV)){
                    Toast.makeText(context,"Please fill up security number",Toast.LENGTH_SHORT).show();
                    return;
                }


                //TODO: save payment to database

                dialog.dismiss();
            }
        });

        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    /**
     *
     * @param context
     * @param view
     * @param bm
     * @param cardsDO
     */
    public static void openShareCardOffline (final Context context, View view, Bitmap bm, CardsDO cardsDO) {

        // https://stackoverflow.com/questions/48117511/exposed-beyond-app-through-clipdata-item-geturi
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());

        String targetFiles[] = { "card_" + cardsDO.getCardId() + ".pdf",
                            "image_" + cardsDO.getCardId() + ".png" };

        String root = Environment.getExternalStorageDirectory() + File.separator + "Tapiolla" + File.separator;
        PDFHelper pdfHelper = new PDFHelper(context);
        pdfHelper.generatePdf(bm, cardsDO);
        pdfHelper.generateImage(bm, cardsDO);
        Intent share = new Intent();
        share.setAction(Intent.ACTION_SEND);
        share.setType("application/pdf");

        ArrayList<Uri> uris = new ArrayList<>();

        for (String targetFile: targetFiles) {
            String path = root + targetFile;
            Uri uri = Uri.parse("file://" + path);
            uris.add(uri);
        }
        Intent testIntent = new Intent(Intent.ACTION_SEND);
        testIntent.setType("text/plain");

        PackageManager packageManager = context.getPackageManager();

        List<ResolveInfo> resolveInfos = packageManager.queryIntentActivities(testIntent, 0);
        List<ResolveInfo> resolveInfoPDFs = packageManager.queryIntentActivities(share, 0);
        //Apps that handles pdf
        List<String> appThatHandlesPDF = new ArrayList<>();

        for (ResolveInfo resolveInfoPdf: resolveInfoPDFs) {
            appThatHandlesPDF.add(resolveInfoPdf.activityInfo.packageName);
        }

        Intent openInChooser = Intent.createChooser(share, "Share card Via?");
        List<LabeledIntent> intentList = new ArrayList<LabeledIntent>();


        if (!resolveInfos.isEmpty()) {
            for (ResolveInfo  resolveInfo: resolveInfos) {

                String packageName = resolveInfo.activityInfo.packageName;
                if (appThatHandlesPDF.contains(packageName)) {
                    //attach pdf only
                    Uri pdfUri = uris.get(0);
                    share.putExtra(Intent.EXTRA_STREAM, pdfUri);
                    share.putExtra(Intent.EXTRA_SUBJECT, "Business Card");
                    share.putExtra(Intent.EXTRA_TEXT, Html.fromHtml(context.getResources().getString(R.string.title_with_pdf)));
                } else {
                    //attach the image and a text
                    Intent newIntent = new Intent();
                    newIntent.setComponent(new ComponentName(packageName, resolveInfo.activityInfo.name));
                    newIntent.setAction(Intent.ACTION_SEND);
                    newIntent.setType("image/png");
                    Uri imageUri = uris.get(1);
                    newIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                    newIntent.putExtra(Intent.EXTRA_TEXT, context.getResources().getString(R.string.title_with_text));
                    intentList.add(new LabeledIntent(newIntent, packageName, resolveInfo.loadLabel(packageManager), resolveInfo.icon));
                }
            }

        }
        LabeledIntent[] extraIntents = intentList.toArray( new LabeledIntent[ intentList.size() ]);
        Set<LabeledIntent> uniqueSet = new HashSet<>();

        openInChooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, extraIntents);

        context.startActivity(openInChooser);
        //share.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        //context.startActivity(Intent.createChooser(share, "Share Card Via?"));

    }


    /**
     * @param context
     */
    public static void deleteSharedCardAlertDialog(final Context context, final ShareCardDynamoDB dynamoDB, final SharedCardsDO sharedCardsDO) {
        final AlertDialog alertDialog = new AlertDialog.Builder(context).setTitle("Delete Card")
                .setMessage("Are You Sure You Want To Delete The Center Card?")
                .setPositiveButton("DELETE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        dynamoDB.delete(sharedCardsDO);
                        Toast.makeText(context,"Successfully Delete!",LENGTH_LONG).show();

                        Intent intent = new Intent();
                        intent.setAction(CONFIRM_DELETE_CARD);
                        // broadcast
                        context.sendBroadcast(intent);
                    }
                })
                .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                }).create();

        alertDialog.show();
        alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.RED);
        alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.LTGRAY);


    }

    /**
     * @param context
     */
    public static void removeSharedCardFromCategory(final Context context, final Category category, final int position, final int categoryPosition) {
        final AlertDialog alertDialog = new AlertDialog.Builder(context).setTitle("Remove Card")
                .setMessage("Are You Sure You Want To Remove The Center Card From " + category.getCategoryName() + "?")
                .setPositiveButton("DELETE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        category.getCardList().remove(position);

                        Toast.makeText(context,"Successfully Removed!",LENGTH_LONG).show();

                        Intent intent = new Intent();
                        intent.setAction(CONFIRM_REMOVE_CARD);
                        intent.putExtra(CATEGORY_POSITION, categoryPosition);
                        // broadcast
                        context.sendBroadcast(intent);
                    }
                })
                .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                }).create();

        alertDialog.show();
        alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.RED);
        alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.LTGRAY);


    }
    /**
     *
     * @param context
     * @param db
     * @param categoriesDO
     */
    public static void saveCategoryAlertDialog(final Context context, final CategoryDynamoDB db, final CategoriesDO categoriesDO) {
        final AlertDialog alertDialog = new AlertDialog.Builder(context).setTitle("Save")
                .setMessage("Are you sure you want to save the Categories?")
                .setPositiveButton("SAVE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(context,"Successfully Saved!",LENGTH_LONG).show();
                        db.saveCategory(categoriesDO);


                    }
                })
                .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                }).create();

        alertDialog.show();

        alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.GREEN);
        alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.LTGRAY);
    }


}
