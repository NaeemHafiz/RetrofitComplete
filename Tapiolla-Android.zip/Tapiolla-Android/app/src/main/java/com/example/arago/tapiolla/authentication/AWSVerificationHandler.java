package com.example.arago.tapiolla.authentication;

public interface AWSVerificationHandler {
    void onRegisterConfirmed();

    void onFailure(int process, Exception exception);

    void onSendCodeSuccess();
}
