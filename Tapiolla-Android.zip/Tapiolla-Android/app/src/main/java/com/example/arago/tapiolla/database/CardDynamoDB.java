package com.example.arago.tapiolla.database;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBQueryExpression;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ComparisonOperator;
import com.amazonaws.services.dynamodbv2.model.Condition;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.arago.tapiolla.controller.DownloadImage;
import com.example.arago.tapiolla.models.Card;
import com.example.arago.tapiolla.models.CardsDO;
import com.example.arago.tapiolla.models.entities.ImageEntitiesDO;
import com.example.arago.tapiolla.models.entities.TextEntitiesDO;
import com.example.arago.tapiolla.motion_views.widget.entity.ImageEntity;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class CardDynamoDB {
    private Context context;
    private String userId;
    private DynamoDBMapper dynamoDBMapper;
    private List<CardsDO> returnList;
    private List<Card> cardsList;
    private List<ImageEntitiesDO> imageEntityReturnList;
    private List<TextEntitiesDO> textEntityReturnList;
    private OnSuccessCardsThumbnail mThumbnailSuccess;
    private OnSuccessSearchCards mSearchCardsCallback;
    private boolean successLoadText = false;
    private boolean successLoadImage = false;

    /**
     *
     */
    public CardDynamoDB() {

        cardsList = new ArrayList<>();
        userId = DynamoSettings.getUserId();
        this.dynamoDBMapper = DynamoSettings.getDynamoDBMapper();

    }
    public CardDynamoDB( OnSuccessSearchCards mSearchCardsCallback) {

        cardsList = new ArrayList<>();
        userId = DynamoSettings.getUserId();
        this.dynamoDBMapper = DynamoSettings.getDynamoDBMapper();
        this.mSearchCardsCallback = mSearchCardsCallback;

    }
    /**
     *
     * @param context
     * @param cardsThumbnail
     */
    public CardDynamoDB(Context context, OnSuccessCardsThumbnail cardsThumbnail) {
        this.context = context;
        userId = DynamoSettings.getUserId();
        this.dynamoDBMapper = DynamoSettings.getDynamoDBMapper();
        mThumbnailSuccess = cardsThumbnail;
        cardsList = new ArrayList<>();
        successLoadText = false;
        successLoadImage = false;

    }

    public List<CardsDO> getReturnList() {
        return returnList;
    }

    public void setReturnList(List<CardsDO> returnList) {
        this.returnList = returnList;
    }

    /**
     *
     * @param newCard
     */
    public void addNewCard(final CardsDO newCard) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                dynamoDBMapper.save(newCard);
                // Item saved
            }
        }).start();
    }

    /**
     *
     * @param newCard
     */
    public void deleteCard(final CardsDO newCard) {
        new Thread(new Runnable() {
            @Override
            public void run() {

                dynamoDBMapper.delete(newCard);
                // Item deleted
            }
        }).start();
    }

    /**
     *
     */
    public void getAllCards() {

        CardsDO template = new CardsDO();
        template.setUserId(DynamoSettings.getUserId());
        new CardDynamoDB.LoadCardsTask().execute(template);

    }

    /**
     *
     * @param searchPatern
     * @return
     */
    public void searchSpecificCards(Context context,String searchPatern) {

        new SearchCardsTask(context).execute(searchPatern);
    }
    /**
     * This task load all the card of a user
     */
    private class LoadCardsTask extends AsyncTask<CardsDO, Void, List<CardsDO>> {

        LoadCardsTask(){
        }

        @Override
        protected List<CardsDO> doInBackground(CardsDO... cardsDOS) {

            DynamoDBQueryExpression<CardsDO> queryExpression = new DynamoDBQueryExpression<CardsDO>();

            queryExpression.setHashKeyValues(cardsDOS[0]);

            List<CardsDO> awsqlist = dynamoDBMapper.query(CardsDO.class, queryExpression);

            return awsqlist;
        }

        protected void onPostExecute(List<CardsDO> result) {
            if(result.size() > 0) {
                int size = result.size();
                for (int i = 0; i< size; i++) {
                    downloadImages(i,size,result.get(i));
                }
            }
        }
    }

    /**
     *
     */
    private class SearchCardsTask extends AsyncTask<String, Void, List<CardsDO>> {
        Context con;
        SearchCardsTask(Context context){
            this.con = context;
        }

        @Override
        protected List<CardsDO> doInBackground(String... searchString) {
            Log.i(searchString[0], searchString[0]);
            Map<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
            eav.put(":val1", new AttributeValue().withS(searchString[0]));

            DynamoDBScanExpression scanExpression = new DynamoDBScanExpression()
                    .withFilterExpression("contains(cardDesc, :val1)")
                    .withExpressionAttributeValues(eav);

            List<CardsDO> scanResult = dynamoDBMapper.scan(CardsDO.class, scanExpression);

            return  scanResult;
        }

        protected void onPostExecute(List<CardsDO> result) {
            //mSearchCardsCallback.onSuccessSearchCards(result);
            Log.i("sizeResult", String.valueOf(result.size()));
            if(result != null)
            for(CardsDO cardsDO : result) {
                if(cardsDO.getThumbnailImgId() != null)
                    DownloadImage.downloadImages(this.con, cardsDO, mSearchCardsCallback);

               // Log.i("sizeResult", cardsDO.getUserId());
            }

            if(result.size() == 0)mSearchCardsCallback.onSuccessSearchCards(null);
        }
    }
    /**
     *
     * @param i
     * @param size
     * @param card
     */
    private void downloadImages(final int i, final int size, final CardsDO card) {
        final Bitmap[] temp = new Bitmap[1];
        Glide.with(context)
                .asBitmap()
                .load(card.getThumbnailImgId())
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        Card c = new Card(card, resource);
                        cardsList.add(c);
                        if(i == size - 1) {
                            mThumbnailSuccess.onSuccessLoadCardsThumbnail(cardsList);
                        }
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                    }
                });
    }

    /**
     *
     */
    public interface OnSuccessCardsThumbnail {
        /**
         *
         * @param cardList
         */
        void onSuccessLoadCardsThumbnail(List<Card> cardList);

    }
    public interface OnSuccessSearchCards {
        void onSuccessSearchCards(Card card);
    }
}
