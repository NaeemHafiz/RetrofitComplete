package com.example.arago.tapiolla.controller;

import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

import com.example.arago.tapiolla.ui.Rolodex;

import java.util.ArrayList;

public class ClickableHelper {
        public static final String TAG = "ClickableHelper";
        private Context context;

        public ClickableHelper(Context context) {
            this.context = context;
        }

        public void openUrl(String url) {
            if (!url.startsWith("https://") && !url.startsWith("http://")) {
                url = "http://" + url;
            }
            Intent hyperlinkIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            hyperlinkIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(hyperlinkIntent);
        }

        public void openEmail(String email) {
            Intent emailIntent = new Intent(Intent.ACTION_SEND, Uri.fromParts("mailto", email, null));
            String[] emails = {email};

            emailIntent.setType("text/plain");
            //emailIntent.setType("application/octet-stream");
            //emailIntent.setType("message/rfc822");
            //emailIntent.putExtra(Intent.EXTRA_EMAIL, email);
            //emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Enter Subject");
            //emailIntent.putExtra(Intent.EXTRA_TEXT, "Enter Body Here");
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:")); // only email apps should handle this
            intent.putExtra(Intent.EXTRA_EMAIL, emails);
            


            context.startActivity(intent);
        }

        public void makeCall(String phoneNumber) {
            String phoneNum = phoneNumber.replaceAll("[^0-9]", "");

            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + phoneNum));
            

            context.startActivity(intent);

        }

        public void openGps(String address) {
            String url = "https://www.google.com/maps/search/?api=1&query=" + address;
            Intent openMaps = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            openMaps.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(openMaps);
        }

        public void playVideo(String newVideoPath) {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(newVideoPath));
            intent.setDataAndType(Uri.parse(newVideoPath), "video/*");
            
            context.startActivity(intent);
        }
}
