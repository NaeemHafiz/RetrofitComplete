package com.example.arago.tapiolla.ui;

import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.DragEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.example.arago.tapiolla.adapter.CardRecyclerAdapter;
import com.example.arago.tapiolla.R;
import com.example.arago.tapiolla.adapter.CategoriesRecyclerAdapter;
import com.example.arago.tapiolla.adapter.ItemClickListener;
import com.example.arago.tapiolla.adapter.ItemDragListener;
import com.example.arago.tapiolla.controller.PopUP;
import com.example.arago.tapiolla.database.CardDynamoDB;
import com.example.arago.tapiolla.database.CategoryDynamoDB;
import com.example.arago.tapiolla.database.DynamoSettings;
import com.example.arago.tapiolla.database.ShareCardDynamoDB;
import com.example.arago.tapiolla.fragments.RolodexNotificationFragment;
import com.example.arago.tapiolla.fragments.RolodexRecyclerCardFragment;
import com.example.arago.tapiolla.models.Card;
import com.example.arago.tapiolla.models.CardsDO;
import com.example.arago.tapiolla.models.CategoriesDO;
import com.example.arago.tapiolla.models.Category;
import com.example.arago.tapiolla.models.SharedCardsDO;
import com.example.arago.tapiolla.models.stamp.CSTextEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.example.arago.tapiolla.Constant.*;

public class Rolodex extends AppCompatActivity implements ShareCardDynamoDB.OnSuccessCLoadSharedCard,
        RolodexRecyclerCardFragment.OnFragmentInteractionListener,
        RolodexNotificationFragment.OnFragmentInteractionListener,
        View.OnClickListener
{

    private static final String TAG = Rolodex.class.getSimpleName();

    RecyclerView  mCategoriesRV;
    CardRecyclerAdapter mCardAdapter;
    CategoriesRecyclerAdapter categoryAdapter;

    ArrayList<Bitmap> mCardList = new ArrayList<>();//businesscard list
    ArrayList<Bitmap> mSearchCardList;//businesscard search list
   // ArrayList<Bitmap> mCurrentCategoryList = new ArrayList<>();//category list


    ArrayList<Card> mCardListDetails = new ArrayList<>();
    ArrayList<CardsDO> mCardsDOList = new ArrayList<>();
    ArrayList<SharedCardsDO> mShareCardDOList = new ArrayList<>();
   // ArrayList<Category> categoryList = new ArrayList<>();
    CategoriesDO categoriesDO;

    ShareCardDynamoDB shareCardDynamoDB;
    CategoryDynamoDB categoryDynamoDB;

    CardDynamoDB cardDynamoDB;

    ImageView searchBtn, addCategoryBtn;
    EditText searchText;
    Button communitySearch, delete, save;
    //DynamoSettings dynamoSettings;


    FragmentManager fm;
    boolean isCommunitySearch;
    RolodexRecyclerCardFragment rolodexRecyclerCardFragment;

    Button btnNotification;
    boolean isShowNotification = false;
    private int cardRecyclerCurrentPosition; // click position
    public int cardRecycleCenterPosition = 0; // center position

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rolodex);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);//set to landscape
        //getSupportActionBar().hide();

        // initialize the dynamoDb object
        //dynamoSettings = new DynamoSettings();
        rolodexRecyclerCardFragment = new RolodexRecyclerCardFragment();

        cardDynamoDB = new CardDynamoDB( new CardDynamoDB.OnSuccessSearchCards() {
            @Override
            public void onSuccessSearchCards(Card card) {
                if(card == null) {
                    Toast.makeText(Rolodex.this, "No cards Found", Toast.LENGTH_SHORT).show();
                    return;
                }
                mSearchCardList.add(card.getCardBitmap());
                // mCardAdapter.notifyDataSetChanged();
                FragmentTransaction ft = fm.beginTransaction();
                ft.setCustomAnimations(R.anim.enter_from_top, R.anim.exit_to_top);

                ft.replace(R.id.rolodexFrame, rolodexRecyclerCardFragment.newInstance(mSearchCardList, mCardsDOList));
                ft.commit();
            }
        });

        shareCardDynamoDB = new ShareCardDynamoDB(getApplicationContext(), this);
        categoryDynamoDB = new CategoryDynamoDB(Rolodex.this);

        // cal the init cards function
        initCards();


        searchBtn =  findViewById(R.id.rolodexSearch);
        searchText =  findViewById(R.id.rolodexSearchText);
        communitySearch = findViewById(R.id.communitySearch);
        btnNotification = findViewById(R.id.btnNotification);
        addCategoryBtn = findViewById(R.id.addCategoryBtn);
        mCategoriesRV = findViewById(R.id.categoriesRecyclerView);
        delete = findViewById(R.id.btnDelete);
        save = findViewById(R.id.btnSave);
        delete.setOnClickListener(this);
        save.setOnClickListener(this);

        // Create new categoryDO if it is null
        createNewCategoryDO();

        displayCategory();




        btnNotification.setOnClickListener(this);
        addCategoryBtn.setOnClickListener(this);
        isCommunitySearch = false;

        fm = getSupportFragmentManager();


        // search button clicked
        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search();
            }
        });
        //listen to search text change
        searchText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.length() == 0) {
                    //clear the search
//                    mCardAdapter.setData(mCardList);
//                    mCardAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        // toggle communitySearch button
        communitySearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleCommunitySearchButton();
            }
        });

    }

    /**
     * This function display categories recycler View
     */
    private void displayCategory() {

        LinearLayoutManager layoutManager
                = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        if(categoriesDO != null) {
            categoryAdapter = new CategoriesRecyclerAdapter(this, (ArrayList<Category>) categoriesDO.getCategories());
        } else {
            categoryAdapter = new CategoriesRecyclerAdapter(this, null);
        }

        categoryAdapter.setItemDragListener(dragListener);
        categoryAdapter.setClickListener(categoryItemClick);
        mCategoriesRV.setAdapter(categoryAdapter);
        mCategoriesRV.setLayoutManager(layoutManager);
    }

    @Override
    protected void onPause() {
        // Unregister since the activity is paused.
        super.onPause();
        unregisterReceiver(response);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // An IntentFilter can match against actions, categories, and data
        IntentFilter filter = new IntentFilter();
        filter.addAction(CONFIRM_REMOVE_CARD);
        filter.addAction(CONFIRM_DELETE_CARD);
        filter.addAction(DONE_LOAD_USER_CATEGORY);

        registerReceiver(response,filter);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG, "onActivityResult: " + resultCode);
    }


    /**
     * this function will search detail on all the card and return the list of found card in the recycler view
     * @param searchInfo
     */
    private void searchMyCards(String searchInfo) {
        mSearchCardList = new ArrayList<>();
        for(Card card : mCardListDetails) {
            if(filterCard(card, searchInfo)) {
                mSearchCardList.add(card.getCardBitmap());
            }
        }
        mCardAdapter.setData(mSearchCardList);
        mCardAdapter.notifyDataSetChanged();
    }

    /**
     * This function filter a single card return true if it contains the search info
     * @param card
     * @param textSearch
     * @return true if this card contains the search string
     */
    private boolean filterCard(Card card, String textSearch) {
        if( card.getCardsDO().getTextEntities() != null) {
            List<CSTextEntity> listText = card.getCardsDO().getTextEntities();
            int size = listText.size();
            for ( int i= 0; i< size; i++) {
                CSTextEntity entity = listText.get(i);
                if (entity.getText().toUpperCase().contains(textSearch.toUpperCase())) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * This function load all the shared cards
     */
    public void initCards(){
        mCardList = new ArrayList<>();
        mCardListDetails = new ArrayList<>();
        //load all cards
        shareCardDynamoDB.loadAllSharedCards();

        categoryDynamoDB.loadCategories();

    }

    /**
     * This is call when card is successfully loaded
     * @param cards
     */
    @Override
    public void onSuccessCLoadSharedCard(ArrayList<Card> cards, ArrayList<SharedCardsDO> sharedCardsDOS) {
        if(cards != null) {
            for(Card card : cards) {
                mCardList.add(card.getCardBitmap());
                mCardListDetails.add(card);
                mCardsDOList.add(card.getCardsDO());
                Log.i("cardid", card.getCardsDO().getCardId());

            }
        }
        this.mShareCardDOList = sharedCardsDOS;

        FragmentTransaction ft = fm.beginTransaction();
        ft.setCustomAnimations(R.anim.enter_from_top, R.anim.exit_to_top);

        ft.replace(R.id.rolodexFrame, rolodexRecyclerCardFragment.newInstance(mCardList, mCardsDOList));
        ft.commitAllowingStateLoss();
    }

    /**
     * This function toggle the community search button
     */
    private void toggleCommunitySearchButton() {
        if(isCommunitySearch) {
            communitySearch.setText("My Community");

        } else
            communitySearch.setText("Entire Community");

        isCommunitySearch = !isCommunitySearch;
    }

    /**
     *
     */
    private void search() {
        String searchInfo = String.valueOf(searchText.getText());
        if(isCommunitySearch) {
            cardDynamoDB.searchSpecificCards(getApplicationContext(), searchInfo);
            mSearchCardList = new ArrayList<>();
            // mCardAdapter.setData(mSearchCardList);
        } else {
            //search my cards
            searchMyCards(searchInfo);
        }


    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        //Clear the Activity's bundle of the subsidiary fragments' bundles.
        outState.clear();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnNotification:
                if(!isShowNotification) {
                    displayNotificationFragment();
                    isShowNotification = true;
                } else {
                    isShowNotification = false;
                    displayRolodexFragment();
                }

                break;
            case R.id.addCategoryBtn:
                openAddCategoryDialog();
                break;
            case R.id.btnDelete:
                int index = categoryAdapter.getSelectedPosition();
                if( index == 0) {
                    // delete from share cards
                    //check if delete return true
                    PopUP.deleteSharedCardAlertDialog(Rolodex.this,shareCardDynamoDB, mShareCardDOList.get(cardRecycleCenterPosition) ) ;

                } else {
                    //remove from category

                    PopUP.removeSharedCardFromCategory(Rolodex.this,categoriesDO.getCategories().get(index-1), cardRecycleCenterPosition, index );
                        //displayCategoryRolodex(index);
                }
                break;
            case R.id.btnSave:
                // save the category

                createNewCategoryDO();

                PopUP.saveCategoryAlertDialog(Rolodex.this, categoryDynamoDB, categoriesDO);
                break;
        }
    }

    /**
     * Pop up for adding a category
     */
    private void openAddCategoryDialog() {
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setPadding(10, 0, 10, 0);
        final EditText editName = new EditText(this);
        editName.setHint("Enter Category Name");
        editName.setFocusable(true);

        linearLayout.addView(editName);

        final AlertDialog alertDialog = new AlertDialog.Builder(Rolodex.this)
                .setTitle("Add Category")
                .setView(linearLayout)
                .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        String name = editName.getText().toString();
                        Category category = new Category();
                        //final String uuid = UUID.randomUUID().toString();

                        //categoriesDO.setCategoryId(uuid);
                        category.setCategoryName(name);
                        categoriesDO.getCategories().add(category);

                        // create new if it is null
                        //createNewCategoryDO();

                        //categoriesDO.setCategories(categoryList);
                        categoryAdapter.notifyDataSetChanged();

                    }
                })
                .setNegativeButton("Cancel", null)
                .create();

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (editName.getText().toString().trim().length() == 0 ) {
                    alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                } else {
                    alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                }
            }
        };

        editName.addTextChangedListener(textWatcher);
        alertDialog.show();
        alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
    }

    /**
     * display notification fragment
     */
    private void displayNotificationFragment() {
        fm = getSupportFragmentManager();

        FragmentTransaction ft = fm.beginTransaction();
        ft.setCustomAnimations(R.anim.enter_from_top, R.anim.exit_to_top);
        RolodexNotificationFragment rolodexNotificationFragment = new RolodexNotificationFragment();

        ft.replace(R.id.rolodexFrame, rolodexNotificationFragment.newInstance(null, null));
        ft.commit();
    }

    /**
     * display rolodex fragment
     */
    private void displayRolodexFragment() {
        fm = getSupportFragmentManager();

        FragmentTransaction ft = fm.beginTransaction();
        ft.setCustomAnimations(R.anim.enter_from_top, R.anim.exit_to_top);

        ft.replace(R.id.rolodexFrame, rolodexRecyclerCardFragment.newInstance(mCardList, mCardsDOList));
        ft.commit();
    }

    @Override
    public void onItemNameClick(View view, int postion) {
        // Toast.makeText(getContext(), "Click " + nameList.get(position), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onItemDrag(View view, int position, Bitmap bitmap) {

        if(categoryAdapter.getSelectedPosition() == 0) {
            ClipData data = ClipData.newPlainText("", "");

            View.DragShadowBuilder myShadow = new View.DragShadowBuilder(view);

            view.startDrag(data, myShadow, null, 0);

            cardRecyclerCurrentPosition = position;
        }
    }

    @Override
    public void centerPoistion(int position) {
        cardRecycleCenterPosition = position;
        //Log.i("centerposition", ""+cardRecycleCenterPosition);
    }


    /**
     *
     * @param context
     * @param view
     * @param position
     */
    public void popUpDeleteCategory(Context context, View view, final int position) {
        final PopupMenu delete = new PopupMenu(context, view);
        delete.getMenuInflater().inflate(R.menu.delete, delete.getMenu());

        delete.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.menu_delete:

                        // delete category
                        categoriesDO.getCategories().remove(position-1);
                        categoryAdapter.notifyDataSetChanged();
                        break;
                }
                return false;
            }
        });
        delete.show();
    }

    /**
     * recycler View item drag listener
     */
    ItemDragListener dragListener = new ItemDragListener() {
        @Override
        public void onItemDrag(View v,int position, DragEvent event) {

                if(position != 0) {
                    Toast.makeText(Rolodex.this, "Add card to " +
                            categoriesDO.getCategories().get(position-1).getCategoryName(), Toast.LENGTH_SHORT).show();
                    ArrayList<String> cards = (ArrayList<String>) categoriesDO.getCategories().get(position-1).getCardList();
                    if(cards == null) {
                        cards = new ArrayList<>();
                    }

                    cards.add(mCardsDOList.get(cardRecyclerCurrentPosition).getCardId());
                    categoriesDO.getCategories().get(position-1).setCardList(cards);

                }


        }
    };

    /**
     * category item click
     * change the category tab
     */
    ItemClickListener categoryItemClick = new ItemClickListener() {
        @Override
        public void onItemClick(View view, int position) {
            // set the center position of recycler view back to 0
            cardRecycleCenterPosition = 0;

            if(position == 0) {
                // show all
                displayRolodexFragment();
            } else {

                displayCategoryRolodex(position);

            }
        }

        @Override
        public void onItemLongClick(View view, int position) {

            popUpDeleteCategory(Rolodex.this, view, position);
        }
    };

    private void displayCategoryRolodex(int position) {
        if(categoriesDO != null) {
            //show current category
            ArrayList<String> cards = (ArrayList<String>) categoriesDO.getCategories().get(position-1).getCardList();

            ArrayList<Card> temp = getCategoryCards(cards);
            ArrayList<Bitmap> temp1 = new ArrayList<>();
            ArrayList<CardsDO> temp2 = new ArrayList<>();

            for(Card c : temp) {
                temp2.add(c.getCardsDO());
                temp1.add(c.getCardBitmap());
            }

            fm = getSupportFragmentManager();

            FragmentTransaction ft = fm.beginTransaction();
            ft.setCustomAnimations(R.anim.enter_from_top, R.anim.exit_to_top);

            ft.replace(R.id.rolodexFrame, rolodexRecyclerCardFragment.newInstance(temp1, temp2));
            ft.commit();
        }

    }

    /**
     * This function get an array list of bitmap based on array list of id card string
     * @param cards array list of cardId
     * @return array list of bitmap
     */
    private ArrayList<Card> getCategoryCards(ArrayList<String> cards) {
        ArrayList<Card> cardList = new ArrayList<>();

        if(cards != null) {
            int size = cards.size();
            for (int i= 0; i< size; i++) {
                for(Card c: mCardListDetails){
                    if(c.getCardsDO().getCardId().equals(cards.get(i))){
                        cardList.add(c);
                    }
                }
            }
        }
        return cardList;
    }

    /**
     * This function create a new category DO if it is null
     */
    private void createNewCategoryDO() {
        if(categoriesDO == null) {
            categoriesDO = new CategoriesDO();
            categoriesDO.setUserId(DynamoSettings.getUserId());
            final String uuid = UUID.randomUUID().toString();
            categoriesDO.setCategoryId(uuid);
            ArrayList<Category> temp = new ArrayList<>();
            categoriesDO.setCategories(temp);
        }
    }

    /**
     * Broadcast receiver
     */
    private BroadcastReceiver response = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction() != null)
            switch (intent.getAction()){
                case CONFIRM_REMOVE_CARD :
                    int index = intent.getIntExtra(CATEGORY_POSITION, 0);
                    displayCategoryRolodex(index);
                    break;
                case CONFIRM_DELETE_CARD :

                    mCardList.remove(cardRecycleCenterPosition);
                    mShareCardDOList.remove(cardRecycleCenterPosition);
                    mCardsDOList.remove(cardRecycleCenterPosition);
                    mCardListDetails.remove(cardRecycleCenterPosition);
                    displayRolodexFragment();

                   break;
                case DONE_LOAD_USER_CATEGORY:
                    categoriesDO = (CategoriesDO) intent.getSerializableExtra("category_data");
                    displayCategory();
                    break;
            }
        }
    };
}