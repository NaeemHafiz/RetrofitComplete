package com.Abdul.retrofitdemo;

public class Constants {

    public static final String BASE_URL = "http://travces.com/bookapp/public/api/";
    public static final String LOGIN = "login";

}
