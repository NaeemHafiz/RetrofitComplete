package com.Abdul.retrofitdemo;

public class Adapter {
}
